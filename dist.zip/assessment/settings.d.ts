import type { AssessmentSettingsData } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
export declare const DEFAULT_ASSESSMENT_SETTINGS: AssessmentSettingsData;
export declare function readAssessmentSettings(db: DatabaseAdapter): AssessmentSettingsData;
export declare function normalizeAssessmentSettings(value: unknown): AssessmentSettingsData;
