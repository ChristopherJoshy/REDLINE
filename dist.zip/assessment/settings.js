"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_ASSESSMENT_SETTINGS = void 0;
exports.readAssessmentSettings = readAssessmentSettings;
exports.normalizeAssessmentSettings = normalizeAssessmentSettings;
exports.DEFAULT_ASSESSMENT_SETTINGS = {
    requireFullscreen: false,
    detectTabSwitches: false,
    singleTabMode: false,
    disableRightClick: false,
    disableCopyPaste: false,
};
function readAssessmentSettings(db) {
    var _a;
    var raw = (_a = db.get("SELECT value FROM game_state WHERE key = ?", "assessment_settings")) === null || _a === void 0 ? void 0 : _a.value;
    if (raw === undefined)
        return exports.DEFAULT_ASSESSMENT_SETTINGS;
    try {
        var value = JSON.parse(raw);
        return {
            requireFullscreen: value.requireFullscreen === true,
            detectTabSwitches: value.detectTabSwitches === true,
            singleTabMode: value.singleTabMode === true,
            disableRightClick: value.disableRightClick === true,
            disableCopyPaste: value.disableCopyPaste === true,
        };
    }
    catch (_b) {
        return exports.DEFAULT_ASSESSMENT_SETTINGS;
    }
}
function normalizeAssessmentSettings(value) {
    var body = value !== null && typeof value === "object"
        ? value
        : {};
    return {
        requireFullscreen: body.requireFullscreen === true,
        detectTabSwitches: body.detectTabSwitches === true,
        singleTabMode: body.singleTabMode === true,
        disableRightClick: body.disableRightClick === true,
        disableCopyPaste: body.disableCopyPaste === true,
    };
}
