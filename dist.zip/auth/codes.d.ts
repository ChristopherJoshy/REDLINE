export declare function generateJoinCode(): string;
export declare function normalizeCode(input: string): string;
export declare function hashJoinCode(normalized: string, pepper: string): string;
export declare function hintFor(normalized: string): string;
export declare function displayCode(normalized: string): string;
export declare function makeSessionToken(teamId: string, displayName: string, pepper: string): string;
export declare function verifySessionToken(token: string, pepper: string): {
    teamId: string;
    displayName: string;
} | undefined;
export declare function adminOk(provided: string | undefined, adminCode: string | undefined): boolean;
export declare function parseCookies(header: string | undefined): Record<string, string>;
