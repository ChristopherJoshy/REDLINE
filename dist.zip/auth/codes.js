"use strict";
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateJoinCode = generateJoinCode;
exports.normalizeCode = normalizeCode;
exports.hashJoinCode = hashJoinCode;
exports.hintFor = hintFor;
exports.displayCode = displayCode;
exports.makeSessionToken = makeSessionToken;
exports.verifySessionToken = verifySessionToken;
exports.adminOk = adminOk;
exports.parseCookies = parseCookies;
// Join codes + sessions. Plaintext codes exist only at creation; only hashes persist.
var node_crypto_1 = require("node:crypto");
var ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
function generateJoinCode() {
    var _a;
    var bytes = (0, node_crypto_1.randomBytes)(8);
    var code = "";
    for (var i = 0; i < 8; i++) {
        code += ALPHABET[((_a = bytes[i]) !== null && _a !== void 0 ? _a : 0) % ALPHABET.length];
    }
    return code;
}
function normalizeCode(input) {
    return input.toUpperCase().replace(/[^A-Z2-9]/g, "");
}
function hashJoinCode(normalized, pepper) {
    return (0, node_crypto_1.createHash)("sha256").update(pepper + ":" + normalized, "utf8").digest("hex");
}
function hintFor(normalized) {
    return normalized.slice(0, 4);
}
function displayCode(normalized) {
    return "".concat(normalized.slice(0, 4), "-").concat(normalized.slice(4));
}
function b64url(input) {
    return Buffer.from(input, "utf8").toString("base64url");
}
function unb64url(input) {
    return Buffer.from(input, "base64url").toString("utf8");
}
// Stateless session: teamId.displayName.signature (HMAC over both, keyed by pepper).
function makeSessionToken(teamId, displayName, pepper) {
    var a = b64url(teamId);
    var b = b64url(displayName);
    var sig = (0, node_crypto_1.createHmac)("sha256", pepper).update("".concat(a, ".").concat(b), "utf8").digest("hex");
    return "".concat(a, ".").concat(b, ".").concat(sig);
}
function verifySessionToken(token, pepper) {
    var parts = token.split(".");
    if (parts.length !== 3) {
        return undefined;
    }
    var _a = __read(parts, 3), a = _a[0], b = _a[1], sig = _a[2];
    var expected = (0, node_crypto_1.createHmac)("sha256", pepper).update("".concat(a, ".").concat(b), "utf8").digest("hex");
    var sigBuf = Buffer.from(sig, "utf8");
    var expBuf = Buffer.from(expected, "utf8");
    if (sigBuf.length !== expBuf.length || !(0, node_crypto_1.timingSafeEqual)(sigBuf, expBuf)) {
        return undefined;
    }
    try {
        return { teamId: unb64url(a), displayName: unb64url(b) };
    }
    catch (_b) {
        return undefined;
    }
}
function adminOk(provided, adminCode) {
    if (provided === undefined || adminCode === undefined || adminCode === "") {
        return false;
    }
    var a = Buffer.from(provided, "utf8");
    var b = Buffer.from(adminCode, "utf8");
    return a.length === b.length && (0, node_crypto_1.timingSafeEqual)(a, b);
}
function parseCookies(header) {
    var e_1, _a;
    var out = {};
    if (header === undefined) {
        return out;
    }
    try {
        for (var _b = __values(header.split(";")), _c = _b.next(); !_c.done; _c = _b.next()) {
            var part = _c.value;
            var idx = part.indexOf("=");
            if (idx < 0) {
                continue;
            }
            try {
                out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
            }
            catch (_d) {
                continue;
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return out;
}
