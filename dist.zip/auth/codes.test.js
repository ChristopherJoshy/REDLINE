"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_test_1 = require("node:test");
var codes_js_1 = require("./codes.js");
(0, node_test_1.test)("malformed unrelated cookies do not crash session authentication", function () {
    strict_1.default.equal((0, codes_js_1.parseCookies)("bad=%E0%A4%A; redline_session=valid")["redline_session"], "valid");
    strict_1.default.equal((0, codes_js_1.parseCookies)("redline_session=%GG")["redline_session"], undefined);
});
