import type { BotMeta } from "./wick.prompt.js";
export interface BossMeta extends BotMeta {
    releaseAt: number;
    phase: "p1" | "p2";
}
export declare const AIZEN_META: BossMeta;
export declare const AIZEN_P1_PROMPT: string;
export declare const AIZEN_P2_PROMPT: string;
