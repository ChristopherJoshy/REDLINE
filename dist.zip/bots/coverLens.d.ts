import type { BotId } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
export interface CoverProfile {
    team_id: string;
    display_name: string;
    bot_id: string;
    alias: string;
    role: string;
    affiliation: string;
    detail: string;
    updated_at: string;
}
export declare function getCover(db: DatabaseAdapter, teamId: string, displayName: string, botId: string): CoverProfile | undefined;
export declare function coverBrief(db: DatabaseAdapter, teamId: string, displayName: string, botId: BotId): string | undefined;
