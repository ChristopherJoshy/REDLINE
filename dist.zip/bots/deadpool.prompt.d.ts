import type { BotMeta } from "./wick.prompt";
export declare const DEADPOOL_PROMPT: string;
export declare const DEADPOOL_META: BotMeta;
