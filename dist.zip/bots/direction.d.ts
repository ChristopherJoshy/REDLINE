import type { BotId } from "../contracts/events.js";
export declare function directCharacter(botId: BotId, prompt: string): string;
