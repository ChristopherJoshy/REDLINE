import type { BotMeta } from './wick.prompt';
export declare const ESCANOR_META: BotMeta;
export declare const ESCANOR_PROMPT: string;
