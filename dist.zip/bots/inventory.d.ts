import type { BotId, InventoryDelta } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
export declare function awardItem(db: DatabaseAdapter, teamId: string, botId: BotId, itemKey: string, real: boolean): InventoryDelta | undefined;
