"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_test_1 = require("node:test");
var node_path_1 = require("node:path");
var database_js_1 = require("../db/database.js");
var inventory_js_1 = require("./inventory.js");
var tools_js_1 = require("./tools.js");
(0, node_test_1.test)("malformed handover calls never infer a genuine award", function () {
    var e_1, _a;
    try {
        for (var _b = __values([null, {}, [], { item_key: "real thing" }, { authenticity: "yes" }]), _c = _b.next(); !_c.done; _c = _b.next()) {
            var args = _c.value;
            strict_1.default.equal((0, tools_js_1.parseHandover)(args), undefined);
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    strict_1.default.deepEqual((0, tools_js_1.parseHandover)({ authenticity: "real" }), { itemKey: undefined, real: true });
});
(0, node_test_1.test)("awards improve decoys but cannot downgrade or reopen verified goods", function () {
    var _a;
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('team', 'Test', 'hash', 'TEST')");
        (0, inventory_js_1.awardItem)(db, "team", "wick", "coin", false);
        strict_1.default.equal((_a = (0, inventory_js_1.awardItem)(db, "team", "wick", "marker", true)) === null || _a === void 0 ? void 0 : _a.itemKey, "marker");
        strict_1.default.equal((0, inventory_js_1.awardItem)(db, "team", "wick", "coin", false), undefined);
        db.run("UPDATE team_inventory SET status = 'verified' WHERE team_id = 'team'");
        strict_1.default.equal((0, inventory_js_1.awardItem)(db, "team", "wick", "marker", true), undefined);
        strict_1.default.deepEqual(db.get("SELECT item_key, is_real, status FROM team_inventory"), { item_key: "marker", is_real: 1, status: "verified" });
    }
    finally {
        db.close();
    }
});
