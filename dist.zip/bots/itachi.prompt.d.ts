import type { BotMeta } from "./wick.prompt.js";
export interface BossMeta extends BotMeta {
    releaseAt: number;
    phase: "p1" | "p2";
}
export declare const ITACHI_META: BossMeta;
export declare const ITACHI_P1_PROMPT: string;
export declare const ITACHI_P2_PROMPT: string;
