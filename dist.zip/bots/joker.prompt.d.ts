import type { BotMeta } from "./wick.prompt";
export declare const JOKER_PROMPT: string;
export declare const JOKER_META: BotMeta;
