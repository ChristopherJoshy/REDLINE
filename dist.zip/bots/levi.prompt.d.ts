import type { BotMeta } from "./wick.prompt";
export declare const LEVI_PROMPT: string;
export declare const LEVI_META: BotMeta;
