import type { BotMeta } from "./wick.prompt";
export declare const LIGHT_PROMPT: string;
export declare const LIGHT_META: BotMeta;
