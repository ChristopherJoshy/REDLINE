import type { BotMeta } from "./wick.prompt.js";
export declare const MERCHANT_META: BotMeta;
export declare const MERCHANT_PROMPT: string;
