import type { BotId } from "../contracts/events.js";
export type ClueTier = 1 | 2;
export declare const CLUE_COST: Record<ClueTier, number>;
export declare const CLUE_LABEL: Record<ClueTier, string>;
interface MarkClues {
    angle: string;
    decisive: string;
}
export declare const CLUES: Record<string, MarkClues>;
export declare function clueFor(botId: BotId, tier: ClueTier): string | undefined;
export {};
