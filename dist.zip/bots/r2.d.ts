import type { BotId } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
import type { ToolDef } from "../llm/groq.js";
export type BossId = "itachi" | "aizen";
export type R2Phase = "p1" | "p2";
export declare const R2_TOOLS: ToolDef[];
export declare function userTurns(db: DatabaseAdapter, teamId: string, boss: BossId): number;
export declare function r2Phase(db: DatabaseAdapter, teamId: string, boss: BossId): R2Phase;
export declare function r2Prompt(db: DatabaseAdapter, teamId: string, boss: BossId): {
    prompt: string;
    phase: R2Phase;
    reveal: boolean;
};
export declare function bossKeys(boss: BossId): {
    itemKey: string;
    decoyKey: string;
};
export declare function bossOf(teamId: string, db: DatabaseAdapter): BossId | undefined;
export declare function escalationUsed(db: DatabaseAdapter, teamId: string, boss: BossId, kind: string): number;
export declare function markEscalation(db: DatabaseAdapter, teamId: string, boss: BossId, kind: string): void;
export declare function isBoss(botId: BotId): botId is BossId;
