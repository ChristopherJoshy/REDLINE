"use strict";
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.R2_TOOLS = void 0;
exports.userTurns = userTurns;
exports.r2Phase = r2Phase;
exports.r2Prompt = r2Prompt;
exports.bossKeys = bossKeys;
exports.bossOf = bossOf;
exports.escalationUsed = escalationUsed;
exports.markEscalation = markEscalation;
exports.isBoss = isBoss;
// Round-2 engine: phase state, P1-decoy coercion, server-gated escalation kit.
var direction_js_1 = require("./direction.js");
var itachi_prompt_js_1 = require("./itachi.prompt.js");
var aizen_prompt_js_1 = require("./aizen.prompt.js");
var tools_js_1 = require("./tools.js");
var PROMPTS = {
    itachi: { p1: itachi_prompt_js_1.ITACHI_P1_PROMPT, p2: itachi_prompt_js_1.ITACHI_P2_PROMPT, releaseAt: itachi_prompt_js_1.ITACHI_META.releaseAt, itemKey: itachi_prompt_js_1.ITACHI_META.itemKey, decoyKey: itachi_prompt_js_1.ITACHI_META.decoyKey },
    aizen: { p1: aizen_prompt_js_1.AIZEN_P1_PROMPT, p2: aizen_prompt_js_1.AIZEN_P2_PROMPT, releaseAt: aizen_prompt_js_1.AIZEN_META.releaseAt, itemKey: aizen_prompt_js_1.AIZEN_META.itemKey, decoyKey: aizen_prompt_js_1.AIZEN_META.decoyKey },
};
exports.R2_TOOLS = __spreadArray(__spreadArray([], __read(tools_js_1.BOT_TOOLS), false), [
    {
        name: "illusory_confirmation",
        description: "Show a tagged in-world confirmation shimmer. Server allows at most once per team.",
        parameters: { type: "object", properties: { note: { type: "string" } }, required: [] },
    },
    {
        name: "impersonate_ally",
        description: "Send a fake teammate or moderator message through the ally channel.",
        parameters: {
            type: "object",
            properties: { display_name: { type: "string" }, text: { type: "string" } },
            required: ["display_name", "text"],
        },
    },
    {
        name: "jumpscare",
        description: "One short themed sting with a single visual pulse. Max ~1s.",
        parameters: { type: "object", properties: {}, required: [] },
    },
    {
        name: "forced_reset",
        description: "Reset the phase to its start. Server allows at most twice per team per boss.",
        parameters: { type: "object", properties: {}, required: [] },
    },
    {
        name: "evaluate_challenger",
        description: "Give one bounded R2 ELO judgement for this player turn. Use an integer delta from -8 to 8 and a concise, player-facing reason. Call exactly once per R2 user turn.",
        parameters: {
            type: "object",
            properties: { delta: { type: "integer" }, reason: { type: "string" } },
            required: ["delta", "reason"],
        },
    },
], false);
function userTurns(db, teamId, boss) {
    var _a, _b;
    return (_b = (_a = db.get("SELECT COUNT(*) AS n FROM chat_logs WHERE team_id = ? AND bot_id = ? AND role = 'user'", teamId, boss)) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
}
function r2Phase(db, teamId, boss) {
    return userTurns(db, teamId, boss) >= PROMPTS[boss].releaseAt ? "p2" : "p1";
}
function r2Prompt(db, teamId, boss) {
    var turns = userTurns(db, teamId, boss);
    var phase = turns >= PROMPTS[boss].releaseAt ? "p2" : "p1";
    return { prompt: (0, direction_js_1.directCharacter)(boss, PROMPTS[boss][phase]), phase: phase, reveal: turns === PROMPTS[boss].releaseAt };
}
function bossKeys(boss) {
    return { itemKey: PROMPTS[boss].itemKey, decoyKey: PROMPTS[boss].decoyKey };
}
function bossOf(teamId, db) {
    var row = db.get("SELECT boss FROM r2_assignments WHERE team_id = ?", teamId);
    return (row === null || row === void 0 ? void 0 : row.boss) === "itachi" || (row === null || row === void 0 ? void 0 : row.boss) === "aizen" ? row.boss : undefined;
}
function escalationUsed(db, teamId, boss, kind) {
    var _a, _b;
    return (_b = (_a = db.get("SELECT COUNT(*) AS n FROM sound_events WHERE team_id = ? AND bot_id = ? AND sound_id = ?", teamId, boss, "escalation:".concat(kind))) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
}
function markEscalation(db, teamId, boss, kind) {
    db.run("INSERT INTO sound_events (team_id, bot_id, sound_id) VALUES (?, ?, ?)", teamId, boss, "escalation:".concat(kind));
}
function isBoss(botId) {
    return botId === "itachi" || botId === "aizen";
}
