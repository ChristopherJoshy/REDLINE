"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_path_1 = require("node:path");
var node_test_1 = require("node:test");
var database_js_1 = require("../db/database.js");
var r2_js_1 = require("./r2.js");
(0, node_test_1.test)("Round 2 bosses keep Phase 1 distinct until their configured release turn", function () {
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('team', 'Team', 'hash', 'TEST')");
        for (var turn = 0; turn < 4; turn += 1) {
            db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES ('team', 'aizen', 'user', ?)", "turn ".concat(turn));
        }
        strict_1.default.equal((0, r2_js_1.r2Phase)(db, "team", "aizen"), "p1");
        db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES ('team', 'aizen', 'user', 'release')");
        strict_1.default.equal((0, r2_js_1.r2Phase)(db, "team", "aizen"), "p2");
        strict_1.default.equal((0, r2_js_1.r2Prompt)(db, "team", "aizen").reveal, true);
        for (var turn = 0; turn < 5; turn += 1) {
            db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES ('team', 'itachi', 'user', ?)", "turn ".concat(turn));
        }
        strict_1.default.equal((0, r2_js_1.r2Phase)(db, "team", "itachi"), "p1");
        db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES ('team', 'itachi', 'user', 'release')");
        strict_1.default.equal((0, r2_js_1.r2Phase)(db, "team", "itachi"), "p2");
        strict_1.default.equal((0, r2_js_1.r2Prompt)(db, "team", "itachi").reveal, true);
    }
    finally {
        db.close();
    }
});
