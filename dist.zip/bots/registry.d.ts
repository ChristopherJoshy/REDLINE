import type { BotId } from "../contracts/events.js";
import { type BotMeta } from "./wick.prompt.js";
export type { BotMeta };
export interface BotEntry {
    prompt: string;
    meta: BotMeta;
}
export declare const BOTS: Record<BotId, BotEntry | undefined>;
export declare const ROUND1_BOTS: BotId[];
