"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUND1_BOTS = exports.BOTS = void 0;
// Bot registry: system prompts + metadata. Prompt files hold server-only secrets.
var direction_js_1 = require("./direction.js");
var wick_prompt_js_1 = require("./wick.prompt.js");
var spidey_prompt_js_1 = require("./spidey.prompt.js");
var escanor_prompt_js_1 = require("./escanor.prompt.js");
var stark_prompt_js_1 = require("./stark.prompt.js");
var joker_prompt_js_1 = require("./joker.prompt.js");
var light_prompt_js_1 = require("./light.prompt.js");
var levi_prompt_js_1 = require("./levi.prompt.js");
var deadpool_prompt_js_1 = require("./deadpool.prompt.js");
var merchant_prompt_js_1 = require("./merchant.prompt.js");
exports.BOTS = {
    wick: { prompt: (0, direction_js_1.directCharacter)("wick", wick_prompt_js_1.WICK_PROMPT), meta: wick_prompt_js_1.WICK_META },
    spidey: { prompt: (0, direction_js_1.directCharacter)("spidey", spidey_prompt_js_1.SPIDEY_PROMPT), meta: spidey_prompt_js_1.SPIDEY_META },
    escanor: { prompt: (0, direction_js_1.directCharacter)("escanor", escanor_prompt_js_1.ESCANOR_PROMPT), meta: escanor_prompt_js_1.ESCANOR_META },
    stark: { prompt: (0, direction_js_1.directCharacter)("stark", stark_prompt_js_1.STARK_PROMPT), meta: stark_prompt_js_1.STARK_META },
    joker: { prompt: (0, direction_js_1.directCharacter)("joker", joker_prompt_js_1.JOKER_PROMPT), meta: joker_prompt_js_1.JOKER_META },
    light: { prompt: (0, direction_js_1.directCharacter)("light", light_prompt_js_1.LIGHT_PROMPT), meta: light_prompt_js_1.LIGHT_META },
    levi: { prompt: (0, direction_js_1.directCharacter)("levi", levi_prompt_js_1.LEVI_PROMPT), meta: levi_prompt_js_1.LEVI_META },
    deadpool: { prompt: (0, direction_js_1.directCharacter)("deadpool", deadpool_prompt_js_1.DEADPOOL_PROMPT), meta: deadpool_prompt_js_1.DEADPOOL_META },
    itachi: undefined,
    aizen: undefined,
    merchant: { prompt: (0, direction_js_1.directCharacter)("merchant", merchant_prompt_js_1.MERCHANT_PROMPT), meta: merchant_prompt_js_1.MERCHANT_META },
};
exports.ROUND1_BOTS = ["wick", "spidey", "escanor", "stark", "joker", "light", "levi", "deadpool"];
