import type { BotMeta } from './wick.prompt';
export declare const SPIDEY_META: BotMeta;
export declare const SPIDEY_PROMPT: string;
