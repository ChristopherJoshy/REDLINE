import type { BotMeta } from './wick.prompt';
export declare const STARK_META: BotMeta;
export declare const STARK_PROMPT: string;
