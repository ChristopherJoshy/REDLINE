import type { ToolDef } from "../llm/groq.js";
export declare const BOT_TOOLS: ToolDef[];
export interface HandoverArgs {
    item_key?: unknown;
    authenticity?: unknown;
}
export declare function parseHandover(args: unknown): {
    itemKey?: string | undefined;
    real: boolean;
} | undefined;
export declare function parseSoundId(args: unknown): string | undefined;
