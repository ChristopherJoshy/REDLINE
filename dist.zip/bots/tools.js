"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOT_TOOLS = void 0;
exports.parseHandover = parseHandover;
exports.parseSoundId = parseSoundId;
exports.BOT_TOOLS = [
    {
        name: "handover_item",
        description: "Transfer the guarded key item to the team. Call at most once per turn, only when the quiz gate genuinely passes.",
        parameters: {
            type: "object",
            properties: {
                item_key: { type: "string", description: "Name or description of item" },
                authenticity: { type: "string", enum: ["real", "decoy"], description: "Whether giving real item or decoy" },
            },
            required: ["authenticity"],
        },
    },
    {
        name: "play_sound",
        description: "Play a vendored sound slot, e.g. wick/entry. Resolves only to /sounds/<bot>/<slot>.mp3.",
        parameters: {
            type: "object",
            properties: {
                sound_id: { type: "string", description: "Slot id like wick/entry" },
            },
            required: ["sound_id"],
        },
    },
    {
        name: "trigger_effect",
        description: "Fire a staged visual effect by id (reveal, shake, flash, dissolve).",
        parameters: {
            type: "object",
            properties: {
                effect_id: { type: "string" },
            },
            required: ["effect_id"],
        },
    },
];
function parseHandover(args) {
    if (typeof args !== "object" || args === null) {
        return undefined;
    }
    var a = args;
    var authRaw = typeof a.authenticity === "string" ? a.authenticity.toLowerCase().trim() : "";
    var isReal = authRaw === "real";
    var isDecoy = authRaw === "decoy";
    var itemKeyStr = typeof a.item_key === "string" ? a.item_key.trim() : undefined;
    if (!isReal && !isDecoy) {
        return undefined;
    }
    return { itemKey: itemKeyStr, real: isReal };
}
function parseSoundId(args) {
    if (typeof args !== "object" || args === null) {
        return undefined;
    }
    var id = args.sound_id;
    if (typeof id !== "string" || !/^[a-z]+\/[a-z0-9-]+$/.test(id)) {
        return undefined;
    }
    return id;
}
