export interface BotMeta {
    botId: string;
    round: 'r1';
    itemKey: string;
    decoyKey: string;
    soundIds: string[];
    bounty: number;
}
export declare const WICK_META: BotMeta;
export declare const WICK_PROMPT: string;
