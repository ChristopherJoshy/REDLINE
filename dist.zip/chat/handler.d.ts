import type { BotId } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
import type { Bus } from "../ws/bus.js";
export declare function handleChatSend(bus: Bus, db: DatabaseAdapter, teamId: string, botId: BotId, text: string, displayName: string): Promise<void>;
