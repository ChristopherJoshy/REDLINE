import type { BotId } from "../contracts/events.js";
export interface BotLock {
    displayName: string;
    since: string;
}
export type LockMap = Partial<Record<BotId, BotLock>>;
export declare function lockable(botId: string): botId is BotId;
export declare class BotLocks {
    private teams;
    /** Acquire (or refresh, when the holder re-knocks). 409-style conflict carries the holder. */
    acquire(teamId: string, botId: string, displayName: string): {
        ok: true;
    } | {
        ok: false;
        holder: BotLock;
    };
    /** Release only the holder's own lock; strangers cannot evict. */
    release(teamId: string, botId: string, displayName: string): boolean;
    holder(teamId: string, botId: string): BotLock | undefined;
    snapshot(teamId: string): LockMap;
    snapshotAll(): Record<string, LockMap>;
    /** Sweep expired leases. Returns the teamIds whose maps changed. */
    sweep(): string[];
    private sweepTeam;
}
