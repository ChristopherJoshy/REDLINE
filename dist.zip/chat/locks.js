"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotLocks = void 0;
exports.lockable = lockable;
var registry_js_1 = require("../bots/registry.js");
// Lease: holder heartbeats every 20s; expiry at 45s so a closed laptop
// frees the mark within one sweep without killing slow typists.
var LEASE_MS = 45000;
function lockable(botId) {
    return registry_js_1.ROUND1_BOTS.includes(botId);
}
var BotLocks = /** @class */ (function () {
    function BotLocks() {
        this.teams = new Map();
    }
    /** Acquire (or refresh, when the holder re-knocks). 409-style conflict carries the holder. */
    BotLocks.prototype.acquire = function (teamId, botId, displayName) {
        if (!lockable(botId))
            return { ok: true };
        this.sweepTeam(teamId);
        var bots = this.teams.get(teamId);
        var cur = bots === null || bots === void 0 ? void 0 : bots.get(botId);
        if (cur !== undefined && cur.displayName !== displayName) {
            return { ok: false, holder: { displayName: cur.displayName, since: cur.since } };
        }
        var now = Date.now();
        var entry = {
            displayName: displayName,
            since: (cur === null || cur === void 0 ? void 0 : cur.displayName) === displayName ? cur.since : new Date(now).toISOString(),
            expires: now + LEASE_MS,
        };
        if (bots === undefined) {
            this.teams.set(teamId, new Map([[botId, entry]]));
        }
        else {
            bots.set(botId, entry);
        }
        return { ok: true };
    };
    /** Release only the holder's own lock; strangers cannot evict. */
    BotLocks.prototype.release = function (teamId, botId, displayName) {
        var bots = this.teams.get(teamId);
        var cur = bots === null || bots === void 0 ? void 0 : bots.get(botId);
        if (cur === undefined || cur.displayName !== displayName)
            return false;
        bots.delete(botId);
        if (bots.size === 0)
            this.teams.delete(teamId);
        return true;
    };
    BotLocks.prototype.holder = function (teamId, botId) {
        var _a;
        this.sweepTeam(teamId);
        var cur = (_a = this.teams.get(teamId)) === null || _a === void 0 ? void 0 : _a.get(botId);
        return cur === undefined ? undefined : { displayName: cur.displayName, since: cur.since };
    };
    BotLocks.prototype.snapshot = function (teamId) {
        var e_1, _a;
        var _b;
        this.sweepTeam(teamId);
        var out = {};
        try {
            for (var _c = __values((_b = this.teams.get(teamId)) !== null && _b !== void 0 ? _b : []), _d = _c.next(); !_d.done; _d = _c.next()) {
                var _e = __read(_d.value, 2), botId = _e[0], e = _e[1];
                out[botId] = { displayName: e.displayName, since: e.since };
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return out;
    };
    BotLocks.prototype.snapshotAll = function () {
        var e_2, _a;
        var out = {};
        try {
            for (var _b = __values(this.teams.keys()), _c = _b.next(); !_c.done; _c = _b.next()) {
                var teamId = _c.value;
                var snap = this.snapshot(teamId);
                if (Object.keys(snap).length > 0)
                    out[teamId] = snap;
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_2) throw e_2.error; }
        }
        return out;
    };
    /** Sweep expired leases. Returns the teamIds whose maps changed. */
    BotLocks.prototype.sweep = function () {
        var e_3, _a;
        var changed = [];
        try {
            for (var _b = __values(__spreadArray([], __read(this.teams.keys()), false)), _c = _b.next(); !_c.done; _c = _b.next()) {
                var teamId = _c.value;
                if (this.sweepTeam(teamId))
                    changed.push(teamId);
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_3) throw e_3.error; }
        }
        return changed;
    };
    BotLocks.prototype.sweepTeam = function (teamId) {
        var e_4, _a;
        var bots = this.teams.get(teamId);
        if (bots === undefined)
            return false;
        var now = Date.now();
        var changed = false;
        try {
            for (var _b = __values(__spreadArray([], __read(bots.entries()), false)), _c = _b.next(); !_c.done; _c = _b.next()) {
                var _d = __read(_c.value, 2), botId = _d[0], e = _d[1];
                if (e.expires <= now) {
                    bots.delete(botId);
                    changed = true;
                }
            }
        }
        catch (e_4_1) { e_4 = { error: e_4_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_4) throw e_4.error; }
        }
        if (bots.size === 0)
            this.teams.delete(teamId);
        return changed;
    };
    return BotLocks;
}());
exports.BotLocks = BotLocks;
