import type { DatabaseAdapter } from "../db/database.js";
import { type BossId } from "../bots/r2.js";
import type { Bus } from "../ws/bus.js";
export declare function handleR2Chat(bus: Bus, db: DatabaseAdapter, teamId: string, boss: BossId, text: string, displayName: string): Promise<void>;
