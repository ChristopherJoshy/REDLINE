"use strict";
// Single-sourced WS + room contracts. Frontend imports this file. No duplicated schemas.
// Every frame on the wire: { id, at, event, data }.
Object.defineProperty(exports, "__esModule", { value: true });
