export interface RunResult {
    changes: number;
    lastInsertRowid: number | bigint;
}
export interface DatabaseAdapter {
    exec(sql: string): void;
    run(sql: string, ...params: unknown[]): RunResult;
    get<T>(sql: string, ...params: unknown[]): T | undefined;
    all<T>(sql: string, ...params: unknown[]): T[];
    transaction<T>(fn: () => T): T;
    backup(path: string): Promise<void>;
    close(): void;
}
export declare function openDatabase(path: string, schemaPath: string): DatabaseAdapter;
