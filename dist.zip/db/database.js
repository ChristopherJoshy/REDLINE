"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.openDatabase = openDatabase;
// DatabaseAdapter hides the bun:sqlite / better-sqlite3 swap.
// Bun primary: `bun run src/server.ts` (bun:sqlite). Node fallback: `node dist/server.js` (better-sqlite3).
var node_fs_1 = require("node:fs");
function loadDriver(path) {
    if (typeof Bun !== "undefined") {
        var Database_1 = require("bun:sqlite").Database;
        var db_1 = new Database_1(path);
        db_1.exec("PRAGMA journal_mode = WAL;");
        return db_1;
    }
    var Database = require("better-sqlite3");
    var db = new Database(path);
    db.exec("PRAGMA journal_mode = WAL;");
    return db;
}
function openDatabase(path, schemaPath) {
    var _this = this;
    var driver = loadDriver(path);
    driver.exec((0, node_fs_1.readFileSync)(schemaPath, "utf8"));
    try {
        driver.exec("ALTER TABLE teams ADD COLUMN join_code TEXT;");
    }
    catch (_a) {
        // column already exists
    }
    try {
        driver.exec("ALTER TABLE teams ADD COLUMN clue_credits INTEGER NOT NULL DEFAULT 0;");
    }
    catch (_b) {
        // column already exists
    }
    try {
        driver.exec("ALTER TABLE teams ADD COLUMN round2_eligible INTEGER NOT NULL DEFAULT 0;");
    }
    catch (_c) {
        // column already exists
    }
    try {
        driver.exec("ALTER TABLE cover_profiles ADD COLUMN bot_id TEXT NOT NULL DEFAULT '*';");
    }
    catch (_d) {
        // column already exists
    }
    // Recreate cover_profiles with correct composite PK (team_id, display_name, bot_id) if needed
    var pkCheck = driver.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='cover_profiles'").get();
    if (pkCheck && !pkCheck.sql.includes("team_id, display_name, bot_id")) {
        driver.exec("DELETE FROM cover_profiles WHERE bot_id = '*'");
        driver.exec("CREATE TABLE cover_profiles_new (\n      team_id TEXT NOT NULL REFERENCES teams(id),\n      display_name TEXT NOT NULL,\n      bot_id TEXT NOT NULL DEFAULT '*',\n      alias TEXT NOT NULL,\n      role TEXT NOT NULL DEFAULT '',\n      affiliation TEXT NOT NULL DEFAULT '',\n      detail TEXT NOT NULL DEFAULT '',\n      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),\n      PRIMARY KEY (team_id, display_name, bot_id)\n    )");
        driver.exec("INSERT INTO cover_profiles_new SELECT * FROM cover_profiles");
        driver.exec("DROP TABLE cover_profiles");
        driver.exec("ALTER TABLE cover_profiles_new RENAME TO cover_profiles");
    }
    driver.exec("DELETE FROM cover_profiles WHERE bot_id = '*';");
    return {
        exec: function (sql) { return driver.exec(sql); },
        run: function (sql) {
            var _a;
            var params = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                params[_i - 1] = arguments[_i];
            }
            var r = (_a = driver.prepare(sql)).run.apply(_a, __spreadArray([], __read(params), false));
            return { changes: Number(r.changes), lastInsertRowid: r.lastInsertRowid };
        },
        get: function (sql) {
            var _a;
            var _b;
            var params = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                params[_i - 1] = arguments[_i];
            }
            return (_b = (_a = driver.prepare(sql)).get.apply(_a, __spreadArray([], __read(params), false))) !== null && _b !== void 0 ? _b : undefined;
        },
        all: function (sql) {
            var _a;
            var params = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                params[_i - 1] = arguments[_i];
            }
            return (_a = driver.prepare(sql)).all.apply(_a, __spreadArray([], __read(params), false));
        },
        transaction: function (fn) { return driver.transaction(fn)(); },
        backup: function (dest) { return __awaiter(_this, void 0, void 0, function () {
            var bytes;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(typeof Bun !== "undefined")) return [3 /*break*/, 2];
                        return [4 /*yield*/, driver.backup(dest)];
                    case 1:
                        bytes = _a.sent();
                        void bytes;
                        return [2 /*return*/];
                    case 2: return [4 /*yield*/, driver.backup(dest)];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); },
        close: function () { return driver.close(); },
    };
}
