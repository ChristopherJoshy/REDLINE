import type { BotId } from "../contracts/events.js";
import type { DatabaseAdapter } from "../db/database.js";
export declare const START_RATING = 600;
export interface EloResult {
    before: number;
    after: number;
    delta: number;
    baseDelta: number;
    speedBonus: number;
    completionRank: number;
    elapsedSecs: number;
}
export interface AssessmentEloResult {
    before: number;
    after: number;
    delta: number;
}
export declare const BOT_RATINGS: Record<BotId, number>;
export declare function expectedScore(team: number, opp: number): number;
export declare function applyElo(db: DatabaseAdapter, teamId: string, botId: BotId, reason: string, now?: number): EloResult;
export declare function applyAssessmentElo(db: DatabaseAdapter, teamId: string, delta: number, reason: string): AssessmentEloResult;
