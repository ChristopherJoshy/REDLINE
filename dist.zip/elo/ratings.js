"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOT_RATINGS = exports.START_RATING = void 0;
exports.expectedScore = expectedScore;
exports.applyElo = applyElo;
exports.applyAssessmentElo = applyAssessmentElo;
var state_js_1 = require("../rounds/state.js");
exports.START_RATING = 600;
var K = 32;
var K_PROVISIONAL = 40;
var PROVISIONAL_MATCHES = 10;
var SPEED_BONUSES = [12, 9, 7, 5, 3, 2, 1];
exports.BOT_RATINGS = {
    wick: 950,
    spidey: 800,
    escanor: 900,
    stark: 1000,
    joker: 1150,
    light: 1200,
    levi: 1100,
    deadpool: 850,
    itachi: 1500,
    aizen: 1700,
    merchant: 600,
};
function expectedScore(team, opp) {
    return 1 / (1 + Math.pow(10, (opp - team) / 400));
}
function applyElo(db, teamId, botId, reason, now) {
    var _a, _b, _c, _d, _e;
    if (now === void 0) { now = Date.now(); }
    var team = db.get("SELECT elo FROM teams WHERE id = ?", teamId);
    if (team === undefined) {
        throw new Error("unknown team");
    }
    var matches = (_b = (_a = db.get("SELECT COUNT(*) AS n FROM elo_log WHERE team_id = ?", teamId)) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
    var k = matches < PROVISIONAL_MATCHES ? K_PROVISIONAL : K;
    var before = team.elo;
    var baseDelta = Math.round(k * (1 - expectedScore(before, exports.BOT_RATINGS[botId])));
    var previousCompletions = (_d = (_c = db.get("SELECT COUNT(*) AS n FROM team_inventory WHERE bot_id = ? AND team_id != ? AND status = 'verified'", botId, teamId)) === null || _c === void 0 ? void 0 : _c.n) !== null && _d !== void 0 ? _d : 0;
    var completionRank = previousCompletions + 1;
    var speedBonus = (_e = SPEED_BONUSES[completionRank - 1]) !== null && _e !== void 0 ? _e : 0;
    var round = botId === "itachi" || botId === "aizen" ? 2 : 1;
    var startsAt = (0, state_js_1.roundState)(db, round, now).startsAt;
    var elapsedSecs = startsAt === null ? 0 : Math.max(0, Math.floor((now - Date.parse(startsAt)) / 1000));
    var delta = baseDelta + speedBonus;
    var after = before + delta;
    var auditReason = "".concat(reason, ";rank=").concat(completionRank, ";elapsed=").concat(elapsedSecs, ";base=").concat(baseDelta, ";speed=").concat(speedBonus);
    db.transaction(function () {
        db.run("UPDATE teams SET elo = ? WHERE id = ?", after, teamId);
        db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) VALUES (?, ?, ?, ?, ?)", teamId, delta, before, after, auditReason);
    });
    return { before: before, after: after, delta: delta, baseDelta: baseDelta, speedBonus: speedBonus, completionRank: completionRank, elapsedSecs: elapsedSecs };
}
// A bounded, auditable R2 judgement. This is intentionally separate from a
// verified-item match: winning the boss remains the only way to earn match Elo.
function applyAssessmentElo(db, teamId, delta, reason) {
    if (!Number.isInteger(delta) || delta < -8 || delta > 8)
        throw new Error("invalid assessment delta");
    var team = db.get("SELECT elo FROM teams WHERE id = ?", teamId);
    if (team === undefined)
        throw new Error("unknown team");
    var after = Math.max(0, team.elo + delta);
    var applied = after - team.elo;
    db.run("UPDATE teams SET elo = ? WHERE id = ?", after, teamId);
    db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) VALUES (?, ?, ?, ?, ?)", teamId, applied, team.elo, after, reason);
    return { before: team.elo, after: after, delta: applied };
}
