"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_path_1 = require("node:path");
var node_test_1 = require("node:test");
var database_js_1 = require("../db/database.js");
var state_js_1 = require("../rounds/state.js");
var ratings_js_1 = require("./ratings.js");
(0, node_test_1.test)("ELO adds a per-character completion-order bonus with an audit trail", function () {
    var _a, _b;
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        var now = Date.parse("2026-09-15T10:01:00.000Z");
        db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('first', 'First', 'one', 'ONE1')");
        db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('second', 'Second', 'two', 'TWO2')");
        (0, state_js_1.startRound)(db, 1, 600, now - 60000);
        db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, verified_at) VALUES ('first', 'wick', 'marker', 1, 'verified', '2026-09-15T10:00:30.000Z')");
        var first = (0, ratings_js_1.applyElo)(db, "first", "wick", "verified:wick", now);
        strict_1.default.equal(first.completionRank, 1);
        strict_1.default.equal(first.speedBonus, 12);
        strict_1.default.equal(first.delta, first.baseDelta + 12);
        db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, verified_at) VALUES ('second', 'wick', 'marker', 1, 'verified', '2026-09-15T10:00:40.000Z')");
        var second = (0, ratings_js_1.applyElo)(db, "second", "wick", "verified:wick", now + 10000);
        strict_1.default.equal(second.completionRank, 2);
        strict_1.default.equal(second.speedBonus, 9);
        strict_1.default.match((_b = (_a = db.get("SELECT reason FROM elo_log WHERE team_id = 'second'")) === null || _a === void 0 ? void 0 : _a.reason) !== null && _b !== void 0 ? _b : "", /rank=2;elapsed=40;base=\d+;speed=9/);
    }
    finally {
        db.close();
    }
});
(0, node_test_1.test)("Round 2 assessments are bounded and leave an ELO audit trail", function () {
    var _a, _b;
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('team', 'Team', 'hash', 'TEST')");
        var result = (0, ratings_js_1.applyAssessmentElo)(db, "team", -8, "r2-assessment:itachi:p1;cover contradicted itself");
        strict_1.default.equal(result.before, 600);
        strict_1.default.equal(result.after, 592);
        strict_1.default.equal(result.delta, -8);
        strict_1.default.match((_b = (_a = db.get("SELECT reason FROM elo_log WHERE team_id = 'team'")) === null || _a === void 0 ? void 0 : _a.reason) !== null && _b !== void 0 ? _b : "", /^r2-assessment:itachi:p1;/);
        strict_1.default.throws(function () { return (0, ratings_js_1.applyAssessmentElo)(db, "team", 9, "out of range"); }, /invalid assessment delta/);
    }
    finally {
        db.close();
    }
});
