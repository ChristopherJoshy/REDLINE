export declare const env: {
    readonly groqApiKey: string;
    readonly zenApiKey: string;
    readonly joinCodePepper: string;
    readonly adminCode: string | undefined;
    readonly adminSettingsPin: string | undefined;
    readonly port: number;
};
