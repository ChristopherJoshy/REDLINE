"use strict";
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
// Env access: every required key read in exactly one place. Boot fails closed (see scripts/check-env.js).
function required(name) {
    var value = process.env[name];
    if (value === undefined || value === "") {
        throw new Error("missing env: ".concat(name, " (see .env.example; no partial boot)"));
    }
    return value;
}
exports.env = {
    get groqApiKey() {
        return required("GROQ_API_KEY");
    },
    get zenApiKey() {
        return required("ZEN_API_KEY");
    },
    get joinCodePepper() {
        return required("JOIN_CODE_PEPPER");
    },
    get adminCode() {
        return process.env["ADMIN_CODE"];
    },
    get adminSettingsPin() {
        return process.env["ADMIN_SETTINGS_PIN"];
    },
    port: Number((_a = process.env["PORT"]) !== null && _a !== void 0 ? _a : 3001),
};
