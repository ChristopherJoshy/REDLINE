import type { DatabaseAdapter } from "../db/database.js";
export interface ChatMessage {
    role: "system" | "user" | "assistant" | "tool";
    content: string;
    tool_calls?: ToolCall[];
    tool_call_id?: string;
    name?: string;
}
export interface ToolCall {
    id: string;
    name: string;
    args: unknown;
}
export interface ToolDef {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
}
export type StreamYield = {
    kind: "delta";
    text: string;
} | {
    kind: "tool";
    call: ToolCall;
} | {
    kind: "done";
    finish: string;
};
export declare function streamChat(messages: ChatMessage[], tools: ToolDef[], db?: DatabaseAdapter): AsyncGenerator<StreamYield>;
