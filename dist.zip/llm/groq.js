"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.streamChat = streamChat;
var keyPool_js_1 = require("./keyPool.js");
var tokenTracker_js_1 = require("./tokenTracker.js");
var MODEL = "qwen/qwen3.8-27b";
function streamChatWithKey(apiKey, messages, tools) {
    return __asyncGenerator(this, arguments, function streamChatWithKey_1() {
        var startTime, estimatedCompletion, exactUsage, res, errorBody, reader, decoder, buf, calls, finish, _a, done, value, lines, lines_1, lines_1_1, line, trimmed, payload, chunk, choice, delta, count, _b, _c, tc, slot, e_1_1, ordered, ordered_1, ordered_1_1, _d, slot, args, e_2_1, durationMs, estimatedPrompt;
        var e_1, _e, e_3, _f, e_2, _g;
        var _h, _j, _k, _l, _m, _o, _p, _q;
        return __generator(this, function (_r) {
            switch (_r.label) {
                case 0:
                    startTime = Date.now();
                    estimatedCompletion = 0;
                    exactUsage = null;
                    return [4 /*yield*/, __await(fetch("https://api.groq.com/openai/v1/chat/completions", {
                            method: "POST",
                            signal: AbortSignal.timeout(90000),
                            headers: {
                                Authorization: "Bearer ".concat(apiKey),
                                "Content-Type": "application/json",
                            },
                            body: JSON.stringify({
                                model: MODEL,
                                messages: messages,
                                tools: tools.map(function (t) { return ({ type: "function", function: { name: t.name, description: t.description, parameters: t.parameters } }); }),
                                stream: true,
                                stream_options: { include_usage: true },
                            }),
                        }))];
                case 1:
                    res = _r.sent();
                    if (!(!res.ok || res.body === null)) return [3 /*break*/, 3];
                    return [4 /*yield*/, __await(res.text().catch(function () { return ""; }))];
                case 2:
                    errorBody = _r.sent();
                    throw new Error("groq ".concat(res.status, ": ").concat(errorBody.slice(0, 150)));
                case 3:
                    reader = res.body.getReader();
                    decoder = new TextDecoder();
                    buf = "";
                    calls = new Map();
                    finish = "";
                    _r.label = 4;
                case 4: return [4 /*yield*/, __await(reader.read())];
                case 5:
                    _a = _r.sent(), done = _a.done, value = _a.value;
                    if (done) {
                        return [3 /*break*/, 16];
                    }
                    buf += decoder.decode(value, { stream: true });
                    lines = buf.split("\n");
                    buf = (_h = lines.pop()) !== null && _h !== void 0 ? _h : "";
                    _r.label = 6;
                case 6:
                    _r.trys.push([6, 13, 14, 15]);
                    lines_1 = (e_1 = void 0, __values(lines)), lines_1_1 = lines_1.next();
                    _r.label = 7;
                case 7:
                    if (!!lines_1_1.done) return [3 /*break*/, 12];
                    line = lines_1_1.value;
                    trimmed = line.trim();
                    if (!trimmed.startsWith("data:")) {
                        return [3 /*break*/, 11];
                    }
                    payload = trimmed.slice(5).trim();
                    if (payload === "[DONE]") {
                        return [3 /*break*/, 11];
                    }
                    chunk = void 0;
                    try {
                        chunk = JSON.parse(payload);
                    }
                    catch (_s) {
                        return [3 /*break*/, 11];
                    }
                    if (chunk.usage && typeof chunk.usage.total_tokens === "number") {
                        exactUsage = chunk.usage;
                    }
                    choice = (_j = chunk.choices) === null || _j === void 0 ? void 0 : _j[0];
                    if ((choice === null || choice === void 0 ? void 0 : choice.finish_reason) !== undefined && choice.finish_reason !== null) {
                        finish = choice.finish_reason;
                    }
                    delta = choice === null || choice === void 0 ? void 0 : choice.delta;
                    if (!(typeof (delta === null || delta === void 0 ? void 0 : delta.content) === "string" && delta.content !== "")) return [3 /*break*/, 10];
                    count = Math.max(1, Math.ceil(delta.content.length / 4));
                    estimatedCompletion += count;
                    tokenTracker_js_1.tokenTracker.recordTokenDelta(count);
                    return [4 /*yield*/, __await({ kind: "delta", text: delta.content })];
                case 8: return [4 /*yield*/, _r.sent()];
                case 9:
                    _r.sent();
                    _r.label = 10;
                case 10:
                    try {
                        for (_b = (e_3 = void 0, __values((_k = delta === null || delta === void 0 ? void 0 : delta.tool_calls) !== null && _k !== void 0 ? _k : [])), _c = _b.next(); !_c.done; _c = _b.next()) {
                            tc = _c.value;
                            slot = (_l = calls.get(tc.index)) !== null && _l !== void 0 ? _l : { id: "", name: "", args: "" };
                            if (tc.id !== undefined) {
                                slot.id = tc.id;
                            }
                            if (((_m = tc.function) === null || _m === void 0 ? void 0 : _m.name) !== undefined) {
                                slot.name = tc.function.name;
                            }
                            if (((_o = tc.function) === null || _o === void 0 ? void 0 : _o.arguments) !== undefined) {
                                slot.args += tc.function.arguments;
                            }
                            calls.set(tc.index, slot);
                        }
                    }
                    catch (e_3_1) { e_3 = { error: e_3_1 }; }
                    finally {
                        try {
                            if (_c && !_c.done && (_f = _b.return)) _f.call(_b);
                        }
                        finally { if (e_3) throw e_3.error; }
                    }
                    _r.label = 11;
                case 11:
                    lines_1_1 = lines_1.next();
                    return [3 /*break*/, 7];
                case 12: return [3 /*break*/, 15];
                case 13:
                    e_1_1 = _r.sent();
                    e_1 = { error: e_1_1 };
                    return [3 /*break*/, 15];
                case 14:
                    try {
                        if (lines_1_1 && !lines_1_1.done && (_e = lines_1.return)) _e.call(lines_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                    return [7 /*endfinally*/];
                case 15: return [3 /*break*/, 4];
                case 16:
                    if (!finish || finish === "length" || finish === "content_filter") {
                        throw new Error("Groq response did not complete successfully");
                    }
                    ordered = __spreadArray([], __read(calls.entries()), false).sort(function (a, b) { return a[0] - b[0]; });
                    _r.label = 17;
                case 17:
                    _r.trys.push([17, 23, 24, 25]);
                    ordered_1 = __values(ordered), ordered_1_1 = ordered_1.next();
                    _r.label = 18;
                case 18:
                    if (!!ordered_1_1.done) return [3 /*break*/, 22];
                    _d = __read(ordered_1_1.value, 2), slot = _d[1];
                    args = {};
                    try {
                        args = JSON.parse(slot.args === "" ? "{}" : slot.args);
                    }
                    catch (_t) {
                        args = {};
                    }
                    return [4 /*yield*/, __await({ kind: "tool", call: { id: slot.id, name: slot.name, args: args } })];
                case 19: return [4 /*yield*/, _r.sent()];
                case 20:
                    _r.sent();
                    _r.label = 21;
                case 21:
                    ordered_1_1 = ordered_1.next();
                    return [3 /*break*/, 18];
                case 22: return [3 /*break*/, 25];
                case 23:
                    e_2_1 = _r.sent();
                    e_2 = { error: e_2_1 };
                    return [3 /*break*/, 25];
                case 24:
                    try {
                        if (ordered_1_1 && !ordered_1_1.done && (_g = ordered_1.return)) _g.call(ordered_1);
                    }
                    finally { if (e_2) throw e_2.error; }
                    return [7 /*endfinally*/];
                case 25:
                    durationMs = Date.now() - startTime;
                    if (exactUsage) {
                        tokenTracker_js_1.tokenTracker.recordStreamUsage((_p = exactUsage.prompt_tokens) !== null && _p !== void 0 ? _p : 0, (_q = exactUsage.completion_tokens) !== null && _q !== void 0 ? _q : estimatedCompletion, durationMs);
                    }
                    else {
                        estimatedPrompt = messages.reduce(function (acc, m) { return acc + Math.max(1, Math.ceil(m.content.length / 3.8)); }, 0);
                        tokenTracker_js_1.tokenTracker.recordStreamUsage(estimatedPrompt, estimatedCompletion, durationMs);
                    }
                    return [4 /*yield*/, __await({ kind: "done", finish: finish })];
                case 26: return [4 /*yield*/, _r.sent()];
                case 27:
                    _r.sent();
                    return [2 /*return*/];
            }
        });
    });
}
var zen_js_1 = require("./zen.js");
function streamChat(messages, tools, db) {
    return __asyncGenerator(this, arguments, function streamChat_1() {
        var started, _a, _b, _c, chunk, e_4_1, groqErr_1, _d, _e, _f, chunk, e_5_1, zenErr_1;
        var _g, e_4, _h, _j, _k, e_5, _l, _m;
        return __generator(this, function (_o) {
            switch (_o.label) {
                case 0:
                    started = false;
                    _o.label = 1;
                case 1:
                    _o.trys.push([1, 16, , 37]);
                    _o.label = 2;
                case 2:
                    _o.trys.push([2, 9, 10, 15]);
                    _a = true, _b = __asyncValues((0, keyPool_js_1.runWithRotation)("groq", function (key) { return streamChatWithKey(key, messages, tools); }, db));
                    _o.label = 3;
                case 3: return [4 /*yield*/, __await(_b.next())];
                case 4:
                    if (!(_c = _o.sent(), _g = _c.done, !_g)) return [3 /*break*/, 8];
                    _j = _c.value;
                    _a = false;
                    chunk = _j;
                    started = true;
                    return [4 /*yield*/, __await(chunk)];
                case 5: return [4 /*yield*/, _o.sent()];
                case 6:
                    _o.sent();
                    _o.label = 7;
                case 7:
                    _a = true;
                    return [3 /*break*/, 3];
                case 8: return [3 /*break*/, 15];
                case 9:
                    e_4_1 = _o.sent();
                    e_4 = { error: e_4_1 };
                    return [3 /*break*/, 15];
                case 10:
                    _o.trys.push([10, , 13, 14]);
                    if (!(!_a && !_g && (_h = _b.return))) return [3 /*break*/, 12];
                    return [4 /*yield*/, __await(_h.call(_b))];
                case 11:
                    _o.sent();
                    _o.label = 12;
                case 12: return [3 /*break*/, 14];
                case 13:
                    if (e_4) throw e_4.error;
                    return [7 /*endfinally*/];
                case 14: return [7 /*endfinally*/];
                case 15: return [3 /*break*/, 37];
                case 16:
                    groqErr_1 = _o.sent();
                    if (started)
                        throw groqErr_1;
                    console.warn("[StreamChat] Groq provider failed or exhausted, attempting OpenCode Zen (Muse Spark 1.3 Free) fallback...", groqErr_1);
                    _o.label = 17;
                case 17:
                    _o.trys.push([17, 35, , 36]);
                    _o.label = 18;
                case 18:
                    _o.trys.push([18, 28, 29, 34]);
                    _d = true, _e = __asyncValues((0, zen_js_1.streamZenChat)(messages, tools, db));
                    _o.label = 19;
                case 19: return [4 /*yield*/, __await(_e.next())];
                case 20:
                    if (!(_f = _o.sent(), _k = _f.done, !_k)) return [3 /*break*/, 27];
                    _m = _f.value;
                    _d = false;
                    chunk = _m;
                    if (!(chunk.kind === "delta" || chunk.kind === "tool")) return [3 /*break*/, 23];
                    return [4 /*yield*/, __await(chunk)];
                case 21: return [4 /*yield*/, _o.sent()];
                case 22:
                    _o.sent();
                    return [3 /*break*/, 26];
                case 23:
                    if (!(chunk.kind === "done")) return [3 /*break*/, 26];
                    return [4 /*yield*/, __await({ kind: "done", finish: chunk.finish })];
                case 24: return [4 /*yield*/, _o.sent()];
                case 25:
                    _o.sent();
                    _o.label = 26;
                case 26:
                    _d = true;
                    return [3 /*break*/, 19];
                case 27: return [3 /*break*/, 34];
                case 28:
                    e_5_1 = _o.sent();
                    e_5 = { error: e_5_1 };
                    return [3 /*break*/, 34];
                case 29:
                    _o.trys.push([29, , 32, 33]);
                    if (!(!_d && !_k && (_l = _e.return))) return [3 /*break*/, 31];
                    return [4 /*yield*/, __await(_l.call(_e))];
                case 30:
                    _o.sent();
                    _o.label = 31;
                case 31: return [3 /*break*/, 33];
                case 32:
                    if (e_5) throw e_5.error;
                    return [7 /*endfinally*/];
                case 33: return [7 /*endfinally*/];
                case 34: return [3 /*break*/, 36];
                case 35:
                    zenErr_1 = _o.sent();
                    console.error("[StreamChat] Zen fallback also failed:", zenErr_1);
                    throw groqErr_1;
                case 36: return [3 /*break*/, 37];
                case 37: return [2 /*return*/];
            }
        });
    });
}
