import type { DatabaseAdapter } from "../db/database.js";
export type LlmProvider = "groq" | "zen";
export interface ApiKeyRecord {
    id: number;
    provider: LlmProvider;
    masked_key: string;
    label: string | null;
    is_active: boolean;
    fail_count: number;
    last_used_at: string | null;
    created_at: string;
}
export declare function maskKey(raw: string): string;
export declare function registerKeyPoolDb(db: DatabaseAdapter): void;
export declare function getKeyList(db?: DatabaseAdapter): {
    keys: ApiKeyRecord[];
    envFallbacks: {
        groqConfigured: boolean;
        zenConfigured: boolean;
    };
};
export declare function addApiKey(provider: LlmProvider, keyValue: string, label?: string, db?: DatabaseAdapter): {
    id: number;
    provider: LlmProvider;
    masked_key: string;
};
export declare function deleteApiKey(id: number, db?: DatabaseAdapter): void;
export declare function toggleApiKey(id: number, db?: DatabaseAdapter): boolean;
export interface CandidateKey {
    key: string;
    dbId?: number;
    source: "db" | "env";
}
export declare function getCandidatesForProvider(provider: LlmProvider, db?: DatabaseAdapter): CandidateKey[];
export declare function recordKeySuccess(candidate: CandidateKey, db?: DatabaseAdapter): void;
export declare function recordKeyFailure(candidate: CandidateKey, err: unknown, db?: DatabaseAdapter): void;
export declare function runWithRotation<YieldT>(provider: LlmProvider, streamFn: (apiKey: string) => AsyncGenerator<YieldT>, db?: DatabaseAdapter): AsyncGenerator<YieldT>;
