"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.maskKey = maskKey;
exports.registerKeyPoolDb = registerKeyPoolDb;
exports.getKeyList = getKeyList;
exports.addApiKey = addApiKey;
exports.deleteApiKey = deleteApiKey;
exports.toggleApiKey = toggleApiKey;
exports.getCandidatesForProvider = getCandidatesForProvider;
exports.recordKeySuccess = recordKeySuccess;
exports.recordKeyFailure = recordKeyFailure;
exports.runWithRotation = runWithRotation;
var env_js_1 = require("../env.js");
function maskKey(raw) {
    if (raw.length <= 12) {
        return "****";
    }
    return "".concat(raw.slice(0, 7), "...").concat(raw.slice(-6));
}
var activeDb = null;
function registerKeyPoolDb(db) {
    activeDb = db;
}
function getKeyList(db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    var rows = targetDb
        ? targetDb.all("SELECT id, provider, key_value, label, is_active, fail_count, last_used_at, created_at FROM api_keys ORDER BY id DESC")
        : [];
    return {
        keys: rows.map(function (r) { return ({
            id: r.id,
            provider: r.provider,
            masked_key: maskKey(r.key_value),
            label: r.label,
            is_active: r.is_active === 1,
            fail_count: r.fail_count,
            last_used_at: r.last_used_at,
            created_at: r.created_at,
        }); }),
        envFallbacks: {
            groqConfigured: Boolean(env_js_1.env.groqApiKey),
            zenConfigured: Boolean(env_js_1.env.zenApiKey),
        },
    };
}
function addApiKey(provider, keyValue, label, db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    if (!targetDb) {
        throw new Error("Database not initialized for key pool");
    }
    var cleanKey = keyValue.trim();
    if (cleanKey === "") {
        throw new Error("Key cannot be empty");
    }
    var res = targetDb.run("INSERT INTO api_keys (provider, key_value, label, is_active, fail_count) VALUES (?, ?, ?, 1, 0)", provider, cleanKey, (label === null || label === void 0 ? void 0 : label.trim()) || null);
    return {
        id: Number(res.lastInsertRowid),
        provider: provider,
        masked_key: maskKey(cleanKey),
    };
}
function deleteApiKey(id, db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    if (!targetDb) {
        throw new Error("Database not initialized for key pool");
    }
    targetDb.run("DELETE FROM api_keys WHERE id = ?", id);
}
function toggleApiKey(id, db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    if (!targetDb) {
        throw new Error("Database not initialized for key pool");
    }
    var existing = targetDb.get("SELECT is_active FROM api_keys WHERE id = ?", id);
    if (!existing) {
        throw new Error("Key not found");
    }
    var next = existing.is_active === 1 ? 0 : 1;
    targetDb.run("UPDATE api_keys SET is_active = ? WHERE id = ?", next, id);
    return next === 1;
}
function getCandidatesForProvider(provider, db) {
    var e_1, _a;
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    var candidates = [];
    if (targetDb) {
        try {
            var rows = targetDb.all("SELECT id, key_value FROM api_keys WHERE provider = ? AND is_active = 1 ORDER BY fail_count ASC, id ASC", provider);
            try {
                for (var rows_1 = __values(rows), rows_1_1 = rows_1.next(); !rows_1_1.done; rows_1_1 = rows_1.next()) {
                    var r = rows_1_1.value;
                    if (r.key_value && r.key_value.trim() !== "") {
                        candidates.push({ key: r.key_value.trim(), dbId: r.id, source: "db" });
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (rows_1_1 && !rows_1_1.done && (_a = rows_1.return)) _a.call(rows_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        catch (_b) {
            // Table might not exist yet during bootstrap
        }
    }
    // Fallback to env key
    var envKey = provider === "groq" ? env_js_1.env.groqApiKey : env_js_1.env.zenApiKey;
    if (envKey && !candidates.some(function (c) { return c.key === envKey; })) {
        candidates.push({ key: envKey, source: "env" });
    }
    return candidates;
}
function recordKeySuccess(candidate, db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    if (candidate.dbId && targetDb) {
        try {
            targetDb.run("UPDATE api_keys SET last_used_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?", candidate.dbId);
        }
        catch (_a) {
            // ignore
        }
    }
}
function recordKeyFailure(candidate, err, db) {
    var targetDb = db !== null && db !== void 0 ? db : activeDb;
    console.warn("[KeyPool] Failure with ".concat(candidate.source, " key (").concat(maskKey(candidate.key), "):"), err instanceof Error ? err.message : String(err));
    if (candidate.dbId && targetDb) {
        try {
            targetDb.run("UPDATE api_keys SET fail_count = fail_count + 1 WHERE id = ?", candidate.dbId);
        }
        catch (_a) {
            // ignore
        }
    }
}
function runWithRotation(provider, streamFn, db) {
    return __asyncGenerator(this, arguments, function runWithRotation_1() {
        var candidates, lastError, i, candidate, yieldedAny, generator, _a, generator_1, generator_1_1, chunk, e_2_1, err_1;
        var _b, e_2, _c, _d;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    candidates = getCandidatesForProvider(provider, db);
                    if (candidates.length === 0) {
                        throw new Error("No API keys configured for provider: ".concat(provider));
                    }
                    lastError = null;
                    i = 0;
                    _e.label = 1;
                case 1:
                    if (!(i < candidates.length)) return [3 /*break*/, 20];
                    candidate = candidates[i];
                    yieldedAny = false;
                    _e.label = 2;
                case 2:
                    _e.trys.push([2, 18, , 19]);
                    generator = streamFn(candidate.key);
                    _e.label = 3;
                case 3:
                    _e.trys.push([3, 10, 11, 16]);
                    _a = true, generator_1 = (e_2 = void 0, __asyncValues(generator));
                    _e.label = 4;
                case 4: return [4 /*yield*/, __await(generator_1.next())];
                case 5:
                    if (!(generator_1_1 = _e.sent(), _b = generator_1_1.done, !_b)) return [3 /*break*/, 9];
                    _d = generator_1_1.value;
                    _a = false;
                    chunk = _d;
                    yieldedAny = true;
                    return [4 /*yield*/, __await(chunk)];
                case 6: return [4 /*yield*/, _e.sent()];
                case 7:
                    _e.sent();
                    _e.label = 8;
                case 8:
                    _a = true;
                    return [3 /*break*/, 4];
                case 9: return [3 /*break*/, 16];
                case 10:
                    e_2_1 = _e.sent();
                    e_2 = { error: e_2_1 };
                    return [3 /*break*/, 16];
                case 11:
                    _e.trys.push([11, , 14, 15]);
                    if (!(!_a && !_b && (_c = generator_1.return))) return [3 /*break*/, 13];
                    return [4 /*yield*/, __await(_c.call(generator_1))];
                case 12:
                    _e.sent();
                    _e.label = 13;
                case 13: return [3 /*break*/, 15];
                case 14:
                    if (e_2) throw e_2.error;
                    return [7 /*endfinally*/];
                case 15: return [7 /*endfinally*/];
                case 16:
                    recordKeySuccess(candidate, db);
                    return [4 /*yield*/, __await(void 0)];
                case 17: return [2 /*return*/, _e.sent()];
                case 18:
                    err_1 = _e.sent();
                    lastError = err_1;
                    recordKeyFailure(candidate, err_1, db);
                    if (yieldedAny) {
                        // Already started streaming chunks to client; rethrow so we don't duplicate conversation parts mid-stream
                        throw err_1;
                    }
                    // If no chunks yielded yet and more keys available, loop to next key!
                    if (i < candidates.length - 1) {
                        console.log("[KeyPool] Auto-switching ".concat(provider, " to next available key in pool..."));
                    }
                    return [3 /*break*/, 19];
                case 19:
                    i++;
                    return [3 /*break*/, 1];
                case 20: throw lastError instanceof Error
                    ? lastError
                    : new Error("All ".concat(provider, " API keys exhausted or failed"));
            }
        });
    });
}
