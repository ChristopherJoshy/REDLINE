import type { DatabaseAdapter } from "../db/database.js";
export interface TokenMetrics {
    totalTokens: number;
    promptTokens: number;
    completionTokens: number;
    currentTps: number;
    peakTps: number;
    averageTps: number;
    totalRequests: number;
}
declare class TokenTracker {
    private totalPromptTokens;
    private totalCompletionTokens;
    private totalRequests;
    private peakTps;
    private totalActiveStreamDurationMs;
    private recentDeltas;
    private db;
    private initialized;
    init(db: DatabaseAdapter): void;
    /**
     * Record a streamed token delta chunk to feed the live rolling TPS calculator.
     */
    recordTokenDelta(count?: number): void;
    /**
     * Record completed stream token usage (exact or estimated) and active duration.
     */
    recordStreamUsage(prompt: number, completion: number, durationMs?: number): void;
    private saveState;
    private pruneOldDeltas;
    private computeCurrentTps;
    getMetrics(): TokenMetrics;
}
export declare const tokenTracker: TokenTracker;
export {};
