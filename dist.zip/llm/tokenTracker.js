"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tokenTracker = void 0;
var TokenTracker = /** @class */ (function () {
    function TokenTracker() {
        this.totalPromptTokens = 0;
        this.totalCompletionTokens = 0;
        this.totalRequests = 0;
        this.peakTps = 0;
        this.totalActiveStreamDurationMs = 0;
        this.recentDeltas = [];
        this.db = null;
        this.initialized = false;
    }
    TokenTracker.prototype.init = function (db) {
        this.db = db;
        if (this.initialized)
            return;
        this.initialized = true;
        try {
            var promptRow = db.get("SELECT value FROM game_state WHERE key = 'total_prompt_tokens'");
            var compRow = db.get("SELECT value FROM game_state WHERE key = 'total_completion_tokens'");
            var reqRow = db.get("SELECT value FROM game_state WHERE key = 'total_llm_requests'");
            var peakRow = db.get("SELECT value FROM game_state WHERE key = 'peak_tps'");
            if (promptRow === null || promptRow === void 0 ? void 0 : promptRow.value)
                this.totalPromptTokens = parseInt(promptRow.value, 10) || 0;
            if (compRow === null || compRow === void 0 ? void 0 : compRow.value)
                this.totalCompletionTokens = parseInt(compRow.value, 10) || 0;
            if (reqRow === null || reqRow === void 0 ? void 0 : reqRow.value)
                this.totalRequests = parseInt(reqRow.value, 10) || 0;
            if (peakRow === null || peakRow === void 0 ? void 0 : peakRow.value)
                this.peakTps = parseFloat(peakRow.value) || 0;
        }
        catch (_a) {
            // game_state table might be empty or initializing
        }
    };
    /**
     * Record a streamed token delta chunk to feed the live rolling TPS calculator.
     */
    TokenTracker.prototype.recordTokenDelta = function (count) {
        if (count === void 0) { count = 1; }
        var now = Date.now();
        this.recentDeltas.push({ timestamp: now, count: count });
        this.pruneOldDeltas(now);
        var tps = this.computeCurrentTps(now);
        if (tps > this.peakTps) {
            this.peakTps = tps;
            this.saveState("peak_tps", this.peakTps.toString());
        }
    };
    /**
     * Record completed stream token usage (exact or estimated) and active duration.
     */
    TokenTracker.prototype.recordStreamUsage = function (prompt, completion, durationMs) {
        this.totalPromptTokens += Math.max(0, prompt);
        this.totalCompletionTokens += Math.max(0, completion);
        this.totalRequests += 1;
        if (durationMs && durationMs > 0) {
            this.totalActiveStreamDurationMs += durationMs;
        }
        this.saveState("total_prompt_tokens", this.totalPromptTokens.toString());
        this.saveState("total_completion_tokens", this.totalCompletionTokens.toString());
        this.saveState("total_llm_requests", this.totalRequests.toString());
    };
    TokenTracker.prototype.saveState = function (key, value) {
        if (!this.db)
            return;
        try {
            this.db.run("INSERT INTO game_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", key, value);
        }
        catch (_a) {
            // Non-blocking in background telemetry
        }
    };
    TokenTracker.prototype.pruneOldDeltas = function (now) {
        var _a, _b;
        // 5-second sliding window for current TPS calculation
        var cutoff = now - 5000;
        while (this.recentDeltas.length > 0 && ((_b = (_a = this.recentDeltas[0]) === null || _a === void 0 ? void 0 : _a.timestamp) !== null && _b !== void 0 ? _b : 0) < cutoff) {
            this.recentDeltas.shift();
        }
    };
    TokenTracker.prototype.computeCurrentTps = function (now) {
        var _a, _b;
        if (now === void 0) { now = Date.now(); }
        this.pruneOldDeltas(now);
        if (this.recentDeltas.length < 2) {
            return 0;
        }
        // Check if generation was idle for > 2000ms
        var lastDelta = this.recentDeltas[this.recentDeltas.length - 1];
        if (!lastDelta || now - lastDelta.timestamp > 2000) {
            return 0;
        }
        var oldest = (_b = (_a = this.recentDeltas[0]) === null || _a === void 0 ? void 0 : _a.timestamp) !== null && _b !== void 0 ? _b : now;
        var durationSec = (now - oldest) / 1000;
        if (durationSec < 0.2)
            return 0;
        var totalTokensInWindow = this.recentDeltas.reduce(function (sum, d) { return sum + d.count; }, 0);
        var tps = totalTokensInWindow / durationSec;
        return Math.round(tps * 10) / 10;
    };
    TokenTracker.prototype.getMetrics = function () {
        var now = Date.now();
        var currentTps = this.computeCurrentTps(now);
        var totalTokens = this.totalPromptTokens + this.totalCompletionTokens;
        var avgTps = this.totalActiveStreamDurationMs > 0
            ? Math.round((this.totalCompletionTokens / (this.totalActiveStreamDurationMs / 1000)) * 10) / 10
            : 0;
        return {
            totalTokens: totalTokens,
            promptTokens: this.totalPromptTokens,
            completionTokens: this.totalCompletionTokens,
            currentTps: currentTps,
            peakTps: this.peakTps,
            averageTps: avgTps,
            totalRequests: this.totalRequests,
        };
    };
    return TokenTracker;
}());
exports.tokenTracker = new TokenTracker();
