import type { DatabaseAdapter } from "../db/database.js";
import type { ChatMessage, StreamYield, ToolDef } from "./groq.js";
export declare function streamZenChatWithKey(apiKey: string, messages: ChatMessage[], tools: ToolDef[]): AsyncGenerator<StreamYield & {
    reasoning?: string;
}>;
export declare function streamZenChat(messages: ChatMessage[], tools: ToolDef[], db?: DatabaseAdapter): AsyncGenerator<StreamYield & {
    reasoning?: string;
}>;
