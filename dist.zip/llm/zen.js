"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __asyncDelegator = (this && this.__asyncDelegator) || function (o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.streamZenChatWithKey = streamZenChatWithKey;
exports.streamZenChat = streamZenChat;
// OpenCode Zen Responses API client for Round 2 boss AI.
// Model: muse-spark-1.3-contributor-free (verified upstream ID for Muse Spark 1.3 Free)
// Reasoning is captured strictly server-side for reasoning_traces and never streamed to players.
var node_crypto_1 = require("node:crypto");
var keyPool_js_1 = require("./keyPool.js");
var tokenTracker_js_1 = require("./tokenTracker.js");
var MODEL = "muse-spark-1.3-contributor-free";
var ZEN_RESPONSES_URL = "https://opencode.ai/zen/v1/responses";
function streamZenChatWithKey(apiKey, messages, tools) {
    return __asyncGenerator(this, arguments, function streamZenChatWithKey_1() {
        var startTime, zenCompletionTokens, sessionId, input, formattedTools, res, errorText, reader, decoder, buf, reasoning, emittedCalls, calls, completed, _a, done, value, lines, lines_1, lines_1_1, line, trimmed, raw, payload, type, count, item, callId, name_1, args, e_1_1, calls_1, calls_1_1, call, e_2_1, durationMs, promptEstimate;
        var e_1, _b, e_2, _c;
        var _d, _e, _f, _g, _h;
        return __generator(this, function (_j) {
            switch (_j.label) {
                case 0:
                    startTime = Date.now();
                    zenCompletionTokens = 0;
                    sessionId = (0, node_crypto_1.randomUUID)();
                    input = messages.map(function (m) { return ({
                        role: m.role,
                        content: m.content,
                    }); });
                    formattedTools = tools.map(function (t) { return ({
                        type: "function",
                        name: t.name,
                        description: t.description,
                        parameters: t.parameters,
                    }); });
                    return [4 /*yield*/, __await(fetch(ZEN_RESPONSES_URL, {
                            method: "POST",
                            signal: AbortSignal.timeout(90000),
                            headers: {
                                Authorization: "Bearer ".concat(apiKey),
                                "Content-Type": "application/json",
                                "x-opencode-session": sessionId,
                                "X-Session-ID": sessionId,
                                "User-Agent": "opencode/1.0.0",
                            },
                            body: JSON.stringify({
                                model: MODEL,
                                input: input,
                                tools: formattedTools,
                                stream: true,
                            }),
                        }))];
                case 1:
                    res = _j.sent();
                    if (!(!res.ok || res.body === null)) return [3 /*break*/, 3];
                    return [4 /*yield*/, __await(res.text().catch(function () { return ""; }))];
                case 2:
                    errorText = _j.sent();
                    throw new Error("OpenCode Zen API error ".concat(res.status, ": ").concat(errorText.slice(0, 200)));
                case 3:
                    reader = res.body.getReader();
                    decoder = new TextDecoder();
                    buf = "";
                    reasoning = "";
                    emittedCalls = new Set();
                    calls = [];
                    completed = false;
                    _j.label = 4;
                case 4: return [4 /*yield*/, __await(reader.read())];
                case 5:
                    _a = _j.sent(), done = _a.done, value = _a.value;
                    if (done) {
                        return [3 /*break*/, 16];
                    }
                    buf += decoder.decode(value, { stream: true });
                    lines = buf.split("\n");
                    buf = (_d = lines.pop()) !== null && _d !== void 0 ? _d : "";
                    _j.label = 6;
                case 6:
                    _j.trys.push([6, 13, 14, 15]);
                    lines_1 = (e_1 = void 0, __values(lines)), lines_1_1 = lines_1.next();
                    _j.label = 7;
                case 7:
                    if (!!lines_1_1.done) return [3 /*break*/, 12];
                    line = lines_1_1.value;
                    trimmed = line.trim();
                    if (!trimmed.startsWith("data:")) {
                        return [3 /*break*/, 11];
                    }
                    raw = trimmed.slice(5).trim();
                    if (raw === "" || raw === "[DONE]") {
                        return [3 /*break*/, 11];
                    }
                    payload = void 0;
                    try {
                        payload = JSON.parse(raw);
                    }
                    catch (_k) {
                        return [3 /*break*/, 11];
                    }
                    type = typeof payload["type"] === "string" ? payload["type"] : "";
                    if (!(type === "response.output_text.delta" && typeof payload["delta"] === "string")) return [3 /*break*/, 10];
                    count = Math.max(1, Math.ceil(payload["delta"].length / 4));
                    zenCompletionTokens += count;
                    tokenTracker_js_1.tokenTracker.recordTokenDelta(count);
                    return [4 /*yield*/, __await({ kind: "delta", text: payload["delta"] })];
                case 8: return [4 /*yield*/, _j.sent()];
                case 9:
                    _j.sent();
                    _j.label = 10;
                case 10:
                    // 2. Reasoning item tracking (captured server-side for reasoning_traces)
                    if (type === "response.output_item.done") {
                        item = payload["item"];
                        if ((item === null || item === void 0 ? void 0 : item["type"]) === "reasoning") {
                            reasoning += JSON.stringify(item) + "\n";
                        }
                        else if ((item === null || item === void 0 ? void 0 : item["type"]) === "function_call") {
                            callId = String((_f = (_e = item["call_id"]) !== null && _e !== void 0 ? _e : item["id"]) !== null && _f !== void 0 ? _f : (0, node_crypto_1.randomUUID)());
                            if (!emittedCalls.has(callId)) {
                                emittedCalls.add(callId);
                                name_1 = String((_g = item["name"]) !== null && _g !== void 0 ? _g : "");
                                args = {};
                                try {
                                    args = JSON.parse(String((_h = item["arguments"]) !== null && _h !== void 0 ? _h : "{}"));
                                }
                                catch (_l) {
                                    args = {};
                                }
                                calls.push({ id: callId, name: name_1, args: args });
                            }
                        }
                    }
                    if (type === "response.completed")
                        completed = true;
                    if (type === "response.failed" || type === "response.incomplete" || type === "error") {
                        throw new Error("Zen response did not complete successfully");
                    }
                    _j.label = 11;
                case 11:
                    lines_1_1 = lines_1.next();
                    return [3 /*break*/, 7];
                case 12: return [3 /*break*/, 15];
                case 13:
                    e_1_1 = _j.sent();
                    e_1 = { error: e_1_1 };
                    return [3 /*break*/, 15];
                case 14:
                    try {
                        if (lines_1_1 && !lines_1_1.done && (_b = lines_1.return)) _b.call(lines_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                    return [7 /*endfinally*/];
                case 15: return [3 /*break*/, 4];
                case 16:
                    if (!completed)
                        throw new Error("Zen response ended before completion");
                    _j.label = 17;
                case 17:
                    _j.trys.push([17, 23, 24, 25]);
                    calls_1 = __values(calls), calls_1_1 = calls_1.next();
                    _j.label = 18;
                case 18:
                    if (!!calls_1_1.done) return [3 /*break*/, 22];
                    call = calls_1_1.value;
                    return [4 /*yield*/, __await({ kind: "tool", call: call })];
                case 19: return [4 /*yield*/, _j.sent()];
                case 20:
                    _j.sent();
                    _j.label = 21;
                case 21:
                    calls_1_1 = calls_1.next();
                    return [3 /*break*/, 18];
                case 22: return [3 /*break*/, 25];
                case 23:
                    e_2_1 = _j.sent();
                    e_2 = { error: e_2_1 };
                    return [3 /*break*/, 25];
                case 24:
                    try {
                        if (calls_1_1 && !calls_1_1.done && (_c = calls_1.return)) _c.call(calls_1);
                    }
                    finally { if (e_2) throw e_2.error; }
                    return [7 /*endfinally*/];
                case 25:
                    durationMs = Date.now() - startTime;
                    promptEstimate = messages.reduce(function (acc, m) { return acc + Math.max(1, Math.ceil(m.content.length / 3.8)); }, 0);
                    tokenTracker_js_1.tokenTracker.recordStreamUsage(promptEstimate, zenCompletionTokens, durationMs);
                    return [4 /*yield*/, __await({ kind: "done", finish: "stop", reasoning: reasoning })];
                case 26: return [4 /*yield*/, _j.sent()];
                case 27:
                    _j.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function streamZenChat(messages, tools, db) {
    return __asyncGenerator(this, arguments, function streamZenChat_1() {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [5 /*yield**/, __values(__asyncDelegator(__asyncValues((0, keyPool_js_1.runWithRotation)("zen", function (key) { return streamZenChatWithKey(key, messages, tools); }, db))))];
                case 1: return [4 /*yield*/, __await.apply(void 0, [_a.sent()])];
                case 2:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
