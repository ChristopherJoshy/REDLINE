"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_test_1 = require("node:test");
var zen_js_1 = require("./zen.js");
function response(events) {
    return new Response(events.map(function (event) { return "data: ".concat(JSON.stringify(event), "\n\n"); }).join(""));
}
(0, node_test_1.test)("Zen emits each completed function once and keeps reasoning out of dialogue", function (t) { return __awaiter(void 0, void 0, void 0, function () {
    var events, _a, _b, _c, event_1, e_1_1;
    var _d, e_1, _e, _f;
    return __generator(this, function (_g) {
        switch (_g.label) {
            case 0:
                t.mock.method(globalThis, "fetch", function () { return __awaiter(void 0, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        return [2 /*return*/, response([
                                { type: "response.output_text.delta", delta: "A promise." },
                                { type: "response.function_call_arguments.done", item_id: "item1", name: "handover_item", arguments: '{"authenticity":"real"}' },
                                { type: "response.output_item.done", item: { type: "function_call", id: "item1", call_id: "call1", name: "handover_item", arguments: '{"authenticity":"real"}' } },
                                { type: "response.output_item.done", item: { type: "reasoning", summary: "private" } },
                                { type: "response.completed" },
                            ])];
                    });
                }); });
                events = [];
                _g.label = 1;
            case 1:
                _g.trys.push([1, 6, 7, 12]);
                _a = true, _b = __asyncValues((0, zen_js_1.streamZenChatWithKey)("test", [], []));
                _g.label = 2;
            case 2: return [4 /*yield*/, _b.next()];
            case 3:
                if (!(_c = _g.sent(), _d = _c.done, !_d)) return [3 /*break*/, 5];
                _f = _c.value;
                _a = false;
                event_1 = _f;
                events.push(event_1);
                _g.label = 4;
            case 4:
                _a = true;
                return [3 /*break*/, 2];
            case 5: return [3 /*break*/, 12];
            case 6:
                e_1_1 = _g.sent();
                e_1 = { error: e_1_1 };
                return [3 /*break*/, 12];
            case 7:
                _g.trys.push([7, , 10, 11]);
                if (!(!_a && !_d && (_e = _b.return))) return [3 /*break*/, 9];
                return [4 /*yield*/, _e.call(_b)];
            case 8:
                _g.sent();
                _g.label = 9;
            case 9: return [3 /*break*/, 11];
            case 10:
                if (e_1) throw e_1.error;
                return [7 /*endfinally*/];
            case 11: return [7 /*endfinally*/];
            case 12:
                strict_1.default.equal(events.filter(function (event) { return event.kind === "tool"; }).length, 1);
                strict_1.default.deepEqual(events.filter(function (event) { return event.kind === "delta"; }), [{ kind: "delta", text: "A promise." }]);
                return [2 /*return*/];
        }
    });
}); });
(0, node_test_1.test)("failed or truncated Zen streams cannot award pending tools", function (t) { return __awaiter(void 0, void 0, void 0, function () {
    var _loop_1, _a, _b, terminal, e_2_1;
    var e_2, _c;
    return __generator(this, function (_d) {
        switch (_d.label) {
            case 0:
                _loop_1 = function (terminal) {
                    var tools;
                    return __generator(this, function (_e) {
                        switch (_e.label) {
                            case 0:
                                t.mock.method(globalThis, "fetch", function () { return __awaiter(void 0, void 0, void 0, function () {
                                    return __generator(this, function (_a) {
                                        return [2 /*return*/, response(__spreadArray([
                                                { type: "response.output_item.done", item: { type: "function_call", call_id: "call1", name: "handover_item", arguments: '{"authenticity":"real"}' } }
                                            ], __read(terminal), false))];
                                    });
                                }); });
                                tools = [];
                                return [4 /*yield*/, strict_1.default.rejects(function () { return __awaiter(void 0, void 0, void 0, function () {
                                        var _a, _b, _c, event_2, e_3_1;
                                        var _d, e_3, _e, _f;
                                        return __generator(this, function (_g) {
                                            switch (_g.label) {
                                                case 0:
                                                    _g.trys.push([0, 5, 6, 11]);
                                                    _a = true, _b = __asyncValues((0, zen_js_1.streamZenChatWithKey)("test", [], []));
                                                    _g.label = 1;
                                                case 1: return [4 /*yield*/, _b.next()];
                                                case 2:
                                                    if (!(_c = _g.sent(), _d = _c.done, !_d)) return [3 /*break*/, 4];
                                                    _f = _c.value;
                                                    _a = false;
                                                    event_2 = _f;
                                                    if (event_2.kind === "tool")
                                                        tools.push(event_2);
                                                    _g.label = 3;
                                                case 3:
                                                    _a = true;
                                                    return [3 /*break*/, 1];
                                                case 4: return [3 /*break*/, 11];
                                                case 5:
                                                    e_3_1 = _g.sent();
                                                    e_3 = { error: e_3_1 };
                                                    return [3 /*break*/, 11];
                                                case 6:
                                                    _g.trys.push([6, , 9, 10]);
                                                    if (!(!_a && !_d && (_e = _b.return))) return [3 /*break*/, 8];
                                                    return [4 /*yield*/, _e.call(_b)];
                                                case 7:
                                                    _g.sent();
                                                    _g.label = 8;
                                                case 8: return [3 /*break*/, 10];
                                                case 9:
                                                    if (e_3) throw e_3.error;
                                                    return [7 /*endfinally*/];
                                                case 10: return [7 /*endfinally*/];
                                                case 11: return [2 /*return*/];
                                            }
                                        });
                                    }); })];
                            case 1:
                                _e.sent();
                                strict_1.default.equal(tools.length, 0);
                                t.mock.restoreAll();
                                return [2 /*return*/];
                        }
                    });
                };
                _d.label = 1;
            case 1:
                _d.trys.push([1, 6, 7, 8]);
                _a = __values([[], [{ type: "response.failed" }], [{ type: "response.incomplete" }]]), _b = _a.next();
                _d.label = 2;
            case 2:
                if (!!_b.done) return [3 /*break*/, 5];
                terminal = _b.value;
                return [5 /*yield**/, _loop_1(terminal)];
            case 3:
                _d.sent();
                _d.label = 4;
            case 4:
                _b = _a.next();
                return [3 /*break*/, 2];
            case 5: return [3 /*break*/, 8];
            case 6:
                e_2_1 = _d.sent();
                e_2 = { error: e_2_1 };
                return [3 /*break*/, 8];
            case 7:
                try {
                    if (_b && !_b.done && (_c = _a.return)) _c.call(_a);
                }
                finally { if (e_2) throw e_2.error; }
                return [7 /*endfinally*/];
            case 8: return [2 /*return*/];
        }
    });
}); });
