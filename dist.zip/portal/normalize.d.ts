export declare function variants(raw: string): string[];
export declare function hashAnswer(folded: string, pepper: string): string;
export declare function matchesAny(forms: string[], expectedFolded: string, pepper: string): boolean;
export declare function foldAnswer(answer: string): string;
