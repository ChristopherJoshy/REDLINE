"use strict";
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.variants = variants;
exports.hashAnswer = hashAnswer;
exports.matchesAny = matchesAny;
exports.foldAnswer = foldAnswer;
// Submission normalization pipeline: strip -> decode -> un-reverse ->
// NFKC fold + leet-fold + acrostic/delimiter-strip. Silent fail: callers never
// learn which normalization fired.
var node_crypto_1 = require("node:crypto");
var LEET = { "0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "8": "b", "@": "a", "$": "s", "!": "i" };
function rot13(s) {
    return s.replace(/[a-zA-Z]/g, function (c) {
        var base = c <= "Z" ? 65 : 97;
        return String.fromCharCode(((c.charCodeAt(0) - base + 13) % 26) + base);
    });
}
function tryBase64(s) {
    if (!/^[A-Za-z0-9+/=]+$/.test(s) || s.length % 4 !== 0 || s.length < 8) {
        return [];
    }
    try {
        var decoded = Buffer.from(s, "base64").toString("utf8");
        if (!/^[\x20-\x7E\s]+$/.test(decoded)) {
            return [];
        }
        return [decoded];
    }
    catch (_a) {
        return [];
    }
}
function tryHex(s) {
    if (!/^[0-9a-fA-F]+$/.test(s) || s.length % 2 !== 0 || s.length < 8) {
        return [];
    }
    try {
        var decoded = Buffer.from(s, "hex").toString("utf8");
        if (!/^[\x20-\x7E\s]+$/.test(decoded)) {
            return [];
        }
        return [decoded];
    }
    catch (_a) {
        return [];
    }
}
function tryUrl(s) {
    if (!s.includes("%")) {
        return [];
    }
    try {
        var decoded = decodeURIComponent(s);
        return decoded === s ? [] : [decoded];
    }
    catch (_a) {
        return [];
    }
}
function unreverse(s) {
    var rev = __spreadArray([], __read(s), false).reverse().join("");
    return rev === s ? [] : [rev];
}
function acrostic(s) {
    var words = s.split(/[\s|,/;:_-]+/).filter(function (w) { return w !== ""; });
    if (words.length < 3) {
        return [];
    }
    return [words.map(function (w) { return w[0]; }).join("")];
}
function fold(s) {
    var leeted = s
        .normalize("NFKC")
        .toLowerCase()
        .split("")
        .map(function (c) { var _a; return (_a = LEET[c]) !== null && _a !== void 0 ? _a : c; })
        .join("");
    return leeted.replace(/[^a-z0-9]/g, "");
}
// Every normalized form of a raw submission. Check BOTH raw and decoded.
function variants(raw) {
    var e_1, _a, e_2, _b;
    var stripped = raw.trim();
    if (stripped === "") {
        return [];
    }
    var out = new Set([fold(stripped)]);
    var decoded = __spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray([], __read(tryBase64(stripped)), false), __read(tryHex(stripped)), false), __read(tryUrl(stripped)), false), [
        rot13(stripped)
    ], false), __read(unreverse(stripped)), false), __read(acrostic(stripped)), false);
    try {
        for (var decoded_1 = __values(decoded), decoded_1_1 = decoded_1.next(); !decoded_1_1.done; decoded_1_1 = decoded_1.next()) {
            var d = decoded_1_1.value;
            out.add(fold(d));
            try {
                for (var _c = (e_2 = void 0, __values(unreverse(d))), _d = _c.next(); !_d.done; _d = _c.next()) {
                    var r = _d.value;
                    out.add(fold(r));
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_d && !_d.done && (_b = _c.return)) _b.call(_c);
                }
                finally { if (e_2) throw e_2.error; }
            }
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (decoded_1_1 && !decoded_1_1.done && (_a = decoded_1.return)) _a.call(decoded_1);
        }
        finally { if (e_1) throw e_1.error; }
    }
    return __spreadArray([], __read(out), false);
}
function hashAnswer(folded, pepper) {
    return (0, node_crypto_1.createHash)("sha256").update(pepper + ":" + folded, "utf8").digest("hex");
}
// Hash-compare so the pipeline never early-exits on a named check.
function matchesAny(forms, expectedFolded, pepper) {
    var e_3, _a;
    var want = hashAnswer(expectedFolded, pepper);
    var hit = false;
    try {
        for (var forms_1 = __values(forms), forms_1_1 = forms_1.next(); !forms_1_1.done; forms_1_1 = forms_1.next()) {
            var form = forms_1_1.value;
            var got = hashAnswer(form, pepper);
            if (got.length === want.length && timingEqual(got, want)) {
                hit = true;
            }
        }
    }
    catch (e_3_1) { e_3 = { error: e_3_1 }; }
    finally {
        try {
            if (forms_1_1 && !forms_1_1.done && (_a = forms_1.return)) _a.call(forms_1);
        }
        finally { if (e_3) throw e_3.error; }
    }
    return hit;
}
function timingEqual(a, b) {
    if (a.length !== b.length) {
        return false;
    }
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
        diff |= (a.charCodeAt(i) ^ b.charCodeAt(i));
    }
    return diff === 0;
}
function foldAnswer(answer) {
    return fold(answer.trim());
}
