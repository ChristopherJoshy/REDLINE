"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_DURATION_SECS = exports.COUNTDOWN_MS = void 0;
exports.roundState = roundState;
exports.roundSnapshot = roundSnapshot;
exports.startRound = startRound;
exports.stopRound = stopRound;
exports.pauseRound = pauseRound;
exports.resumeRound = resumeRound;
exports.extendRound = extendRound;
exports.reduceRound = reduceRound;
exports.COUNTDOWN_MS = 30000;
exports.MAX_DURATION_SECS = 86400;
function schedule(db, round) {
    var _a;
    var raw = (_a = db.get("SELECT value FROM game_state WHERE key = ?", "round".concat(round, "_schedule"))) === null || _a === void 0 ? void 0 : _a.value;
    if (!raw)
        return null;
    try {
        var value = JSON.parse(raw);
        if (typeof value.startsAt !== "string" || typeof value.endsAt !== "string" || typeof value.stopped !== "boolean")
            return null;
        var start = Date.parse(value.startsAt);
        var end = Date.parse(value.endsAt);
        return Number.isFinite(start) && Number.isFinite(end) && end > start ? value : null;
    }
    catch (_b) {
        return null;
    }
}
function save(db, round, value) {
    db.run("INSERT INTO game_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", "round".concat(round, "_schedule"), JSON.stringify(value));
}
function roundState(db, round, now) {
    if (now === void 0) { now = Date.now(); }
    var saved = schedule(db, round);
    if (!saved)
        return { status: "not_started", startsAt: null, endsAt: null, durationSecs: 0 };
    var start = Date.parse(saved.startsAt);
    var end = Date.parse(saved.endsAt);
    var status = saved.stopped || now >= end ? "ended" : now < start ? "countdown" : "active";
    if (status === "active" && saved.pausedAt)
        status = "paused";
    return {
        status: status,
        startsAt: saved.startsAt,
        endsAt: saved.endsAt,
        durationSecs: (end - start) / 1000,
    };
}
function roundSnapshot(db, now) {
    if (now === void 0) { now = Date.now(); }
    return { serverNow: new Date(now).toISOString(), round1: roundState(db, 1, now), round2: roundState(db, 2, now) };
}
function startRound(db, round, durationSecs, now) {
    if (now === void 0) { now = Date.now(); }
    if (!Number.isInteger(durationSecs) || durationSecs < 1 || durationSecs > exports.MAX_DURATION_SECS)
        throw new Error("Duration must be between 1 second and 24 hours.");
    save(db, round, { startsAt: new Date(now + exports.COUNTDOWN_MS).toISOString(), endsAt: new Date(now + exports.COUNTDOWN_MS + durationSecs * 1000).toISOString(), stopped: false, pausedAt: null });
    return roundState(db, round, now);
}
function stopRound(db, round) {
    var saved = schedule(db, round);
    if (saved)
        save(db, round, __assign(__assign({}, saved), { stopped: true, pausedAt: null }));
}
function pauseRound(db, round, now) {
    if (now === void 0) { now = Date.now(); }
    var saved = schedule(db, round);
    var state = roundState(db, round, now);
    if (!saved || state.status !== "active")
        throw new Error("Round ".concat(round, " is not active, cannot pause."));
    save(db, round, __assign(__assign({}, saved), { pausedAt: new Date(now).toISOString() }));
    return roundState(db, round, now);
}
function resumeRound(db, round, now) {
    if (now === void 0) { now = Date.now(); }
    var saved = schedule(db, round);
    var state = roundState(db, round, now);
    if (!saved || state.status !== "paused" || !saved.pausedAt)
        throw new Error("Round ".concat(round, " is not paused."));
    var pausedMs = now - Date.parse(saved.pausedAt);
    var newEndsAt = new Date(Date.parse(saved.endsAt) + pausedMs);
    save(db, round, __assign(__assign({}, saved), { pausedAt: null, endsAt: newEndsAt.toISOString() }));
    return roundState(db, round, now);
}
function extendRound(db, round, addSecs, now) {
    if (now === void 0) { now = Date.now(); }
    if (!Number.isInteger(addSecs) || addSecs < 1 || addSecs > exports.MAX_DURATION_SECS)
        throw new Error("Extension must be between 1 second and 24 hours.");
    var saved = schedule(db, round);
    var state = roundState(db, round, now);
    if (!saved || (state.status !== "active" && state.status !== "paused"))
        throw new Error("Round ".concat(round, " is not active or paused."));
    if ((Date.parse(saved.endsAt) - Date.parse(saved.startsAt)) / 1000 + addSecs > exports.MAX_DURATION_SECS)
        throw new Error("Total duration cannot exceed 24 hours.");
    save(db, round, __assign(__assign({}, saved), { endsAt: new Date(Date.parse(saved.endsAt) + addSecs * 1000).toISOString() }));
    return roundState(db, round, now);
}
function reduceRound(db, round, reduceSecs, now) {
    if (now === void 0) { now = Date.now(); }
    if (!Number.isInteger(reduceSecs) || reduceSecs < 1)
        throw new Error("Reduction must be positive.");
    var saved = schedule(db, round);
    var state = roundState(db, round, now);
    if (!saved || (state.status !== "active" && state.status !== "paused"))
        throw new Error("Round ".concat(round, " is not active or paused."));
    var currentEnd = Date.parse(saved.endsAt);
    var newEnd = currentEnd - reduceSecs * 1000;
    if (newEnd < now)
        newEnd = now; // Can't reduce past current time
    save(db, round, __assign(__assign({}, saved), { endsAt: new Date(newEnd).toISOString() }));
    return roundState(db, round, now);
}
