"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_path_1 = require("node:path");
var node_test_1 = require("node:test");
var database_js_1 = require("../db/database.js");
var state_js_1 = require("./state.js");
(0, node_test_1.test)("round clock keeps countdown separate from playable duration", function () {
    var _a, _b, _c;
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        var now = Date.parse("2026-09-15T10:00:00.000Z");
        var scheduled = (0, state_js_1.startRound)(db, 1, 300, now);
        strict_1.default.equal(scheduled.status, "countdown");
        strict_1.default.equal(Date.parse((_a = scheduled.startsAt) !== null && _a !== void 0 ? _a : "") - now, state_js_1.COUNTDOWN_MS);
        strict_1.default.equal(Date.parse((_b = scheduled.endsAt) !== null && _b !== void 0 ? _b : "") - Date.parse((_c = scheduled.startsAt) !== null && _c !== void 0 ? _c : ""), 300000);
        strict_1.default.equal((0, state_js_1.roundState)(db, 1, now + state_js_1.COUNTDOWN_MS).status, "active");
        strict_1.default.equal((0, state_js_1.roundState)(db, 1, now + state_js_1.COUNTDOWN_MS + 299999).status, "active");
        strict_1.default.equal((0, state_js_1.roundState)(db, 1, now + state_js_1.COUNTDOWN_MS + 300000).status, "ended");
    }
    finally {
        db.close();
    }
});
(0, node_test_1.test)("only active rounds extend and a stop ends immediately", function () {
    var db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
    try {
        var now_1 = Date.parse("2026-09-15T10:00:00.000Z");
        (0, state_js_1.startRound)(db, 1, 120, now_1 - state_js_1.COUNTDOWN_MS);
        var extended = (0, state_js_1.extendRound)(db, 1, 60, now_1);
        strict_1.default.equal(extended.durationSecs, 180);
        strict_1.default.equal((0, state_js_1.roundState)(db, 1, now_1 + 179999).status, "active");
        (0, state_js_1.stopRound)(db, 1);
        strict_1.default.equal((0, state_js_1.roundState)(db, 1, now_1).status, "ended");
        strict_1.default.throws(function () { return (0, state_js_1.extendRound)(db, 1, 60, now_1); });
    }
    finally {
        db.close();
    }
});
