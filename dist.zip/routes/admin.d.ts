import type { FastifyInstance } from "fastify";
import type { DatabaseAdapter } from "../db/database.js";
import type { Bus } from "../ws/bus.js";
import type { BotLocks } from "../chat/locks.js";
export declare function registerAdminRoutes(app: FastifyInstance, db: DatabaseAdapter, root: string, bus?: Bus, locks?: BotLocks): void;
