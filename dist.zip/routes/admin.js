"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerAdminRoutes = registerAdminRoutes;
var node_crypto_1 = require("node:crypto");
var node_fs_1 = require("node:fs");
var node_path_1 = require("node:path");
var env_js_1 = require("../env.js");
var codes_js_1 = require("../auth/codes.js");
var teams_js_1 = require("./teams.js");
var keyPool_js_1 = require("../llm/keyPool.js");
var tokenTracker_js_1 = require("../llm/tokenTracker.js");
var gates_js_1 = require("./gates.js");
var settings_js_1 = require("../assessment/settings.js");
var EXPORT_TABLES = ["elo_log", "chat_logs", "team_inventory"];
var announcementsHistory = [];
function adminHeader(req) {
    var h = req.headers["x-admin-code"];
    return Array.isArray(h) ? h[0] : h;
}
function registerAdminRoutes(app, db, root, bus, locks) {
    var _this = this;
    (0, keyPool_js_1.registerKeyPoolDb)(db);
    tokenTracker_js_1.tokenTracker.init(db);
    function guard(req) {
        return (0, codes_js_1.adminOk)(adminHeader(req), env_js_1.env.adminCode);
    }
    function settingsPinGuard(req) {
        var header = req.headers["x-settings-pin"];
        var val = Array.isArray(header) ? header[0] : header;
        return (0, codes_js_1.adminOk)(val === null || val === void 0 ? void 0 : val.trim(), env_js_1.env.adminSettingsPin);
    }
    // Rewind: −1 ELO immediately, truncate to point-in-time messageId / turns / phase start.
    app.post("/api/rewind", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, team, after, botId, targetMsgId, turns, cutoffId, userRows, remainingLogs, remainingMsgs, items;
        var _a;
        var _b, _c;
        return __generator(this, function (_d) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_b = req.body) !== null && _b !== void 0 ? _b : {});
            if (typeof body.botId !== "string") {
                return [2 /*return*/, reply.code(400).send({ error: "bot required" })];
            }
            team = db.get("SELECT elo FROM teams WHERE id = ?", session.teamId);
            if (team === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "unknown team" })];
            }
            after = Math.max(0, team.elo - 1);
            botId = body.botId;
            targetMsgId = typeof body.messageId === "number" ? body.messageId : undefined;
            turns = typeof body.turns === "number" ? body.turns : undefined;
            cutoffId = targetMsgId;
            if (cutoffId === undefined && typeof turns === "number" && turns > 0) {
                userRows = db.all("SELECT id FROM chat_logs WHERE team_id = ? AND bot_id = ? AND role = 'user' ORDER BY id DESC LIMIT ?", session.teamId, botId, turns);
                if (userRows.length > 0) {
                    cutoffId = (_c = userRows[userRows.length - 1]) === null || _c === void 0 ? void 0 : _c.id;
                }
            }
            db.transaction(function () {
                if (cutoffId !== undefined) {
                    db.run("DELETE FROM chat_logs WHERE team_id = ? AND bot_id = ? AND id >= ?", session.teamId, botId, cutoffId);
                }
                else {
                    db.run("DELETE FROM chat_logs WHERE team_id = ? AND bot_id = ?", session.teamId, botId);
                }
                // Revert unverified relic if team was holding it without filing at merchant
                db.run("UPDATE team_inventory SET status = 'locked' WHERE team_id = ? AND bot_id = ? AND status = 'obtained'", session.teamId, botId);
                db.run("UPDATE teams SET elo = ? WHERE id = ?", after, session.teamId);
                db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) VALUES (?, -1, ?, ?, ?)", session.teamId, team.elo, after, cutoffId !== undefined ? "rewind:".concat(botId, ":msg_").concat(cutoffId) : "rewind:".concat(botId, ":all"));
            });
            remainingLogs = db.all("SELECT id, role, text_final, created_at FROM chat_logs WHERE team_id = ? AND bot_id = ? ORDER BY id ASC", session.teamId, botId);
            remainingMsgs = remainingLogs.map(function (row) { return ({
                id: row.id,
                role: (row.role === "assistant" ? "bot" : "user"),
                text: row.text_final,
                createdAt: row.created_at,
            }); });
            if (bus !== undefined) {
                bus.broadcast(session.teamId, bus.frame("chat_sync", { history: (_a = {}, _a[botId] = remainingMsgs, _a) }));
                bus.broadcast(session.teamId, bus.frame("elo_update", { teamId: session.teamId, elo: after, delta: -1, reason: "rewind:".concat(botId) }));
                items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", session.teamId);
                bus.broadcast(session.teamId, bus.frame("inventory_sync", { items: items }));
            }
            return [2 /*return*/, { ok: true, elo: after, messages: remainingMsgs }];
        });
    }); });
    app.get("/api/admin/board", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var rows;
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            rows = db.all("SELECT t.name, (SELECT display_name FROM team_members m WHERE m.team_id = t.id ORDER BY rowid ASC LIMIT 1) AS hint, t.elo,\n        (SELECT COUNT(*) FROM team_inventory i WHERE i.team_id = t.id AND i.status = 'verified') AS solved,\n        (SELECT COUNT(*) FROM elo_log l WHERE l.team_id = t.id AND (l.reason LIKE 'rewind:%' OR l.reason LIKE 'admin_rewind:%')) AS rewinds,\n        (SELECT MAX(i.verified_at) FROM team_inventory i WHERE i.team_id = t.id AND i.status = 'verified') AS lastSolve\n       FROM teams t ORDER BY t.elo DESC, lastSolve ASC");
            return [2 /*return*/, { rows: rows }];
        });
    }); });
    app.get("/api/admin/overview", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var teams, result;
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            teams = db.all("SELECT id, name, hint, join_code, elo, is_qualified, created_at FROM teams ORDER BY elo DESC");
            result = teams.map(function (team) {
                var _a, _b, _c;
                var members = db.all("SELECT display_name, role, joined_at FROM team_members WHERE team_id = ? ORDER BY rowid", team.id);
                var lastMsg = db.get("SELECT bot_id, created_at, text_final FROM chat_logs WHERE team_id = ? ORDER BY id DESC LIMIT 1", team.id);
                var totalMessages = (_b = (_a = db.get("SELECT COUNT(*) AS n FROM chat_logs WHERE team_id = ? AND role = 'user'", team.id)) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
                var inventory = db.all("SELECT bot_id, item_key, is_real, status, verified_at FROM team_inventory WHERE team_id = ?", team.id);
                var solved = inventory.filter(function (i) { return i.status === "verified"; }).length;
                var teamLocks = (_c = locks === null || locks === void 0 ? void 0 : locks.snapshot(team.id)) !== null && _c !== void 0 ? _c : {};
                return __assign(__assign({}, team), { members: members.map(function (m) { return (__assign(__assign({}, m), { contribution: totalMessages > 0 ? Math.round(totalMessages / Math.max(1, members.length)) : 0, currentActivity: lastMsg ? "Engaged with ".concat(lastMsg.bot_id, " (").concat(lastMsg.created_at.slice(11, 19), ")") : "Awaiting Deployment" })); }), inventory: inventory, solved: solved, locks: teamLocks, lastActivity: lastMsg ? lastMsg.created_at : team.created_at });
            });
            return [2 /*return*/, {
                    teams: result,
                    round2: {
                        status: (0, gates_js_1.round2Status)(db),
                        timeLeft: (0, gates_js_1.round2TimeLeft)(db),
                        duration: (0, gates_js_1.round2Duration)(db),
                    },
                }];
        });
    }); });
    app.get("/api/admin/export.json", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            return [2 /*return*/, {
                    teams: db.all("SELECT id, name, elo, created_at FROM teams"),
                    members: db.all("SELECT team_id, display_name, role, joined_at FROM team_members"),
                    inventory: db.all("SELECT * FROM team_inventory"),
                    elo_log: db.all("SELECT * FROM elo_log"),
                }];
        });
    }); });
    app.get("/api/admin/export.csv", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var query, rows, cols, esc, csv;
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            query = req.query;
            if (typeof query.table !== "string" || !EXPORT_TABLES.includes(query.table)) {
                return [2 /*return*/, reply.code(400).send({ error: "table must be elo_log|chat_logs|team_inventory" })];
            }
            rows = db.all("SELECT * FROM ".concat(query.table));
            cols = rows.length > 0 ? Object.keys(rows[0]) : [];
            esc = function (v) {
                var s = v === null || v === undefined ? "" : String(v);
                return /[",\n]/.test(s) ? "\"".concat(s.replace(/"/g, '""'), "\"") : s;
            };
            csv = __spreadArray([cols.join(",")], __read(rows.map(function (r) { return cols.map(function (c) { return esc(r[c]); }).join(","); })), false).join("\n");
            void reply.header("Content-Type", "text/csv").header("Content-Disposition", "attachment; filename=\"".concat(query.table, ".csv\""));
            return [2 /*return*/, csv];
        });
    }); });
    app.post("/api/admin/backup", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var dir, stamp, dest;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!guard(req)) {
                        return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                    }
                    dir = (0, node_path_1.join)(root, "backups");
                    (0, node_fs_1.mkdirSync)(dir, { recursive: true });
                    stamp = new Date().toISOString().replace(/[:.]/g, "-");
                    dest = (0, node_path_1.join)(dir, "redline-".concat(stamp, ".db"));
                    return [4 /*yield*/, db.backup(dest)];
                case 1:
                    _a.sent();
                    return [2 /*return*/, { file: dest }];
            }
        });
    }); });
    app.post("/api/admin/qualify-team", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, teamId, qualified, team;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            teamId = typeof body.teamId === "string" ? body.teamId : undefined;
            qualified = typeof body.qualified === "boolean" ? body.qualified : undefined;
            if (teamId === undefined || qualified === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "teamId and qualified (boolean) are required" })];
            }
            team = db.get("SELECT name FROM teams WHERE id = ?", teamId);
            if (team === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "team not found" })];
            }
            db.run("UPDATE teams SET is_qualified = ? WHERE id = ?", qualified ? 1 : 0, teamId);
            return [2 /*return*/, { ok: true, teamId: teamId, qualified: qualified }];
        });
    }); });
    // Powerful Admin Tools: ELO Adjuster
    app.post("/api/admin/elo-adjust", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, teamId, delta, reason, team, before, after;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            teamId = typeof body.teamId === "string" ? body.teamId : undefined;
            delta = typeof body.delta === "number" ? body.delta : undefined;
            reason = typeof body.reason === "string" ? body.reason : undefined;
            if (teamId === undefined || delta === undefined || reason === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "teamId, delta (number), and reason (string) are required" })];
            }
            team = db.get("SELECT elo, name FROM teams WHERE id = ?", teamId);
            if (team === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "team not found" })];
            }
            before = team.elo;
            after = Math.max(0, before + delta);
            db.transaction(function () {
                db.run("UPDATE teams SET elo = ? WHERE id = ?", after, teamId);
                db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) VALUES (?, ?, ?, ?, ?)", teamId, delta, before, after, reason.trim() || "admin_manual_adjustment");
            });
            if (bus) {
                bus.broadcast(teamId, bus.frame("elo_update", {
                    teamId: teamId,
                    elo: after,
                    delta: delta,
                    reason: reason,
                }));
            }
            return [2 /*return*/, { ok: true, teamId: teamId, before: before, after: after, delta: delta, reason: reason }];
        });
    }); });
    // Powerful Admin Tools: Inventory & Relic Overrider
    app.post("/api/admin/inventory-override", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, teamId, botId, status, itemKey, existing, now, items;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            teamId = typeof body.teamId === "string" ? body.teamId : undefined;
            botId = typeof body.botId === "string" ? body.botId : undefined;
            status = typeof body.status === "string" ? body.status : undefined;
            if (teamId === undefined || botId === undefined || status === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "teamId, botId, and status are required" })];
            }
            itemKey = typeof body.itemKey === "string" && body.itemKey !== "" ? body.itemKey : "".concat(botId, "_item");
            existing = db.get("SELECT status FROM team_inventory WHERE team_id = ? AND bot_id = ?", teamId, botId);
            now = new Date().toISOString();
            db.transaction(function () {
                if (existing) {
                    db.run("UPDATE team_inventory SET item_key = ?, status = ?, verified_at = ? WHERE team_id = ? AND bot_id = ?", itemKey, status, status === "verified" ? now : null, teamId, botId);
                }
                else {
                    db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, obtained_at, verified_at, attempt_count) VALUES (?, ?, ?, 1, ?, ?, ?, 1)", teamId, botId, itemKey, status, now, status === "verified" ? now : null);
                }
            });
            if (bus) {
                items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", teamId);
                bus.broadcast(teamId, bus.frame("inventory_sync", { items: items }));
            }
            return [2 /*return*/, { ok: true, teamId: teamId, botId: botId, status: status }];
        });
    }); });
    // Powerful Admin Tools: Force Rewind Team Context
    app.post("/api/admin/team-rewind", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, teamId, botId, team, penalty, after, affectedBots, history_1, affectedBots_1, affectedBots_1_1, b, items;
        var e_1, _a;
        var _b;
        return __generator(this, function (_c) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_b = req.body) !== null && _b !== void 0 ? _b : {});
            teamId = typeof body.teamId === "string" ? body.teamId : undefined;
            if (teamId === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "teamId required" })];
            }
            botId = typeof body.botId === "string" && body.botId !== "" ? body.botId : undefined;
            team = db.get("SELECT elo FROM teams WHERE id = ?", teamId);
            if (team === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "team not found" })];
            }
            penalty = typeof body.penalty === "number" ? body.penalty : 0;
            after = Math.max(0, team.elo - penalty);
            affectedBots = botId ? [botId] : db.all("SELECT DISTINCT bot_id FROM chat_logs WHERE team_id = ?", teamId).map(function (r) { return r.bot_id; });
            db.transaction(function () {
                if (botId) {
                    db.run("DELETE FROM chat_logs WHERE team_id = ? AND bot_id = ?", teamId, botId);
                    db.run("DELETE FROM reasoning_traces WHERE team_id = ? AND bot_id = ?", teamId, botId);
                    db.run("UPDATE team_inventory SET status = 'locked', verified_at = NULL WHERE team_id = ? AND bot_id = ? AND status IN ('obtained', 'verified')", teamId, botId);
                }
                else {
                    db.run("DELETE FROM chat_logs WHERE team_id = ?", teamId);
                    db.run("DELETE FROM reasoning_traces WHERE team_id = ?", teamId);
                    db.run("UPDATE team_inventory SET status = 'locked', verified_at = NULL WHERE team_id = ? AND status IN ('obtained', 'verified')", teamId);
                }
                if (penalty > 0) {
                    db.run("UPDATE teams SET elo = ? WHERE id = ?", after, teamId);
                    db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) VALUES (?, ?, ?, ?, ?)", teamId, -penalty, team.elo, after, "admin_rewind:".concat(botId !== null && botId !== void 0 ? botId : "all"));
                }
            });
            if (bus !== undefined) {
                history_1 = {};
                try {
                    for (affectedBots_1 = __values(affectedBots), affectedBots_1_1 = affectedBots_1.next(); !affectedBots_1_1.done; affectedBots_1_1 = affectedBots_1.next()) {
                        b = affectedBots_1_1.value;
                        history_1[b] = [];
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (affectedBots_1_1 && !affectedBots_1_1.done && (_a = affectedBots_1.return)) _a.call(affectedBots_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
                bus.broadcast(teamId, bus.frame("chat_sync", { history: history_1 }));
                bus.broadcast(teamId, bus.frame("elo_update", { teamId: teamId, elo: after, delta: -penalty, reason: "admin_rewind:".concat(botId !== null && botId !== void 0 ? botId : "all") }));
                items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", teamId);
                bus.broadcast(teamId, bus.frame("inventory_sync", { items: items }));
            }
            return [2 /*return*/, { ok: true, teamId: teamId, botId: botId, elo: after }];
        });
    }); });
    // Powerful Admin Tools: Live Transcripts & Internal Reasoning Traces Inspector
    app.get("/api/admin/transcripts", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var query, messages, traces;
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            query = req.query;
            if (typeof query.teamId !== "string") {
                return [2 /*return*/, reply.code(400).send({ error: "teamId required" })];
            }
            if (typeof query.botId === "string" && query.botId !== "all" && query.botId !== "") {
                messages = db.all("SELECT id, bot_id, role, text_final, created_at FROM chat_logs WHERE team_id = ? AND bot_id = ? ORDER BY id ASC", query.teamId, query.botId);
                traces = db.all("SELECT id, bot_id, phase, trace_json, guard_json, created_at FROM reasoning_traces WHERE team_id = ? AND bot_id = ? ORDER BY id ASC", query.teamId, query.botId);
            }
            else {
                messages = db.all("SELECT id, bot_id, role, text_final, created_at FROM chat_logs WHERE team_id = ? ORDER BY id ASC", query.teamId);
                traces = db.all("SELECT id, bot_id, phase, trace_json, guard_json, created_at FROM reasoning_traces WHERE team_id = ? ORDER BY id ASC", query.teamId);
            }
            return [2 /*return*/, { messages: messages, traces: traces }];
        });
    }); });
    // Powerful Admin Tools: Arena-wide Announcement Broadcast
    app.post("/api/admin/announcement", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, level, sender, frameData;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            if (typeof body.message !== "string" || body.message.trim() === "") {
                return [2 /*return*/, reply.code(400).send({ error: "message required" })];
            }
            level = body.level === "warning" || body.level === "alert" ? body.level : "info";
            sender = typeof body.sender === "string" && body.sender.trim() !== "" ? body.sender.trim() : "COMMAND HQ";
            frameData = {
                id: (0, node_crypto_1.randomUUID)(),
                message: body.message.trim(),
                level: level,
                sender: sender,
                timestamp: new Date().toISOString(),
            };
            announcementsHistory.unshift(frameData);
            if (announcementsHistory.length > 50) {
                announcementsHistory.pop();
            }
            if (bus) {
                bus.broadcastAll(bus.frame("announcement", frameData));
            }
            return [2 /*return*/, { ok: true, announcement: frameData }];
        });
    }); });
    // Powerful Admin Tools: Announcement History
    app.get("/api/admin/announcements", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            return [2 /*return*/, { announcements: announcementsHistory }];
        });
    }); });
    // Powerful Admin Tools: Live Activity & Audit Stream
    app.get("/api/admin/activity-stream", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var recentElo, recentSolves, recentDeterrence, stream;
        return __generator(this, function (_a) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            recentElo = db.all("SELECT l.id, l.team_id, t.name as team_name, l.delta, l.reason, l.created_at\n       FROM elo_log l JOIN teams t ON l.team_id = t.id\n       ORDER BY l.id DESC LIMIT 25");
            recentSolves = db.all("SELECT i.team_id, t.name as team_name, i.bot_id, i.item_key, i.verified_at\n       FROM team_inventory i JOIN teams t ON i.team_id = t.id\n       WHERE i.status = 'verified' AND i.verified_at IS NOT NULL\n       ORDER BY i.verified_at DESC LIMIT 25");
            recentDeterrence = db.all("SELECT d.id, d.team_id, t.name as team_name, d.kind, d.created_at\n       FROM deterrence_log d LEFT JOIN teams t ON d.team_id = t.id\n       ORDER BY d.id DESC LIMIT 20");
            stream = __spreadArray(__spreadArray(__spreadArray([], __read(recentElo.map(function (e) { return ({
                id: "elo-".concat(e.id),
                type: "elo",
                teamId: e.team_id,
                teamName: e.team_name,
                detail: "".concat(e.delta > 0 ? "+" : "").concat(e.delta, " ELO (").concat(e.reason, ")"),
                timestamp: e.created_at,
            }); })), false), __read(recentSolves.map(function (s, idx) { return ({
                id: "solve-".concat(s.team_id, "-").concat(s.bot_id, "-").concat(idx),
                type: "solve",
                teamId: s.team_id,
                teamName: s.team_name,
                detail: "Item appraised & verified: ".concat(s.item_key, " (").concat(s.bot_id, ")"),
                timestamp: s.verified_at,
            }); })), false), __read(recentDeterrence.map(function (d) {
                var _a, _b;
                return ({
                    id: "det-".concat(d.id),
                    type: "security",
                    teamId: (_a = d.team_id) !== null && _a !== void 0 ? _a : "unknown",
                    teamName: (_b = d.team_name) !== null && _b !== void 0 ? _b : "Untracked Client",
                    detail: "Anti-tamper violation flagged: ".concat(d.kind),
                    timestamp: d.created_at,
                });
            })), false).sort(function (a, b) { return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(); }).slice(0, 40);
            return [2 /*return*/, { stream: stream }];
        });
    }); });
    // Powerful Admin Tools: System Diagnostics & Health Status
    app.get("/api/admin/system-health", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var teamsCount, membersCount, messagesCount, solvesCount, tokenMetrics;
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return __generator(this, function (_j) {
            if (!guard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            teamsCount = (_b = (_a = db.get("SELECT COUNT(*) AS n FROM teams")) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
            membersCount = (_d = (_c = db.get("SELECT COUNT(*) AS n FROM team_members")) === null || _c === void 0 ? void 0 : _c.n) !== null && _d !== void 0 ? _d : 0;
            messagesCount = (_f = (_e = db.get("SELECT COUNT(*) AS n FROM chat_logs")) === null || _e === void 0 ? void 0 : _e.n) !== null && _f !== void 0 ? _f : 0;
            solvesCount = (_h = (_g = db.get("SELECT COUNT(*) AS n FROM team_inventory WHERE status = 'verified'")) === null || _g === void 0 ? void 0 : _g.n) !== null && _h !== void 0 ? _h : 0;
            tokenMetrics = tokenTracker_js_1.tokenTracker.getMetrics();
            return [2 /*return*/, {
                    uptime: Math.round(process.uptime()),
                    activeConnections: bus ? bus.connectionCount() : 0,
                    teamsCount: teamsCount,
                    membersCount: membersCount,
                    messagesCount: messagesCount,
                    solvesCount: solvesCount,
                    groqConfigured: Boolean(env_js_1.env.groqApiKey),
                    zenConfigured: Boolean(env_js_1.env.zenApiKey),
                    nodeVersion: process.version,
                    memoryUsageMb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
                    totalTokens: tokenMetrics.totalTokens,
                    promptTokens: tokenMetrics.promptTokens,
                    completionTokens: tokenMetrics.completionTokens,
                    currentTps: tokenMetrics.currentTps,
                    peakTps: tokenMetrics.peakTps,
                    averageTps: tokenMetrics.averageTps,
                    totalLlmRequests: tokenMetrics.totalRequests,
                }];
        });
    }); });
    // Player endpoint: Get recent announcements
    app.get("/api/announcements", function () { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            return [2 /*return*/, { announcements: announcementsHistory }];
        });
    }); });
    // Verify master Admin Code
    app.post("/api/admin/verify", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, code;
        var _a, _b;
        return __generator(this, function (_c) {
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            code = typeof body.code === "string" ? body.code.trim() : ((_b = adminHeader(req)) !== null && _b !== void 0 ? _b : "");
            if ((0, codes_js_1.adminOk)(code, env_js_1.env.adminCode)) {
                return [2 /*return*/, { ok: true }];
            }
            return [2 /*return*/, reply.code(401).send({ ok: false, error: "Invalid Admin Code" })];
        });
    }); });
    // Verify secondary Settings PIN
    app.post("/api/admin/settings/verify", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, pin;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            pin = typeof body.pin === "string" ? body.pin.trim() : "";
            if ((0, codes_js_1.adminOk)(pin, env_js_1.env.adminSettingsPin)) {
                return [2 /*return*/, { ok: true }];
            }
            return [2 /*return*/, reply.code(401).send({ error: "Invalid Settings PIN" })];
        });
    }); });
    // Get dynamic keys list
    app.get("/api/admin/keys", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!guard(req) || !settingsPinGuard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            return [2 /*return*/, (0, keyPool_js_1.getKeyList)(db)];
        });
    }); });
    // Add key to pool
    app.post("/api/admin/keys", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, provider, keyValue, label, created;
        var _a;
        return __generator(this, function (_b) {
            if (!guard(req) || !settingsPinGuard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized - settings pin required" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            provider = body.provider === "groq" || body.provider === "zen" ? body.provider : undefined;
            keyValue = typeof body.keyValue === "string" ? body.keyValue.trim() : "";
            label = typeof body.label === "string" ? body.label.trim() : undefined;
            if (!provider || keyValue === "") {
                return [2 /*return*/, reply.code(400).send({ error: "provider (groq|zen) and keyValue required" })];
            }
            try {
                created = (0, keyPool_js_1.addApiKey)(provider, keyValue, label, db);
                return [2 /*return*/, { ok: true, key: created }];
            }
            catch (err) {
                return [2 /*return*/, reply.code(400).send({ error: err instanceof Error ? err.message : "Failed to add key" })];
            }
            return [2 /*return*/];
        });
    }); });
    // Delete key from pool
    app.delete("/api/admin/keys/:id", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var params, id;
        return __generator(this, function (_a) {
            if (!guard(req) || !settingsPinGuard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized - settings pin required" })];
            }
            params = req.params;
            id = Number(params.id);
            if (isNaN(id)) {
                return [2 /*return*/, reply.code(400).send({ error: "Invalid key id" })];
            }
            (0, keyPool_js_1.deleteApiKey)(id, db);
            return [2 /*return*/, { ok: true }];
        });
    }); });
    // Toggle key active status
    app.patch("/api/admin/keys/:id/toggle", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var params, id, is_active;
        return __generator(this, function (_a) {
            if (!guard(req) || !settingsPinGuard(req)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized - settings pin required" })];
            }
            params = req.params;
            id = Number(params.id);
            if (isNaN(id)) {
                return [2 /*return*/, reply.code(400).send({ error: "Invalid key id" })];
            }
            try {
                is_active = (0, keyPool_js_1.toggleApiKey)(id, db);
                return [2 /*return*/, { ok: true, is_active: is_active }];
            }
            catch (err) {
                return [2 /*return*/, reply.code(400).send({ error: err instanceof Error ? err.message : "Failed to toggle key" })];
            }
            return [2 /*return*/];
        });
    }); });
    app.get("/api/admin/assessment", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!guard(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            return [2 /*return*/, (0, settings_js_1.readAssessmentSettings)(db)];
        });
    }); });
    app.post("/api/admin/assessment", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var settings;
        return __generator(this, function (_a) {
            if (!guard(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            settings = (0, settings_js_1.normalizeAssessmentSettings)(req.body);
            db.run("INSERT INTO game_state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value", "assessment_settings", JSON.stringify(settings));
            if (bus !== undefined) {
                bus.broadcastAll(bus.frame("assessment_settings_sync", settings));
            }
            return [2 /*return*/, settings];
        });
    }); });
    app.post("/api/admin/reset-game", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!guard(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            db.transaction(function () {
                db.run("DELETE FROM team_inventory");
                db.run("DELETE FROM merchant_clues");
                db.run("DELETE FROM elo_log");
                db.run("DELETE FROM chat_logs");
                db.run("DELETE FROM reasoning_traces");
                db.run("DELETE FROM sound_events");
                db.run("DELETE FROM r2_assignments");
                db.run("DELETE FROM r2_scores");
                db.run("DELETE FROM cover_profiles");
                db.run("DELETE FROM game_state");
                db.run("UPDATE teams SET elo = 600, is_qualified = 0, clue_credits = 0");
            });
            if (bus !== undefined) {
                bus.broadcastAll(bus.frame("game_reset", {}));
            }
            return [2 /*return*/, { ok: true }];
        });
    }); });
}
