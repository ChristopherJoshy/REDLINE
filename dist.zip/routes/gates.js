"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ROUND1_SIZE = void 0;
exports.round1Open = round1Open;
exports.vaultOpen = vaultOpen;
exports.round2Status = round2Status;
exports.round2Duration = round2Duration;
exports.round2TimeLeft = round2TimeLeft;
exports.isQualified = isQualified;
exports.isRound2Eligible = isRound2Eligible;
exports.solvedCount = solvedCount;
exports.registerGateRoutes = registerGateRoutes;
var env_js_1 = require("../env.js");
var codes_js_1 = require("../auth/codes.js");
var teams_js_1 = require("./teams.js");
var state_js_1 = require("../rounds/state.js");
exports.ROUND1_SIZE = 8;
function admin(req) {
    var h = req.headers["x-admin-code"];
    return (0, codes_js_1.adminOk)(Array.isArray(h) ? h[0] : h, env_js_1.env.adminCode);
}
function round1Open(db) { return (0, state_js_1.roundState)(db, 1).status === "active"; }
function vaultOpen(db) {
    var _a;
    return ((_a = db.get("SELECT value FROM game_state WHERE key = 'vault_open'")) === null || _a === void 0 ? void 0 : _a.value) === "1";
}
function round2Status(db) {
    var status = (0, state_js_1.roundState)(db, 2).status;
    return status === "countdown" || status === "active" ? status : "off";
}
function round2Duration(db) { return (0, state_js_1.roundState)(db, 2).durationSecs; }
function round2TimeLeft(db) {
    var state = (0, state_js_1.roundState)(db, 2);
    var end = state.status === "countdown" ? state.startsAt : state.status === "active" ? state.endsAt : null;
    return end ? Math.max(0, Math.ceil((Date.parse(end) - Date.now()) / 1000)) : 0;
}
function isQualified(db, teamId) {
    var _a;
    return ((_a = db.get("SELECT is_qualified FROM teams WHERE id = ?", teamId)) === null || _a === void 0 ? void 0 : _a.is_qualified) === 1;
}
function isRound2Eligible(db, teamId) {
    var _a;
    return ((_a = db.get("SELECT round2_eligible FROM teams WHERE id = ?", teamId)) === null || _a === void 0 ? void 0 : _a.round2_eligible) === 1;
}
function solvedCount(db, teamId) {
    var _a, _b;
    return (_b = (_a = db.get("SELECT COUNT(*) AS n FROM team_inventory WHERE team_id = ? AND status = 'verified' AND bot_id NOT IN ('itachi', 'aizen')", teamId)) === null || _a === void 0 ? void 0 : _a.n) !== null && _b !== void 0 ? _b : 0;
}
function registerGateRoutes(app, db, bus) {
    var e_1, _a;
    var _this = this;
    app.get("/api/gates", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (!session)
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            return [2 /*return*/, __assign(__assign({}, (0, state_js_1.roundSnapshot)(db)), { round1Open: round1Open(db), vaultOpen: vaultOpen(db), qualified: vaultOpen(db) && isQualified(db, session.teamId), solved: solvedCount(db, session.teamId), round1Size: exports.ROUND1_SIZE, round2Status: round2Status(db), round2TimeLeft: round2TimeLeft(db) })];
        });
    }); });
    app.get("/api/admin/rounds", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!admin(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            return [2 /*return*/, (0, state_js_1.roundSnapshot)(db)];
        });
    }); });
    var _loop_1 = function (round) {
        app.post("/api/admin/start-round".concat(round), function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            var body, now, duration, state;
            var _a;
            return __generator(this, function (_b) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
                now = Date.now();
                duration = typeof body.endsAt === "string" ? Math.floor((Date.parse(body.endsAt) - now - 30000) / 1000) : body.durationSecs;
                if (typeof duration !== "number" || !Number.isInteger(duration) || duration < 1 || duration > 86400) {
                    return [2 /*return*/, reply.code(400).send({ error: "Choose a duration from 1 second to 24 hours, or an end time after the 30-second countdown." })];
                }
                try {
                    state = db.transaction(function () {
                        var started = (0, state_js_1.startRound)(db, round, duration, now);
                        if (round === 2) {
                            db.run("INSERT INTO elo_log (team_id, delta, before_rating, after_rating, reason) SELECT id, 600 - elo, elo, 600, 'round2_start_reset' FROM teams");
                            db.run("UPDATE teams SET elo = 600, round2_eligible = 0");
                            // Set eligible teams
                            if (Array.isArray(body.selectedTeamIds) && body.selectedTeamIds.length > 0) {
                                var placeholders = body.selectedTeamIds.map(function () { return "?"; }).join(",");
                                db.run.apply(db, __spreadArray(["UPDATE teams SET round2_eligible = 1 WHERE id IN (".concat(placeholders, ")")], __read(body.selectedTeamIds), false));
                            }
                            db.run("INSERT INTO game_state (key, value) VALUES ('vault_open', '1') ON CONFLICT(key) DO UPDATE SET value = '1'");
                        }
                        return started;
                    });
                    if (round === 2 && state.startsAt)
                        bus.broadcastAll(bus.frame("round2_countdown", { endsAt: state.startsAt }));
                    return [2 /*return*/, __assign(__assign({ ok: true }, (0, state_js_1.roundSnapshot)(db)), { countdownEndsAt: state.startsAt, duration: duration })];
                }
                catch (error) {
                    return [2 /*return*/, reply.code(409).send({ error: error instanceof Error ? error.message : "Could not start round." })];
                }
                return [2 /*return*/];
            });
        }); });
        app.post("/api/admin/extend-round".concat(round), function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            var body, state;
            var _a;
            return __generator(this, function (_b) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
                if (typeof body.addSecs !== "number")
                    return [2 /*return*/, reply.code(400).send({ error: "addSecs is required." })];
                try {
                    state = db.transaction(function () { return (0, state_js_1.extendRound)(db, round, body.addSecs); });
                    if (round === 2 && state.endsAt)
                        bus.broadcastAll(bus.frame("round2_extend", { addedSecs: body.addSecs, newEndsAt: state.endsAt }));
                    return [2 /*return*/, __assign({ ok: true }, (0, state_js_1.roundSnapshot)(db))];
                }
                catch (error) {
                    return [2 /*return*/, reply.code(400).send({ error: error instanceof Error ? error.message : "Could not extend round." })];
                }
                return [2 /*return*/];
            });
        }); });
        app.post("/api/admin/reduce-round".concat(round), function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            var body, state;
            var _a;
            return __generator(this, function (_b) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
                if (typeof body.reduceSecs !== "number")
                    return [2 /*return*/, reply.code(400).send({ error: "reduceSecs is required." })];
                try {
                    state = db.transaction(function () { return (0, state_js_1.reduceRound)(db, round, body.reduceSecs); });
                    // We could emit a round2_extend with negative secs, but clients polling /api/gates will catch up anyway.
                    return [2 /*return*/, __assign({ ok: true }, (0, state_js_1.roundSnapshot)(db))];
                }
                catch (error) {
                    return [2 /*return*/, reply.code(400).send({ error: error instanceof Error ? error.message : "Could not reduce round." })];
                }
                return [2 /*return*/];
            });
        }); });
        app.post("/api/admin/pause-round".concat(round), function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                try {
                    db.transaction(function () { return (0, state_js_1.pauseRound)(db, round); });
                    return [2 /*return*/, __assign({ ok: true }, (0, state_js_1.roundSnapshot)(db))];
                }
                catch (error) {
                    return [2 /*return*/, reply.code(400).send({ error: error instanceof Error ? error.message : "Could not pause round." })];
                }
                return [2 /*return*/];
            });
        }); });
        app.post("/api/admin/resume-round".concat(round), function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                try {
                    db.transaction(function () { return (0, state_js_1.resumeRound)(db, round); });
                    return [2 /*return*/, __assign({ ok: true }, (0, state_js_1.roundSnapshot)(db))];
                }
                catch (error) {
                    return [2 /*return*/, reply.code(400).send({ error: error instanceof Error ? error.message : "Could not resume round." })];
                }
                return [2 /*return*/];
            });
        }); });
    };
    try {
        for (var _b = __values([1, 2]), _c = _b.next(); !_c.done; _c = _b.next()) {
            var round = _c.value;
            _loop_1(round);
        }
    }
    catch (e_1_1) { e_1 = { error: e_1_1 }; }
    finally {
        try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
        }
        finally { if (e_1) throw e_1.error; }
    }
    function registerStop(path, round) {
        var _this = this;
        app.post(path, function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (!admin(req))
                    return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
                (0, state_js_1.stopRound)(db, round);
                if (round === 2)
                    bus.broadcastAll(bus.frame("round2_end", { reason: "admin_stop" }));
                return [2 /*return*/, __assign({ ok: true }, (0, state_js_1.roundSnapshot)(db))];
            });
        }); });
    }
    registerStop("/api/admin/end-round1", 1);
    registerStop("/api/admin/stop-round2", 2);
    app.post("/api/admin/open-vault", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            if (!admin(req))
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            if (round2Status(db) === "off")
                return [2 /*return*/, reply.code(409).send({ error: "Start Round 2 to open the vault." })];
            db.run("INSERT INTO game_state (key, value) VALUES ('vault_open', '1') ON CONFLICT(key) DO UPDATE SET value = '1'");
            return [2 /*return*/, { ok: true }];
        });
    }); });
    app.post("/api/round2/enter", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, existing, boss;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (!session)
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            if (!isRound2Eligible(db, session.teamId))
                return [2 /*return*/, reply.code(403).send({ error: "not_selected" })];
            if (round2Status(db) !== "active" || !vaultOpen(db) || !isQualified(db, session.teamId))
                return [2 /*return*/, reply.code(403).send({ error: "vault sealed or not qualified" })];
            existing = db.get("SELECT boss FROM r2_assignments WHERE team_id = ?", session.teamId);
            if (existing)
                return [2 /*return*/, { boss: existing.boss }];
            boss = Math.random() < 0.5 ? "itachi" : "aizen";
            db.run("INSERT INTO r2_assignments (team_id, boss) VALUES (?, ?)", session.teamId, boss);
            return [2 /*return*/, { boss: boss }];
        });
    }); });
}
