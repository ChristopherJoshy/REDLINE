import type { FastifyInstance } from "fastify";
import type { Bus } from "../ws/bus.js";
import { BotLocks } from "../chat/locks.js";
export declare function registerLockRoutes(app: FastifyInstance, locks: BotLocks, bus: Bus): void;
