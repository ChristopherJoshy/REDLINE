"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerLockRoutes = registerLockRoutes;
var teams_js_1 = require("./teams.js");
var locks_js_1 = require("../chat/locks.js");
function registerLockRoutes(app, locks, bus) {
    var _this = this;
    function sync(teamId) {
        bus.broadcast(teamId, bus.frame("bot_locks", { locks: locks.snapshot(teamId) }));
    }
    // Current locks for my team (mount / re-sync).
    app.get("/api/bot-locks", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            return [2 /*return*/, { locks: locks.snapshot(session.teamId) }];
        });
    }); });
    // Take (or refresh) the lock for a mark. 409 names the holder.
    app.post("/api/bot-lock", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, botId, res;
        var _a;
        return __generator(this, function (_b) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            botId = typeof body.botId === "string" ? body.botId : "";
            if (!(0, locks_js_1.lockable)(botId)) {
                return [2 /*return*/, reply.code(400).send({ error: "bot is not lockable" })];
            }
            res = locks.acquire(session.teamId, botId, session.displayName);
            if (!res.ok) {
                return [2 /*return*/, reply.code(409).send({ error: "bot already in use", holder: res.holder })];
            }
            sync(session.teamId);
            return [2 /*return*/, { ok: true, locks: locks.snapshot(session.teamId) }];
        });
    }); });
    // Release my own lock. Releasing a mark I don't hold is a no-op.
    app.post("/api/bot-unlock", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, botId;
        var _a;
        return __generator(this, function (_b) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            botId = typeof body.botId === "string" ? body.botId : "";
            if (!(0, locks_js_1.lockable)(botId)) {
                return [2 /*return*/, reply.code(400).send({ error: "bot is not lockable" })];
            }
            if (locks.release(session.teamId, botId, session.displayName)) {
                sync(session.teamId);
            }
            return [2 /*return*/, { ok: true, locks: locks.snapshot(session.teamId) }];
        });
    }); });
}
