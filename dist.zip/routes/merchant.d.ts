import type { FastifyInstance } from "fastify";
import type { DatabaseAdapter } from "../db/database.js";
import type { Bus } from "../ws/bus.js";
export declare function registerMerchantRoutes(app: FastifyInstance, db: DatabaseAdapter, bus: Bus): void;
