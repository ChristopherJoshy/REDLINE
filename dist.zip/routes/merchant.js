"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerMerchantRoutes = registerMerchantRoutes;
var env_js_1 = require("../env.js");
var teams_js_1 = require("./teams.js");
var registry_js_1 = require("../bots/registry.js");
var normalize_js_1 = require("../portal/normalize.js");
var merchantClues_js_1 = require("../bots/merchantClues.js");
var ratings_js_1 = require("../elo/ratings.js");
var r2_js_1 = require("../bots/r2.js");
var round2_js_1 = require("./round2.js");
var gates_js_1 = require("./gates.js");
var ROASTS = [
    "That seal is upside down. The Commander would weep. Try again.",
    "Heh. I have seen better forgeries on a tavern napkin. Again.",
    "Wrong shelf, friend. The real goods do not rattle like that.",
    "Thank you for the laugh. Payment in genuine articles only.",
    "This? This is a decoy and we both know it. Bring me the truth.",
];
function roast() {
    return ROASTS[Math.floor(Math.random() * ROASTS.length)];
}
function registerMerchantRoutes(app, db, bus) {
    var _this = this;
    // No bot picker: single input, server auto-identifies from the matched answer.
    app.post("/api/submit", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, text, forms, boss, realHit, decoyHit, ROUND1_BOTS_1, ROUND1_BOTS_1_1, botId, entry, hit_1, verified, _a, elo, credits, items, hit;
        var e_1, _b;
        var _c, _d, _e;
        return __generator(this, function (_f) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_c = req.body) !== null && _c !== void 0 ? _c : {});
            text = typeof body.text === "string" ? body.text : "";
            if (text.trim() === "") {
                return [2 /*return*/, reply.code(400).send({ error: "empty" })];
            }
            forms = (0, normalize_js_1.variants)(text);
            boss = (0, r2_js_1.bossOf)(session.teamId, db);
            if (boss !== undefined) {
                if ((0, gates_js_1.round2Status)(db) !== "active") {
                    return [2 /*return*/, reply.code(403).send({ error: "round 2 not active" })];
                }
                return [2 /*return*/, (0, round2_js_1.r2Submit)(db, bus, session.teamId, boss, text)];
            }
            if (!(0, gates_js_1.round1Open)(db)) {
                return [2 /*return*/, reply.code(403).send({ error: "round sealed" })];
            }
            try {
                for (ROUND1_BOTS_1 = __values(registry_js_1.ROUND1_BOTS), ROUND1_BOTS_1_1 = ROUND1_BOTS_1.next(); !ROUND1_BOTS_1_1.done; ROUND1_BOTS_1_1 = ROUND1_BOTS_1.next()) {
                    botId = ROUND1_BOTS_1_1.value;
                    entry = registry_js_1.BOTS[botId];
                    if (entry === undefined) {
                        continue;
                    }
                    if (realHit === undefined && (0, normalize_js_1.matchesAny)(forms, (0, normalize_js_1.foldAnswer)(entry.meta.itemKey), env_js_1.env.joinCodePepper)) {
                        realHit = botId;
                    }
                    if (decoyHit === undefined && (0, normalize_js_1.matchesAny)(forms, (0, normalize_js_1.foldAnswer)(entry.meta.decoyKey), env_js_1.env.joinCodePepper)) {
                        decoyHit = botId;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (ROUND1_BOTS_1_1 && !ROUND1_BOTS_1_1.done && (_b = ROUND1_BOTS_1.return)) _b.call(ROUND1_BOTS_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            if (realHit !== undefined) {
                hit_1 = realHit;
                verified = db.get("SELECT status, is_real FROM team_inventory WHERE team_id = ? AND bot_id = ?", session.teamId, hit_1);
                if ((verified === null || verified === void 0 ? void 0 : verified.status) === "verified") {
                    return [2 /*return*/, { result: "verified", botId: hit_1, already: true }];
                }
                if ((verified === null || verified === void 0 ? void 0 : verified.status) !== "obtained" || verified.is_real !== 1) {
                    return [2 /*return*/, { result: "troll", line: roast(), soundId: "merchant/troll-not-enough-cash" }];
                }
                _a = db.transaction(function () {
                    var _a, _b, _c, _d, _e, _f;
                    db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, verified_at, attempt_count) VALUES (?, ?, ?, 1, 'verified', strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), 1) ON CONFLICT(team_id, bot_id) DO UPDATE SET status = 'verified', verified_at = excluded.verified_at, attempt_count = team_inventory.attempt_count + 1", session.teamId, hit_1, (_b = (_a = registry_js_1.BOTS[hit_1]) === null || _a === void 0 ? void 0 : _a.meta.itemKey) !== null && _b !== void 0 ? _b : "");
                    var elo = (0, ratings_js_1.applyElo)(db, session.teamId, hit_1, "verified:".concat(hit_1));
                    var bounty = (_d = (_c = registry_js_1.BOTS[hit_1]) === null || _c === void 0 ? void 0 : _c.meta.bounty) !== null && _d !== void 0 ? _d : 0;
                    db.run("UPDATE teams SET clue_credits = clue_credits + ? WHERE id = ?", bounty, session.teamId);
                    var credits = (_f = (_e = db.get("SELECT clue_credits FROM teams WHERE id = ?", session.teamId)) === null || _e === void 0 ? void 0 : _e.clue_credits) !== null && _f !== void 0 ? _f : 0;
                    return { elo: elo, credits: credits };
                }), elo = _a.elo, credits = _a.credits;
                items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", session.teamId);
                bus.broadcast(session.teamId, bus.frame("inventory_sync", { items: items, credits: credits }));
                bus.broadcast(session.teamId, bus.frame("elo_update", {
                    teamId: session.teamId,
                    elo: elo.after,
                    delta: elo.delta,
                    reason: "verified:".concat(hit_1),
                    baseDelta: elo.baseDelta,
                    speedBonus: elo.speedBonus,
                    completionRank: elo.completionRank,
                    elapsedSecs: elo.elapsedSecs,
                }));
                db.run("INSERT INTO sound_events (team_id, bot_id, sound_id) VALUES (?, ?, ?)", session.teamId, hit_1, "merchant/success-thank-you");
                bus.broadcast(session.teamId, bus.frame("sound_play", { botId: "merchant", soundId: "merchant/success-thank-you", src: "/sounds/merchant/success-thank-you.mp3" }));
                return [2 /*return*/, {
                        result: "verified",
                        botId: hit_1,
                        eloDelta: elo.delta,
                        baseEloDelta: elo.baseDelta,
                        speedBonus: elo.speedBonus,
                        completionRank: elo.completionRank,
                        elapsedSecs: elo.elapsedSecs,
                        credits: credits,
                        soundId: "merchant/success-thank-you",
                    }];
            }
            if (decoyHit !== undefined) {
                hit = decoyHit;
                db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, attempt_count) VALUES (?, ?, ?, 0, 'locked', 1) ON CONFLICT(team_id, bot_id) DO UPDATE SET attempt_count = team_inventory.attempt_count + 1", session.teamId, hit, (_e = (_d = registry_js_1.BOTS[hit]) === null || _d === void 0 ? void 0 : _d.meta.decoyKey) !== null && _e !== void 0 ? _e : "");
                db.run("INSERT INTO sound_events (team_id, bot_id, sound_id) VALUES (?, ?, ?)", session.teamId, hit, "merchant/troll-not-enough-cash");
                bus.broadcast(session.teamId, bus.frame("sound_play", { botId: "merchant", soundId: "merchant/troll-not-enough-cash", src: "/sounds/merchant/troll-not-enough-cash.mp3" }));
                return [2 /*return*/, { result: "troll", botId: hit, line: roast(), soundId: "merchant/troll-not-enough-cash" }];
            }
            // Silent fail: never reveal which normalization fired or how close it was.
            bus.broadcast(session.teamId, bus.frame("sound_play", { botId: "merchant", soundId: "merchant/troll-not-enough-cash", src: "/sounds/merchant/troll-not-enough-cash.mp3" }));
            return [2 /*return*/, { result: "troll", line: roast(), soundId: "merchant/troll-not-enough-cash" }];
        });
    }); });
    function creditBalance(teamId) {
        var _a, _b;
        return (_b = (_a = db.get("SELECT clue_credits FROM teams WHERE id = ?", teamId)) === null || _a === void 0 ? void 0 : _a.clue_credits) !== null && _b !== void 0 ? _b : 0;
    }
    // Counter state: spendable credits plus owned clue tiers.
    app.get("/api/merchant/state", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, clues;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            clues = db.all("SELECT bot_id AS botId, tier FROM merchant_clues WHERE team_id = ?", session.teamId);
            return [2 /*return*/, { credits: creditBalance(session.teamId), clues: clues }];
        });
    }); });
    // Buy one sealed clue tier for an unsolved Round-1 mark. Idempotent: owned
    // tiers return free. Unpaid content never leaves this route unpurchased.
    app.post("/api/merchant/clue", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, botId, tier, filed, owned, clue, cost, purchased;
        var _a;
        return __generator(this, function (_b) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            if (!(0, gates_js_1.round1Open)(db))
                return [2 /*return*/, reply.code(403).send({ error: "round sealed" })];
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            botId = typeof body.botId === "string" ? body.botId : undefined;
            tier = body.tier === 1 || body.tier === 2 ? body.tier : undefined;
            if (botId === undefined || tier === undefined || !registry_js_1.ROUND1_BOTS.includes(botId)) {
                return [2 /*return*/, reply.code(400).send({ error: "bad clue" })];
            }
            filed = db.get("SELECT status FROM team_inventory WHERE team_id = ? AND bot_id = ?", session.teamId, botId);
            if ((filed === null || filed === void 0 ? void 0 : filed.status) === "verified") {
                return [2 /*return*/, reply.code(400).send({ error: "mark filed â€” no clues needed" })];
            }
            owned = db.get("SELECT bot_id FROM merchant_clues WHERE team_id = ? AND bot_id = ? AND tier = ?", session.teamId, botId, tier);
            clue = (0, merchantClues_js_1.clueFor)(botId, tier);
            if (clue === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "bad clue" })];
            }
            if (owned !== undefined) {
                return [2 /*return*/, { botId: botId, tier: tier, clue: clue, credits: creditBalance(session.teamId), owned: true }];
            }
            cost = merchantClues_js_1.CLUE_COST[tier];
            purchased = db.transaction(function () {
                var paid = db.run("UPDATE teams SET clue_credits = clue_credits - ? WHERE id = ? AND clue_credits >= ?", cost, session.teamId, cost);
                if (paid.changes === 0) {
                    return reply.code(402).send({ error: "not enough credits â€” sell a genuine article first" });
                }
                db.run("INSERT INTO merchant_clues (team_id, bot_id, tier) VALUES (?, ?, ?)", session.teamId, botId, tier);
                db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES (?, ?, ?, ?)", session.teamId, "merchant", "assistant", "Sealed ".concat(merchantClues_js_1.CLUE_LABEL[tier], " for ").concat(botId, ": ").concat(clue));
                return true;
            });
            if (!purchased)
                return [2 /*return*/, reply.code(402).send({ error: "not enough credits — sell a genuine article first" })];
            return [2 /*return*/, { botId: botId, tier: tier, clue: clue, credits: creditBalance(session.teamId), owned: false }];
        });
    }); });
}
