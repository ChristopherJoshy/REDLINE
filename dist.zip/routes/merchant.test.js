"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var strict_1 = __importDefault(require("node:assert/strict"));
var node_test_1 = require("node:test");
var node_path_1 = require("node:path");
var fastify_1 = __importDefault(require("fastify"));
var database_js_1 = require("../db/database.js");
var bus_js_1 = require("../ws/bus.js");
var codes_js_1 = require("../auth/codes.js");
var inventory_js_1 = require("../bots/inventory.js");
var registry_js_1 = require("../bots/registry.js");
var state_js_1 = require("../rounds/state.js");
var merchant_js_1 = require("./merchant.js");
var round2_js_1 = require("./round2.js");
var r2_js_1 = require("../bots/r2.js");
(0, node_test_1.test)("merchant requires real possession and rewards each item only once", function () { return __awaiter(void 0, void 0, void 0, function () {
    var oldPepper, db, app, text_1, submit, _a, _b, _c, _d, _e, _f, _g, _h;
    var _j, _k;
    return __generator(this, function (_l) {
        switch (_l.label) {
            case 0:
                oldPepper = process.env["JOIN_CODE_PEPPER"];
                process.env["JOIN_CODE_PEPPER"] = "test-pepper";
                db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
                app = (0, fastify_1.default)();
                _l.label = 1;
            case 1:
                _l.trys.push([1, , 6, 8]);
                db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('team', 'Test', 'hash', 'TEST')");
                (0, state_js_1.startRound)(db, 1, 3600, Date.now() - 31000);
                (0, merchant_js_1.registerMerchantRoutes)(app, db, new bus_js_1.Bus());
                text_1 = registry_js_1.BOTS.wick.meta.itemKey;
                submit = function () { return app.inject({ method: "POST", url: "/api/submit", headers: { "x-session-token": (0, codes_js_1.makeSessionToken)("team", "Tester", "test-pepper") }, payload: { text: text_1 } }); };
                _b = (_a = strict_1.default).equal;
                return [4 /*yield*/, submit()];
            case 2:
                _b.apply(_a, [(_l.sent()).json().result, "troll"]);
                (0, inventory_js_1.awardItem)(db, "team", "wick", registry_js_1.BOTS.wick.meta.decoyKey, false);
                _d = (_c = strict_1.default).equal;
                return [4 /*yield*/, submit()];
            case 3:
                _d.apply(_c, [(_l.sent()).json().result, "troll"]);
                (0, inventory_js_1.awardItem)(db, "team", "wick", text_1, true);
                _f = (_e = strict_1.default).equal;
                return [4 /*yield*/, submit()];
            case 4:
                _f.apply(_e, [(_l.sent()).json().result, "verified"]);
                _h = (_g = strict_1.default).equal;
                return [4 /*yield*/, submit()];
            case 5:
                _h.apply(_g, [(_l.sent()).json().already, true]);
                strict_1.default.equal((_j = db.get("SELECT COUNT(*) AS n FROM elo_log")) === null || _j === void 0 ? void 0 : _j.n, 1);
                strict_1.default.equal((_k = db.get("SELECT clue_credits FROM teams")) === null || _k === void 0 ? void 0 : _k.clue_credits, registry_js_1.BOTS.wick.meta.bounty);
                return [3 /*break*/, 8];
            case 6: return [4 /*yield*/, app.close()];
            case 7:
                _l.sent();
                db.close();
                if (oldPepper === undefined)
                    delete process.env["JOIN_CODE_PEPPER"];
                else
                    process.env["JOIN_CODE_PEPPER"] = oldPepper;
                return [7 /*endfinally*/];
            case 8: return [2 /*return*/];
        }
    });
}); });
(0, node_test_1.test)("Round 2 correct words and phase alone cannot create an unearned prize", function () { return __awaiter(void 0, void 0, void 0, function () {
    var oldPepper, db, bus, i, text, _a, _b, _c, _d, _e, _f;
    var _g;
    return __generator(this, function (_h) {
        switch (_h.label) {
            case 0:
                oldPepper = process.env["JOIN_CODE_PEPPER"];
                process.env["JOIN_CODE_PEPPER"] = "test-pepper";
                db = (0, database_js_1.openDatabase)(":memory:", (0, node_path_1.join)(__dirname, "../db/schema.sql"));
                bus = new bus_js_1.Bus();
                _h.label = 1;
            case 1:
                _h.trys.push([1, , 5, 6]);
                db.run("INSERT INTO teams (id, name, join_code_hash, hint) VALUES ('team', 'Test', 'hash', 'TEST')");
                db.run("INSERT INTO r2_assignments (team_id, boss) VALUES ('team', 'itachi')");
                (0, state_js_1.startRound)(db, 2, 3600, Date.now() - 31000);
                for (i = 0; i < 6; i++)
                    db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES ('team', 'itachi', 'user', 'hello')");
                text = (0, r2_js_1.bossKeys)("itachi").itemKey;
                _b = (_a = strict_1.default).equal;
                return [4 /*yield*/, (0, round2_js_1.r2Submit)(db, bus, "team", "itachi", text)];
            case 2:
                _b.apply(_a, [(_h.sent()).result, "troll"]);
                (0, inventory_js_1.awardItem)(db, "team", "itachi", text, true);
                _d = (_c = strict_1.default).equal;
                return [4 /*yield*/, (0, round2_js_1.r2Submit)(db, bus, "team", "itachi", text)];
            case 3:
                _d.apply(_c, [(_h.sent()).result, "verified"]);
                _f = (_e = strict_1.default).equal;
                return [4 /*yield*/, (0, round2_js_1.r2Submit)(db, bus, "team", "itachi", text)];
            case 4:
                _f.apply(_e, [(_h.sent()).result, "verified"]);
                strict_1.default.equal((_g = db.get("SELECT COUNT(*) AS n FROM elo_log")) === null || _g === void 0 ? void 0 : _g.n, 1);
                return [3 /*break*/, 6];
            case 5:
                db.close();
                if (oldPepper === undefined)
                    delete process.env["JOIN_CODE_PEPPER"];
                else
                    process.env["JOIN_CODE_PEPPER"] = oldPepper;
                return [7 /*endfinally*/];
            case 6: return [2 /*return*/];
        }
    });
}); });
