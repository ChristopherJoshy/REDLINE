import type { FastifyInstance } from "fastify";
import type { DatabaseAdapter } from "../db/database.js";
export declare function registerProfileRoutes(app: FastifyInstance, db: DatabaseAdapter): void;
