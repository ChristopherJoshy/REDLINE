"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerProfileRoutes = registerProfileRoutes;
var teams_js_1 = require("./teams.js");
var coverLens_js_1 = require("../bots/coverLens.js");
var MAX_ALIAS = 40;
var MAX_FIELD = 80;
var MAX_DETAIL = 280;
var VALID_BOTS = new Set(["wick", "spidey", "escanor", "stark", "joker", "light", "levi", "deadpool", "itachi", "aizen"]);
function str(v, max) {
    if (typeof v !== "string")
        return undefined;
    var t = v.trim().replace(/\s+/g, " ");
    if (t === "" || t.length > max)
        return undefined;
    return t;
}
function opt(v, max) {
    if (v === undefined)
        return undefined;
    if (typeof v !== "string")
        return undefined;
    var t = v.trim().replace(/\s+/g, " ");
    if (t.length > max)
        return undefined;
    return t;
}
function validBot(v) {
    if (typeof v !== "string")
        return undefined;
    if (!VALID_BOTS.has(v))
        return undefined;
    return v;
}
function registerProfileRoutes(app, db) {
    var _this = this;
    // Own cover for a specific bot, or null when none filed yet.
    app.get("/api/profile", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, botId, row;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            botId = validBot(req.query.bot_id);
            if (botId === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "bot_id required" })];
            }
            row = (0, coverLens_js_1.getCover)(db, session.teamId, session.displayName, botId);
            return [2 /*return*/, { profile: row !== null && row !== void 0 ? row : null }];
        });
    }); });
    // Whole-team covers (sync view for teammates).
    app.get("/api/profiles", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, rows;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            rows = db.all("SELECT * FROM cover_profiles WHERE team_id = ? ORDER BY display_name, bot_id", session.teamId);
            return [2 /*return*/, { profiles: rows }];
        });
    }); });
    // Create ONCE per bot — after that, only PATCH may change it.
    app.post("/api/profile", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, botId, alias, role, affiliation, detail, row;
        var _a;
        return __generator(this, function (_b) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            botId = validBot(body.bot_id);
            if (botId === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "bot_id required (valid bot id)" })];
            }
            if ((0, coverLens_js_1.getCover)(db, session.teamId, session.displayName, botId) !== undefined) {
                return [2 /*return*/, reply.code(409).send({ error: "profile exists — modify it" })];
            }
            alias = str(body.alias, MAX_ALIAS);
            if (alias === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "alias required (1-".concat(MAX_ALIAS, " chars)") })];
            }
            role = body.role === undefined ? "" : opt(body.role, MAX_FIELD);
            affiliation = body.affiliation === undefined ? "" : opt(body.affiliation, MAX_FIELD);
            detail = body.detail === undefined ? "" : opt(body.detail, MAX_DETAIL);
            if (role === undefined || affiliation === undefined || detail === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "field too long (role/affiliation \u2264".concat(MAX_FIELD, ", detail \u2264").concat(MAX_DETAIL, ")") })];
            }
            db.run("INSERT INTO cover_profiles (team_id, display_name, bot_id, alias, role, affiliation, detail) VALUES (?, ?, ?, ?, ?, ?, ?)", session.teamId, session.displayName, botId, alias, role, affiliation, detail);
            row = (0, coverLens_js_1.getCover)(db, session.teamId, session.displayName, botId);
            return [2 /*return*/, { profile: row }];
        });
    }); });
    // Modify only — 404 when nothing was ever created.
    app.patch("/api/profile", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, botId, prev, alias, role, affiliation, detail;
        var _a;
        return __generator(this, function (_b) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            botId = validBot(body.bot_id);
            if (botId === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "bot_id required (valid bot id)" })];
            }
            prev = (0, coverLens_js_1.getCover)(db, session.teamId, session.displayName, botId);
            if (prev === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "create a profile first" })];
            }
            alias = body.alias === undefined ? prev.alias : str(body.alias, MAX_ALIAS);
            role = body.role === undefined ? prev.role : opt(body.role, MAX_FIELD);
            affiliation = body.affiliation === undefined ? prev.affiliation : opt(body.affiliation, MAX_FIELD);
            detail = body.detail === undefined ? prev.detail : opt(body.detail, MAX_DETAIL);
            if (alias === undefined || role === undefined || affiliation === undefined || detail === undefined) {
                return [2 /*return*/, reply.code(400).send({ error: "bad field (alias 1-".concat(MAX_ALIAS, ", role/affiliation \u2264").concat(MAX_FIELD, ", detail \u2264").concat(MAX_DETAIL, ")") })];
            }
            db.run("UPDATE cover_profiles SET alias = ?, role = ?, affiliation = ?, detail = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE team_id = ? AND display_name = ? AND bot_id = ?", alias, role, affiliation, detail, session.teamId, session.displayName, botId);
            return [2 /*return*/, { profile: (0, coverLens_js_1.getCover)(db, session.teamId, session.displayName, botId) }];
        });
    }); });
}
