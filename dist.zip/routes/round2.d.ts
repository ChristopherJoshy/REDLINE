import type { FastifyInstance } from "fastify";
import type { DatabaseAdapter } from "../db/database.js";
import type { Bus } from "../ws/bus.js";
import { type BossId } from "../bots/r2.js";
export declare function r2Submit(db: DatabaseAdapter, bus: Bus, teamId: string, boss: BossId, text: string): Promise<{
    result: "verified";
    botId: BossId;
    eloDelta: number;
    score: number;
} | {
    result: "dissolve";
    botId: BossId;
    line: string;
} | {
    result: "troll";
    line: string;
}>;
export declare function registerRound2Routes(app: FastifyInstance, db: DatabaseAdapter, bus: Bus): void;
