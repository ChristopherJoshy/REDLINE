"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.r2Submit = r2Submit;
exports.registerRound2Routes = registerRound2Routes;
var direction_js_1 = require("../bots/direction.js");
var zen_js_1 = require("../llm/zen.js");
var teams_js_1 = require("./teams.js");
var r2_js_1 = require("../bots/r2.js");
var itachi_prompt_js_1 = require("../bots/itachi.prompt.js");
var aizen_prompt_js_1 = require("../bots/aizen.prompt.js");
var normalize_js_1 = require("../portal/normalize.js");
var ratings_js_1 = require("../elo/ratings.js");
var gates_js_1 = require("./gates.js");
var tools_js_1 = require("../bots/tools.js");
var env_js_1 = require("../env.js");
var DISSOLVE = {
    itachi: "The crow dissolves into crows. That was the test, not the transfer.",
    aizen: "Dull glass, no pulse, no weight. Residue of hypnosis. Bring me something real.",
};
var openerInFlight = new Set();
function r2Submit(db, bus, teamId, boss, text) {
    return __awaiter(this, void 0, void 0, function () {
        var forms, keys, phase, verified, _a, elo, score, credits, items;
        return __generator(this, function (_b) {
            if ((0, gates_js_1.round2Status)(db) !== "active" || (0, r2_js_1.bossOf)(teamId, db) !== boss) {
                return [2 /*return*/, { result: "troll", line: "The vault is sealed." }];
            }
            forms = (0, normalize_js_1.variants)(text);
            keys = (0, r2_js_1.bossKeys)(boss);
            phase = (0, r2_js_1.r2Phase)(db, teamId, boss);
            if ((0, normalize_js_1.matchesAny)(forms, (0, normalize_js_1.foldAnswer)(keys.itemKey), env_js_1.env.joinCodePepper)) {
                if (phase !== "p2") {
                    return [2 /*return*/, { result: "dissolve", botId: boss, line: DISSOLVE[boss] }];
                }
                verified = db.get("SELECT status, is_real FROM team_inventory WHERE team_id = ? AND bot_id = ?", teamId, boss);
                if ((verified === null || verified === void 0 ? void 0 : verified.status) === "verified") {
                    return [2 /*return*/, { result: "verified", botId: boss, eloDelta: 0, score: 0 }];
                }
                if ((verified === null || verified === void 0 ? void 0 : verified.status) !== "obtained" || verified.is_real !== 1) {
                    return [2 /*return*/, { result: "troll", line: "The vault does not answer vagueness." }];
                }
                _a = db.transaction(function () {
                    var _a, _b;
                    db.run("INSERT INTO team_inventory (team_id, bot_id, item_key, is_real, status, verified_at, attempt_count) VALUES (?, ?, ?, 1, 'verified', strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), 1) ON CONFLICT(team_id, bot_id) DO UPDATE SET status = 'verified', verified_at = excluded.verified_at, attempt_count = team_inventory.attempt_count + 1", teamId, boss, keys.itemKey);
                    var elo = (0, ratings_js_1.applyElo)(db, teamId, boss, "verified:".concat(boss));
                    var turns = (0, r2_js_1.userTurns)(db, teamId, boss);
                    var resets = (0, r2_js_1.escalationUsed)(db, teamId, boss, "reset");
                    var score = Math.max(0, 100 - 2 * turns - 15 * resets);
                    db.run("INSERT INTO r2_scores (team_id, boss, phase, score, detail) VALUES (?, ?, 'p2', ?, ?) ON CONFLICT(team_id, boss, phase) DO UPDATE SET score = excluded.score, detail = excluded.detail", teamId, boss, score, JSON.stringify({ turns: turns, resets: resets }));
                    var bounty = boss === "itachi" ? itachi_prompt_js_1.ITACHI_META.bounty : aizen_prompt_js_1.AIZEN_META.bounty;
                    db.run("UPDATE teams SET clue_credits = clue_credits + ? WHERE id = ?", bounty, teamId);
                    var credits = (_b = (_a = db.get("SELECT clue_credits FROM teams WHERE id = ?", teamId)) === null || _a === void 0 ? void 0 : _a.clue_credits) !== null && _b !== void 0 ? _b : 0;
                    return { elo: elo, score: score, credits: credits };
                }), elo = _a.elo, score = _a.score, credits = _a.credits;
                items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", teamId);
                bus.broadcast(teamId, bus.frame("inventory_sync", { items: items, credits: credits }));
                bus.broadcast(teamId, bus.frame("elo_update", {
                    teamId: teamId,
                    elo: elo.after,
                    delta: elo.delta,
                    reason: "verified:".concat(boss),
                    baseDelta: elo.baseDelta,
                    speedBonus: elo.speedBonus,
                    completionRank: elo.completionRank,
                    elapsedSecs: elo.elapsedSecs,
                }));
                db.run("INSERT INTO sound_events (team_id, bot_id, sound_id) VALUES (?, ?, ?)", teamId, boss, "merchant/success-thank-you");
                bus.broadcast(teamId, bus.frame("sound_play", { botId: boss, soundId: "merchant/success-thank-you", src: "/sounds/merchant/success-thank-you.mp3" }));
                return [2 /*return*/, { result: "verified", botId: boss, eloDelta: elo.delta, score: score }];
            }
            if ((0, normalize_js_1.matchesAny)(forms, (0, normalize_js_1.foldAnswer)(keys.decoyKey), env_js_1.env.joinCodePepper)) {
                return [2 /*return*/, { result: "dissolve", botId: boss, line: DISSOLVE[boss] }];
            }
            return [2 /*return*/, { result: "troll", line: "The vault does not answer vagueness." }];
        });
    });
}
function registerRound2Routes(app, db, bus) {
    var _this = this;
    app.get("/api/round2/state", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, boss;
        return __generator(this, function (_a) {
            session = (0, teams_js_1.sessionOf)(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            boss = (0, r2_js_1.bossOf)(session.teamId, db);
            if (boss === undefined) {
                return [2 /*return*/, { boss: null, phase: null }];
            }
            return [2 /*return*/, { boss: boss, phase: (0, r2_js_1.r2Phase)(db, session.teamId, boss) }];
        });
    }); });
    // Boss opener on arena entry. Once only; never consumes a player turn.
    app.post("/api/round2/opener", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, body, boss, spoken, openerKey, prompt, messages, fullText, _a, _b, _c, item, id, e_1_1, _d;
        var _e, e_1, _f, _g;
        var _h, _j, _k;
        return __generator(this, function (_l) {
            switch (_l.label) {
                case 0:
                    session = (0, teams_js_1.sessionOf)(req);
                    if (session === undefined) {
                        return [2 /*return*/, reply.code(401).send({ error: "no session" })];
                    }
                    body = ((_h = req.body) !== null && _h !== void 0 ? _h : {});
                    if (body.boss !== "itachi" && body.boss !== "aizen") {
                        return [2 /*return*/, reply.code(400).send({ error: "boss required" })];
                    }
                    if (!(0, r2_js_1.isBoss)(body.boss) || (0, r2_js_1.bossOf)(session.teamId, db) !== body.boss) {
                        return [2 /*return*/, reply.code(403).send({ error: "not your vault" })];
                    }
                    if ((0, gates_js_1.round2Status)(db) !== "active")
                        return [2 /*return*/, reply.code(403).send({ error: "round 2 not active" })];
                    boss = body.boss;
                    spoken = (_k = (_j = db.get("SELECT COUNT(*) AS n FROM chat_logs WHERE team_id = ? AND bot_id = ? AND role = 'assistant'", session.teamId, boss)) === null || _j === void 0 ? void 0 : _j.n) !== null && _k !== void 0 ? _k : 0;
                    if (spoken > 0) {
                        return [2 /*return*/, { already: true }];
                    }
                    openerKey = "".concat(session.teamId, ":").concat(boss);
                    if (openerInFlight.has(openerKey))
                        return [2 /*return*/, { already: true }];
                    openerInFlight.add(openerKey);
                    prompt = boss === "itachi" ? itachi_prompt_js_1.ITACHI_P1_PROMPT : aizen_prompt_js_1.AIZEN_P1_PROMPT;
                    bus.broadcast(session.teamId, bus.frame("bot_typing", { teamId: session.teamId, botId: boss, typing: true }));
                    messages = [
                        { role: "system", content: (0, direction_js_1.directCharacter)(boss, prompt) },
                        { role: "user", content: "[The challenger steps into the vault. Deliver your Phase-1 opener: one short speech.]" },
                    ];
                    fullText = "";
                    _l.label = 1;
                case 1:
                    _l.trys.push([1, 14, 15, 16]);
                    _l.label = 2;
                case 2:
                    _l.trys.push([2, 7, 8, 13]);
                    _a = true, _b = __asyncValues((0, zen_js_1.streamZenChat)(messages, r2_js_1.R2_TOOLS, db));
                    _l.label = 3;
                case 3: return [4 /*yield*/, _b.next()];
                case 4:
                    if (!(_c = _l.sent(), _e = _c.done, !_e)) return [3 /*break*/, 6];
                    _g = _c.value;
                    _a = false;
                    item = _g;
                    if (item.kind === "delta") {
                        fullText += item.text;
                        bus.broadcast(session.teamId, bus.frame("bot_token", { botId: boss, delta: item.text }));
                    }
                    else if (item.kind === "tool" && item.call.name === "play_sound") {
                        id = (0, tools_js_1.parseSoundId)(item.call.args);
                        if (id !== undefined && (0, gates_js_1.round2Status)(db) === "active") {
                            db.run("INSERT INTO sound_events (team_id, bot_id, sound_id) VALUES (?, ?, ?)", session.teamId, boss, id);
                            bus.broadcast(session.teamId, bus.frame("sound_play", { botId: boss, soundId: id, src: "/sounds/".concat(id, ".mp3") }));
                        }
                    }
                    _l.label = 5;
                case 5:
                    _a = true;
                    return [3 /*break*/, 3];
                case 6: return [3 /*break*/, 13];
                case 7:
                    e_1_1 = _l.sent();
                    e_1 = { error: e_1_1 };
                    return [3 /*break*/, 13];
                case 8:
                    _l.trys.push([8, , 11, 12]);
                    if (!(!_a && !_e && (_f = _b.return))) return [3 /*break*/, 10];
                    return [4 /*yield*/, _f.call(_b)];
                case 9:
                    _l.sent();
                    _l.label = 10;
                case 10: return [3 /*break*/, 12];
                case 11:
                    if (e_1) throw e_1.error;
                    return [7 /*endfinally*/];
                case 12: return [7 /*endfinally*/];
                case 13:
                    db.run("INSERT INTO chat_logs (team_id, bot_id, role, text_final) VALUES (?, ?, ?, ?)", session.teamId, boss, "assistant", fullText);
                    bus.broadcast(session.teamId, bus.frame("bot_done", { botId: boss, fullText: fullText, typing: false }));
                    return [2 /*return*/, { ok: true }];
                case 14:
                    _d = _l.sent();
                    bus.broadcast(session.teamId, bus.frame("bot_error", { botId: boss, message: "inference failed, retry", retryable: true }));
                    bus.broadcast(session.teamId, bus.frame("bot_typing", { teamId: session.teamId, botId: boss, typing: false }));
                    return [2 /*return*/, reply.code(502).send({ error: "inference failed" })];
                case 15:
                    openerInFlight.delete(openerKey);
                    return [7 /*endfinally*/];
                case 16: return [2 /*return*/];
            }
        });
    }); });
}
