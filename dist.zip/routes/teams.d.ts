import type { FastifyInstance } from "fastify";
import type { DatabaseAdapter } from "../db/database.js";
export declare function sessionOf(req: {
    headers: Record<string, string | string[] | undefined>;
}): {
    teamId: string;
    displayName: string;
} | undefined;
export declare function registerTeamRoutes(app: FastifyInstance, db: DatabaseAdapter): void;
