"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionOf = sessionOf;
exports.registerTeamRoutes = registerTeamRoutes;
var node_crypto_1 = require("node:crypto");
var env_js_1 = require("../env.js");
var codes_js_1 = require("../auth/codes.js");
var SESSION_COOKIE = "redline_session";
function sessionOf(req) {
    // 1. Check custom header x-session-token
    var xToken = req.headers["x-session-token"];
    var headerToken = Array.isArray(xToken) ? xToken[0] : xToken;
    if (typeof headerToken === "string" && headerToken.trim() !== "") {
        var verified = (0, codes_js_1.verifySessionToken)(headerToken.trim(), env_js_1.env.joinCodePepper);
        if (verified)
            return verified;
    }
    // 2. Check Authorization Bearer header
    var auth = req.headers["authorization"];
    var authHeader = Array.isArray(auth) ? auth[0] : auth;
    if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
        var bearerToken = authHeader.slice(7).trim();
        if (bearerToken !== "") {
            var verified = (0, codes_js_1.verifySessionToken)(bearerToken, env_js_1.env.joinCodePepper);
            if (verified)
                return verified;
        }
    }
    // 3. Fallback to cookie
    var raw = req.headers["cookie"];
    var header = Array.isArray(raw) ? raw.join("; ") : raw;
    var token = (0, codes_js_1.parseCookies)(header)[SESSION_COOKIE];
    if (token === undefined) {
        return undefined;
    }
    return (0, codes_js_1.verifySessionToken)(token, env_js_1.env.joinCodePepper);
}
/** In-memory seat lock: teamId → Set of display_names currently in-session */
var seatLocks = new Map();
function lockSeat(teamId, displayName) {
    if (!seatLocks.has(teamId))
        seatLocks.set(teamId, new Set());
    seatLocks.get(teamId).add(displayName);
}
function releaseSeat(teamId, displayName) {
    var _a;
    (_a = seatLocks.get(teamId)) === null || _a === void 0 ? void 0 : _a.delete(displayName);
}
function isSeatTaken(teamId, displayName) {
    var _a, _b;
    return (_b = (_a = seatLocks.get(teamId)) === null || _a === void 0 ? void 0 : _a.has(displayName)) !== null && _b !== void 0 ? _b : false;
}
function activeSeats(teamId) {
    var _a;
    return Array.from((_a = seatLocks.get(teamId)) !== null && _a !== void 0 ? _a : []);
}
function registerTeamRoutes(app, db) {
    var _this = this;
    // Admin: create team + members. Code shown ONCE here, never stored.
    app.post("/api/admin/teams", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var header, body, name, members, code, id;
        var _a;
        return __generator(this, function (_b) {
            header = req.headers["x-admin-code"];
            if (!(0, codes_js_1.adminOk)(Array.isArray(header) ? header[0] : header, env_js_1.env.adminCode)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            name = typeof body.name === "string" ? body.name.trim() : "";
            members = Array.isArray(body.members)
                ? body.members.filter(function (m) { return typeof m === "string"; }).map(function (m) { return m.trim(); }).filter(function (m) { return m !== ""; })
                : [];
            if (name === "" || members.length < 2 || members.length > 3) {
                return [2 /*return*/, reply.code(400).send({ error: "need a team name and 2-3 members" })];
            }
            code = (0, codes_js_1.generateJoinCode)();
            id = (0, node_crypto_1.randomUUID)();
            try {
                db.transaction(function () {
                    var e_1, _a;
                    db.run("INSERT INTO teams (id, name, join_code_hash, hint, join_code) VALUES (?, ?, ?, ?, ?)", id, name, (0, codes_js_1.hashJoinCode)(code, env_js_1.env.joinCodePepper), (0, codes_js_1.hintFor)(code), (0, codes_js_1.displayCode)(code));
                    var seen = new Set();
                    try {
                        for (var members_1 = __values(members), members_1_1 = members_1.next(); !members_1_1.done; members_1_1 = members_1.next()) {
                            var displayName = members_1_1.value;
                            if (seen.has(displayName)) {
                                continue;
                            }
                            seen.add(displayName);
                            db.run("INSERT INTO team_members (team_id, display_name) VALUES (?, ?)", id, displayName);
                        }
                    }
                    catch (e_1_1) { e_1 = { error: e_1_1 }; }
                    finally {
                        try {
                            if (members_1_1 && !members_1_1.done && (_a = members_1.return)) _a.call(members_1);
                        }
                        finally { if (e_1) throw e_1.error; }
                    }
                });
            }
            catch (_c) {
                return [2 /*return*/, reply.code(409).send({ error: "team name taken, retry" })];
            }
            return [2 /*return*/, { id: id, name: name, code: (0, codes_js_1.displayCode)(code), hint: (0, codes_js_1.hintFor)(code) }];
        });
    }); });
    // Player: enter code -> reveals ONLY this team's member names. No game info.
    app.post("/api/join", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, normalized, team, members;
        var _a;
        return __generator(this, function (_b) {
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            normalized = typeof body.code === "string" ? (0, codes_js_1.normalizeCode)(body.code) : "";
            if (normalized.length !== 8) {
                return [2 /*return*/, reply.code(401).send({ error: "invalid code" })];
            }
            team = db.get("SELECT id, name FROM teams WHERE join_code_hash = ?", (0, codes_js_1.hashJoinCode)(normalized, env_js_1.env.joinCodePepper));
            if (team === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "invalid code" })];
            }
            members = db
                .all("SELECT display_name FROM team_members WHERE team_id = ? ORDER BY rowid", team.id)
                .map(function (m) { return m.display_name; });
            return [2 /*return*/, { teamId: team.id, teamName: team.name, members: members }];
        });
    }); });
    // Player: pick identity -> session binds (team_id, display_name).
    app.post("/api/identify", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var body, teamId, displayName, member, token, team;
        var _a, _b, _c;
        return __generator(this, function (_d) {
            body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
            teamId = typeof body.teamId === "string" ? body.teamId : "";
            displayName = typeof body.displayName === "string" ? body.displayName.trim() : "";
            if (teamId === "" || displayName === "") {
                return [2 /*return*/, reply.code(400).send({ error: "pick who you are" })];
            }
            member = db.get("SELECT display_name FROM team_members WHERE team_id = ? AND display_name = ?", teamId, displayName);
            if (member === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "unknown identity" })];
            }
            // Check if this seat is already locked by another session
            if (isSeatTaken(teamId, displayName)) {
                return [2 /*return*/, reply.code(409).send({ error: "That seat is already taken by another player." })];
            }
            lockSeat(teamId, displayName);
            token = (0, codes_js_1.makeSessionToken)(teamId, displayName, env_js_1.env.joinCodePepper);
            team = db.get("SELECT name, elo FROM teams WHERE id = ?", teamId);
            void reply.header("Set-Cookie", "".concat(SESSION_COOKIE, "=").concat(encodeURIComponent(token), "; Path=/; HttpOnly; SameSite=None; Secure"));
            return [2 /*return*/, {
                    teamId: teamId,
                    displayName: displayName,
                    teamName: (_b = team === null || team === void 0 ? void 0 : team.name) !== null && _b !== void 0 ? _b : "",
                    elo: (_c = team === null || team === void 0 ? void 0 : team.elo) !== null && _c !== void 0 ? _c : 1200,
                    token: token,
                }];
        });
    }); });
    // Get active (locked) members for a team — used by the Enter screen.
    app.get("/api/team/active", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var teamId;
        return __generator(this, function (_a) {
            teamId = req.query.teamId;
            if (typeof teamId !== "string" || teamId.trim() === "") {
                return [2 /*return*/, reply.code(400).send({ error: "teamId required" })];
            }
            return [2 /*return*/, { active: activeSeats(teamId.trim()) }];
        });
    }); });
    // Admin: reset team by id -> removes team, members, and related game data.
    app.delete("/api/admin/teams/:id", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var header, params, teamId, team;
        return __generator(this, function (_a) {
            header = req.headers["x-admin-code"];
            if (!(0, codes_js_1.adminOk)(Array.isArray(header) ? header[0] : header, env_js_1.env.adminCode)) {
                return [2 /*return*/, reply.code(401).send({ error: "unauthorized" })];
            }
            params = req.params;
            teamId = typeof params.id === "string" ? params.id.trim() : "";
            if (teamId === "") {
                return [2 /*return*/, reply.code(400).send({ error: "teamId required" })];
            }
            team = db.get("SELECT id FROM teams WHERE id = ?", teamId);
            if (team === undefined) {
                return [2 /*return*/, reply.code(404).send({ error: "team not found" })];
            }
            db.transaction(function () {
                db.run("DELETE FROM cover_profiles WHERE team_id = ?", teamId);
                db.run("DELETE FROM team_inventory WHERE team_id = ?", teamId);
                db.run("DELETE FROM merchant_clues WHERE team_id = ?", teamId);
                db.run("DELETE FROM chat_logs WHERE team_id = ?", teamId);
                db.run("DELETE FROM elo_log WHERE team_id = ?", teamId);
                db.run("DELETE FROM reasoning_traces WHERE team_id = ?", teamId);
                db.run("DELETE FROM sound_events WHERE team_id = ?", teamId);
                db.run("DELETE FROM fullscreen_attempts WHERE team_id = ?", teamId);
                db.run("DELETE FROM r2_assignments WHERE team_id = ?", teamId);
                db.run("DELETE FROM r2_scores WHERE team_id = ?", teamId);
                db.run("DELETE FROM deterrence_log WHERE team_id = ?", teamId);
                db.run("DELETE FROM team_members WHERE team_id = ?", teamId);
                db.run("DELETE FROM teams WHERE id = ?", teamId);
            });
            return [2 /*return*/, { ok: true, teamId: teamId }];
        });
    }); });
    app.get("/api/me", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session, member, team;
        var _a, _b;
        return __generator(this, function (_c) {
            session = sessionOf(req);
            if (session === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            member = db.get("SELECT display_name FROM team_members WHERE team_id = ? AND display_name = ?", session.teamId, session.displayName);
            if (member === undefined) {
                return [2 /*return*/, reply.code(401).send({ error: "no session" })];
            }
            // Re-lock seat on page refresh — this won't block concurrent sessions
            // because the token already proves identity; we just restore the lock state.
            lockSeat(session.teamId, session.displayName);
            team = db.get("SELECT name, elo FROM teams WHERE id = ?", session.teamId);
            return [2 /*return*/, {
                    teamId: session.teamId,
                    displayName: session.displayName,
                    teamName: (_a = team === null || team === void 0 ? void 0 : team.name) !== null && _a !== void 0 ? _a : "",
                    elo: (_b = team === null || team === void 0 ? void 0 : team.elo) !== null && _b !== void 0 ? _b : 1200,
                }];
        });
    }); });
    app.post("/api/logout", function (req, reply) { return __awaiter(_this, void 0, void 0, function () {
        var session;
        return __generator(this, function (_a) {
            session = sessionOf(req);
            if (session !== undefined) {
                releaseSeat(session.teamId, session.displayName);
            }
            void reply.header("Set-Cookie", "".concat(SESSION_COOKIE, "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=None; Secure"));
            return [2 /*return*/, { ok: true }];
        });
    }); });
}
