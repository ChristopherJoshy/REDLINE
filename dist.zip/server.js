"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var node_fs_1 = require("node:fs");
var node_path_1 = require("node:path");
var fastify_1 = __importDefault(require("fastify"));
var static_1 = __importDefault(require("@fastify/static"));
var ws_1 = require("ws");
var env_js_1 = require("./env.js");
var database_js_1 = require("./db/database.js");
var teams_js_1 = require("./routes/teams.js");
var profiles_js_1 = require("./routes/profiles.js");
var admin_js_1 = require("./routes/admin.js");
var gates_js_1 = require("./routes/gates.js");
var state_js_1 = require("./rounds/state.js");
var round2_js_1 = require("./routes/round2.js");
var settings_js_1 = require("./assessment/settings.js");
var merchant_js_1 = require("./routes/merchant.js");
var bus_js_1 = require("./ws/bus.js");
var locks_js_1 = require("./chat/locks.js");
var locks_js_2 = require("./routes/locks.js");
var handler_js_1 = require("./chat/handler.js");
var codes_js_1 = require("./auth/codes.js");
var tokenTracker_js_1 = require("./llm/tokenTracker.js");
// src/ and dist/ are both one level below the backend root.
var root = (0, node_fs_1.existsSync)((0, node_path_1.join)(__dirname, "..", "package.json"))
    ? (0, node_path_1.join)(__dirname, "..")
    : (0, node_path_1.join)(__dirname, "..", "..");
var app = (0, fastify_1.default)({ logger: true });
app.addHook("onRequest", function (req, reply) { return __awaiter(void 0, void 0, void 0, function () {
    var origin;
    return __generator(this, function (_a) {
        origin = req.headers.origin;
        if (typeof origin === "string" && origin !== "") {
            reply.header("Access-Control-Allow-Origin", origin);
            reply.header("Access-Control-Allow-Credentials", "true");
            reply.header("Vary", "Origin");
        }
        reply.header("Access-Control-Allow-Methods", "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS");
        reply.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-session-token, x-admin-code, x-admin-pin, x-settings-pin, ngrok-skip-browser-warning");
        reply.header("Access-Control-Max-Age", "86400");
        if (req.method === "OPTIONS") {
            return [2 /*return*/, reply.code(204).send()];
        }
        return [2 /*return*/];
    });
}); });
app.get("/api/health", function () { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
    return [2 /*return*/, ({ ok: true })];
}); }); });
// Single LAN process: the built frontend (dist, sounds included) + API + WS.
var webRoot = (0, node_path_1.join)(root, "..", "frontend", "dist");
if ((0, node_fs_1.existsSync)(webRoot)) {
    app.register(static_1.default, { root: webRoot });
    app.setNotFoundHandler(function (req, reply) {
        if (req.url.startsWith("/api")) {
            reply.code(404).send({ error: "not found" });
        }
        else {
            reply.sendFile("index.html");
        }
    });
}
else {
    app.register(static_1.default, { root: (0, node_path_1.join)(root, "public"), prefix: "/sounds/" });
}
(0, node_fs_1.mkdirSync)((0, node_path_1.join)(root, "data"), { recursive: true });
var db = (0, database_js_1.openDatabase)((0, node_path_1.join)(root, "data", "redline.db"), (0, node_path_1.join)(__dirname, "db", "schema.sql"));
var bus = new bus_js_1.Bus();
var locks = new locks_js_1.BotLocks();
(0, teams_js_1.registerTeamRoutes)(app, db);
(0, profiles_js_1.registerProfileRoutes)(app, db);
(0, locks_js_2.registerLockRoutes)(app, locks, bus);
(0, merchant_js_1.registerMerchantRoutes)(app, db, bus);
(0, gates_js_1.registerGateRoutes)(app, db, bus);
(0, round2_js_1.registerRound2Routes)(app, db, bus);
(0, admin_js_1.registerAdminRoutes)(app, db, root, bus, locks);
app.post("/api/fullscreen-log", function (req, reply) { return __awaiter(void 0, void 0, void 0, function () {
    var session;
    return __generator(this, function (_a) {
        session = (0, teams_js_1.sessionOf)(req);
        if (session === undefined) {
            return [2 /*return*/, reply.code(401).send({ error: "no session" })];
        }
        db.run("INSERT INTO fullscreen_attempts (team_id, display_name) VALUES (?, ?)", session.teamId, session.displayName);
        return [2 /*return*/, { ok: true }];
    });
}); });
app.post("/api/deterrence-log", function (req) { return __awaiter(void 0, void 0, void 0, function () {
    var session, body, kind;
    var _a, _b;
    return __generator(this, function (_c) {
        session = (0, teams_js_1.sessionOf)(req);
        body = ((_a = req.body) !== null && _a !== void 0 ? _a : {});
        kind = typeof body.kind === "string" ? body.kind.slice(0, 32) : "unknown";
        db.run("INSERT INTO deterrence_log (team_id, kind) VALUES (?, ?)", (_b = session === null || session === void 0 ? void 0 : session.teamId) !== null && _b !== void 0 ? _b : null, kind);
        return [2 /*return*/, { ok: true }];
    });
}); });
app.get("/api/chat/history", function (req, reply) { return __awaiter(void 0, void 0, void 0, function () {
    var session, logs, history, logs_1, logs_1_1, row;
    var e_1, _a;
    return __generator(this, function (_b) {
        session = (0, teams_js_1.sessionOf)(req);
        if (session === undefined) {
            return [2 /*return*/, reply.code(401).send({ error: "no session" })];
        }
        logs = db.all("SELECT id, bot_id, role, text_final, created_at FROM chat_logs WHERE team_id = ? ORDER BY id ASC", session.teamId);
        history = {};
        try {
            for (logs_1 = __values(logs), logs_1_1 = logs_1.next(); !logs_1_1.done; logs_1_1 = logs_1.next()) {
                row = logs_1_1.value;
                if (!history[row.bot_id]) {
                    history[row.bot_id] = [];
                }
                history[row.bot_id].push({
                    id: row.id,
                    role: row.role === "assistant" ? "bot" : "user",
                    text: row.text_final,
                    createdAt: row.created_at,
                });
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (logs_1_1 && !logs_1_1.done && (_a = logs_1.return)) _a.call(logs_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return [2 /*return*/, { history: history }];
    });
}); });
// EventSource fallback for venues whose firewall blocks the WS upgrade.
app.get("/api/stream", function (req, reply) { return __awaiter(void 0, void 0, void 0, function () {
    var session, raw, off;
    return __generator(this, function (_a) {
        session = (0, teams_js_1.sessionOf)(req);
        if (session === undefined) {
            return [2 /*return*/, reply.code(401).send({ error: "no session" })];
        }
        raw = reply.raw;
        raw.writeHead(200, {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
        });
        raw.write("data: ".concat(JSON.stringify(bus.frame("hello_ack", {})), "\n\n"));
        off = bus.subscribe(session.teamId, function (event) {
            raw.write("data: ".concat(JSON.stringify(event), "\n\n"));
        });
        raw.on("close", function () {
            off();
        });
        return [2 /*return*/];
    });
}); });
function boot() {
    return __awaiter(this, void 0, void 0, function () {
        var telemetryInterval, wss, previousRound2, roundEvents;
        var _this = this;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // Touch env at boot so missing keys fail closed here, not mid-event.
                    void env_js_1.env.groqApiKey;
                    void env_js_1.env.zenApiKey;
                    void env_js_1.env.joinCodePepper;
                    app.addHook("onClose", function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                        clearInterval(roundEvents);
                        clearInterval(telemetryInterval);
                        wss.close();
                        db.close();
                        return [2 /*return*/];
                    }); }); });
                    return [4 /*yield*/, app.listen({ port: env_js_1.env.port, host: "0.0.0.0" })];
                case 1:
                    _a.sent();
                    wss = new ws_1.WebSocketServer({ server: app.server });
                    wss.on("connection", function (socket, req) {
                        var _a;
                        var token;
                        if (req.url) {
                            try {
                                var parsedUrl = new URL(req.url, "http://localhost");
                                token = (_a = parsedUrl.searchParams.get("token")) !== null && _a !== void 0 ? _a : undefined;
                            }
                            catch (_b) {
                                // ignore
                            }
                        }
                        if (!token) {
                            token = (0, codes_js_1.parseCookies)(req.headers.cookie)["redline_session"];
                        }
                        var session = token === undefined ? undefined : (0, codes_js_1.verifySessionToken)(token, env_js_1.env.joinCodePepper);
                        if (session === undefined && token !== env_js_1.env.adminCode) {
                            socket.close(4401, "no session");
                            return;
                        }
                        var teamId = session ? session.teamId : "ADMIN";
                        bus.add(socket, teamId);
                        if (session === undefined) {
                            // Admin clients don't send hello/chat commands
                            return;
                        }
                        socket.on("message", function (raw) {
                            var e_2, _a;
                            var _b;
                            var event;
                            try {
                                event = JSON.parse(String(raw));
                            }
                            catch (_c) {
                                return;
                            }
                            if (event.event === "hello") {
                                var assessmentSettings = (0, settings_js_1.readAssessmentSettings)(db);
                                bus.setMember(socket, session.displayName, "online", assessmentSettings.singleTabMode);
                                if (typeof event.data.lastEventId === "string") {
                                    bus.replay(socket, session.teamId, event.data.lastEventId);
                                }
                                bus.send(socket, bus.frame("hello_ack", {}));
                                // Fresh mounts (or a dropped room) start from current truth, not empty.
                                var items = db.all("SELECT bot_id AS botId, item_key AS itemKey, status FROM team_inventory WHERE team_id = ?", session.teamId);
                                bus.send(socket, bus.frame("assessment_settings_sync", assessmentSettings));
                                var teamRow = db.get("SELECT elo, clue_credits FROM teams WHERE id = ?", session.teamId);
                                var credits = (_b = teamRow === null || teamRow === void 0 ? void 0 : teamRow.clue_credits) !== null && _b !== void 0 ? _b : 0;
                                bus.send(socket, bus.frame("inventory_sync", { items: items, credits: credits }));
                                if (teamRow !== undefined) {
                                    bus.send(socket, bus.frame("elo_update", { teamId: session.teamId, elo: teamRow.elo, delta: 0, reason: "sync" }));
                                }
                                var logs = db.all("SELECT id, bot_id, role, text_final, created_at FROM chat_logs WHERE team_id = ? ORDER BY id ASC", session.teamId);
                                var history_1 = {};
                                try {
                                    for (var logs_2 = __values(logs), logs_2_1 = logs_2.next(); !logs_2_1.done; logs_2_1 = logs_2.next()) {
                                        var row = logs_2_1.value;
                                        if (!history_1[row.bot_id]) {
                                            history_1[row.bot_id] = [];
                                        }
                                        history_1[row.bot_id].push({
                                            id: row.id,
                                            role: row.role === "assistant" ? "bot" : "user",
                                            text: row.text_final,
                                            createdAt: row.created_at,
                                        });
                                    }
                                }
                                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                                finally {
                                    try {
                                        if (logs_2_1 && !logs_2_1.done && (_a = logs_2.return)) _a.call(logs_2);
                                    }
                                    finally { if (e_2) throw e_2.error; }
                                }
                                bus.send(socket, bus.frame("chat_sync", { history: history_1 }));
                                bus.send(socket, bus.frame("bot_locks", { locks: locks.snapshot(session.teamId) }));
                            }
                            else if (event.event === "ping") {
                                bus.send(socket, bus.frame("pong", {}));
                            }
                            else if (event.event === "visibility_change") {
                                var member = bus.memberOf(socket);
                                if (member) {
                                    bus.setMember(socket, member.displayName, event.data.status, false);
                                }
                            }
                            else if (event.event === "security_violation") {
                                var member = bus.memberOf(socket);
                                if (member) {
                                    db.run("INSERT INTO security_logs (team_id, display_name, violation_type, detail) VALUES (?, ?, ?, ?)", session.teamId, member.displayName, event.data.type, "");
                                }
                            }
                            else if (event.event === "chat_send") {
                                if (event.data.teamId && event.data.teamId !== session.teamId) {
                                    return;
                                }
                                // Round-1 single-operator rule: a mark held by a teammate rejects other senders.
                                if ((0, locks_js_1.lockable)(event.data.botId)) {
                                    var held = locks.holder(session.teamId, event.data.botId);
                                    if (held !== undefined && held.displayName !== session.displayName) {
                                        bus.send(socket, bus.frame("bot_error", {
                                            botId: event.data.botId,
                                            message: "".concat(held.displayName, " is already talking to this mark"),
                                            retryable: false,
                                        }));
                                        return;
                                    }
                                }
                                void (0, handler_js_1.handleChatSend)(bus, db, session.teamId, event.data.botId, event.data.text, session.displayName);
                            }
                        });
                    });
                    setInterval(function () {
                        var e_3, _a;
                        bus.sweep();
                        bus.heartbeat(function (socket) { return socket.ping(); });
                        try {
                            for (var _b = __values(locks.sweep()), _c = _b.next(); !_c.done; _c = _b.next()) {
                                var teamId = _c.value;
                                bus.broadcast(teamId, bus.frame("bot_locks", { locks: locks.snapshot(teamId) }));
                            }
                        }
                        catch (e_3_1) { e_3 = { error: e_3_1 }; }
                        finally {
                            try {
                                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                            }
                            finally { if (e_3) throw e_3.error; }
                        }
                    }, PING_MS).unref();
                    telemetryInterval = setInterval(function () {
                        // We can just eagerly broadcast it. If no admins are listening, it just drops.
                        var tokens = tokenTracker_js_1.tokenTracker.getMetrics();
                        bus.broadcast("ADMIN", bus.frame("admin_telemetry", {
                            tps: tokens.currentTps,
                            peakTps: tokens.peakTps,
                            tokensIn: tokens.promptTokens,
                            tokensOut: tokens.completionTokens,
                        }));
                    }, 500);
                    telemetryInterval.unref();
                    previousRound2 = (0, state_js_1.roundState)(db, 2).status;
                    roundEvents = setInterval(function () {
                        var current = (0, state_js_1.roundState)(db, 2);
                        if (current.status !== previousRound2) {
                            previousRound2 = current.status;
                            if (current.status === "active")
                                bus.broadcastAll(bus.frame("round2_start", { durationSecs: current.durationSecs }));
                            if (current.status === "ended")
                                bus.broadcastAll(bus.frame("round2_end", { reason: "expired" }));
                        }
                    }, 250);
                    roundEvents.unref();
                    return [2 /*return*/];
            }
        });
    });
}
var PING_MS = 25000;
void boot();
