import type { WebSocket } from "ws";
import type { ServerEvent } from "../contracts/events.js";
export declare class Bus {
    private teamSockets;
    private alive;
    private teams;
    private members;
    private ring;
    private listeners;
    subscribe(teamId: string, fn: (event: ServerEvent) => void): () => void;
    add(socket: WebSocket, teamId: string): void;
    setMember(socket: WebSocket, displayName: string, status?: "online" | "away", enforceSingleTab?: boolean): void;
    memberOf(socket: WebSocket): {
        teamId: string;
        displayName: string;
        status: "online" | "away";
    } | undefined;
    remove(socket: WebSocket): void;
    private broadcastPresence;
    teamOf(socket: WebSocket): string | undefined;
    send(socket: WebSocket, event: ServerEvent): void;
    broadcast(teamId: string, event: ServerEvent): void;
    broadcastAll(event: ServerEvent): void;
    connectionCount(): number;
    replay(socket: WebSocket, teamId: string, lastEventId: string): void;
    sweep(): void;
    heartbeat(ping: (socket: WebSocket) => void): void;
    frame<T extends ServerEvent["event"]>(event: T, data: Extract<ServerEvent, {
        event: T;
    }>["data"]): Extract<ServerEvent, {
        event: T;
    }>;
    private pushRing;
}
