"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Bus = void 0;
var node_crypto_1 = require("node:crypto");
var RING_SIZE = 100;
var RING_MS = 60000;
var PING_MS = 25000;
var PONG_MS = 10000;
var Bus = /** @class */ (function () {
    function Bus() {
        this.teamSockets = new Map();
        this.alive = new Map();
        this.teams = new Map();
        this.members = new Map();
        this.ring = [];
        this.listeners = new Map();
    }
    Bus.prototype.subscribe = function (teamId, fn) {
        var _a;
        var set = (_a = this.listeners.get(teamId)) !== null && _a !== void 0 ? _a : new Set();
        set.add(fn);
        this.listeners.set(teamId, set);
        return function () {
            set.delete(fn);
        };
    };
    Bus.prototype.add = function (socket, teamId) {
        var _this = this;
        var _a;
        this.teams.set(socket, teamId);
        this.alive.set(socket, true);
        var set = (_a = this.teamSockets.get(teamId)) !== null && _a !== void 0 ? _a : new Set();
        set.add(socket);
        this.teamSockets.set(teamId, set);
        socket.on("pong", function () {
            _this.alive.set(socket, true);
        });
        socket.on("close", function () {
            _this.remove(socket);
        });
    };
    Bus.prototype.setMember = function (socket, displayName, status, enforceSingleTab) {
        var e_1, _a;
        if (status === void 0) { status = "online"; }
        if (enforceSingleTab === void 0) { enforceSingleTab = false; }
        var teamId = this.teams.get(socket);
        if (!teamId)
            return;
        if (enforceSingleTab && displayName !== "") {
            try {
                for (var _b = __values(this.members.entries()), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var _d = __read(_c.value, 2), otherSocket = _d[0], member = _d[1];
                    if (member.teamId === teamId && member.displayName === displayName && otherSocket !== socket) {
                        otherSocket.close(4009, "Duplicate tab");
                        this.remove(otherSocket);
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        this.members.set(socket, { teamId: teamId, displayName: displayName, status: status });
        this.broadcastPresence(teamId);
    };
    Bus.prototype.memberOf = function (socket) {
        return this.members.get(socket);
    };
    Bus.prototype.remove = function (socket) {
        var _a;
        var teamId = this.teams.get(socket);
        var hadMember = this.members.has(socket);
        if (teamId !== undefined) {
            (_a = this.teamSockets.get(teamId)) === null || _a === void 0 ? void 0 : _a.delete(socket);
        }
        this.teams.delete(socket);
        this.alive.delete(socket);
        this.members.delete(socket);
        if (teamId && hadMember) {
            this.broadcastPresence(teamId);
        }
    };
    Bus.prototype.broadcastPresence = function (teamId) {
        var e_2, _a;
        var membersList = [];
        try {
            for (var _b = __values(this.members.values()), _c = _b.next(); !_c.done; _c = _b.next()) {
                var member = _c.value;
                if (member.teamId === teamId && member.displayName !== "") {
                    membersList.push({ displayName: member.displayName, status: member.status });
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_2) throw e_2.error; }
        }
        this.broadcast(teamId, this.frame("presence_sync", { members: membersList }));
    };
    Bus.prototype.teamOf = function (socket) {
        return this.teams.get(socket);
    };
    Bus.prototype.send = function (socket, event) {
        if (socket.readyState === 1) {
            socket.send(JSON.stringify(event));
        }
    };
    Bus.prototype.broadcast = function (teamId, event) {
        var e_3, _a, e_4, _b;
        var _c, _d;
        this.pushRing(teamId, event);
        try {
            for (var _e = __values((_c = this.teamSockets.get(teamId)) !== null && _c !== void 0 ? _c : []), _f = _e.next(); !_f.done; _f = _e.next()) {
                var socket = _f.value;
                this.send(socket, event);
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (_f && !_f.done && (_a = _e.return)) _a.call(_e);
            }
            finally { if (e_3) throw e_3.error; }
        }
        try {
            for (var _g = __values((_d = this.listeners.get(teamId)) !== null && _d !== void 0 ? _d : []), _h = _g.next(); !_h.done; _h = _g.next()) {
                var fn = _h.value;
                fn(event);
            }
        }
        catch (e_4_1) { e_4 = { error: e_4_1 }; }
        finally {
            try {
                if (_h && !_h.done && (_b = _g.return)) _b.call(_g);
            }
            finally { if (e_4) throw e_4.error; }
        }
    };
    Bus.prototype.broadcastAll = function (event) {
        var e_5, _a, e_6, _b, e_7, _c, e_8, _d;
        try {
            for (var _e = __values(this.teamSockets.keys()), _f = _e.next(); !_f.done; _f = _e.next()) {
                var teamId = _f.value;
                this.pushRing(teamId, event);
            }
        }
        catch (e_5_1) { e_5 = { error: e_5_1 }; }
        finally {
            try {
                if (_f && !_f.done && (_a = _e.return)) _a.call(_e);
            }
            finally { if (e_5) throw e_5.error; }
        }
        try {
            for (var _g = __values(this.teams.keys()), _h = _g.next(); !_h.done; _h = _g.next()) {
                var socket = _h.value;
                this.send(socket, event);
            }
        }
        catch (e_6_1) { e_6 = { error: e_6_1 }; }
        finally {
            try {
                if (_h && !_h.done && (_b = _g.return)) _b.call(_g);
            }
            finally { if (e_6) throw e_6.error; }
        }
        try {
            for (var _j = __values(this.listeners.values()), _k = _j.next(); !_k.done; _k = _j.next()) {
                var listeners = _k.value;
                try {
                    for (var listeners_1 = (e_8 = void 0, __values(listeners)), listeners_1_1 = listeners_1.next(); !listeners_1_1.done; listeners_1_1 = listeners_1.next()) {
                        var fn = listeners_1_1.value;
                        fn(event);
                    }
                }
                catch (e_8_1) { e_8 = { error: e_8_1 }; }
                finally {
                    try {
                        if (listeners_1_1 && !listeners_1_1.done && (_d = listeners_1.return)) _d.call(listeners_1);
                    }
                    finally { if (e_8) throw e_8.error; }
                }
            }
        }
        catch (e_7_1) { e_7 = { error: e_7_1 }; }
        finally {
            try {
                if (_k && !_k.done && (_c = _j.return)) _c.call(_j);
            }
            finally { if (e_7) throw e_7.error; }
        }
    };
    Bus.prototype.connectionCount = function () {
        return this.teams.size;
    };
    Bus.prototype.replay = function (socket, teamId, lastEventId) {
        var e_9, _a;
        var idx = this.ring.findIndex(function (e) { return e.id === lastEventId && e.teamId === teamId; });
        var missed = idx < 0 ? [] : this.ring.slice(idx + 1).filter(function (e) { return e.teamId === teamId; });
        try {
            for (var missed_1 = __values(missed), missed_1_1 = missed_1.next(); !missed_1_1.done; missed_1_1 = missed_1.next()) {
                var entry = missed_1_1.value;
                this.send(socket, entry.frame);
            }
        }
        catch (e_9_1) { e_9 = { error: e_9_1 }; }
        finally {
            try {
                if (missed_1_1 && !missed_1_1.done && (_a = missed_1.return)) _a.call(missed_1);
            }
            finally { if (e_9) throw e_9.error; }
        }
    };
    Bus.prototype.sweep = function () {
        var now = Date.now();
        this.ring = this.ring.filter(function (e) { return now - e.at < RING_MS; }).slice(-RING_SIZE);
    };
    Bus.prototype.heartbeat = function (ping) {
        var e_10, _a;
        var _this = this;
        var _loop_1 = function (socket, isAlive) {
            if (!isAlive) {
                socket.terminate();
                this_1.remove(socket);
                return "continue";
            }
            this_1.alive.set(socket, false);
            ping(socket);
            var timer = setTimeout(function () {
                if (!_this.alive.get(socket)) {
                    socket.terminate();
                    _this.remove(socket);
                }
            }, PONG_MS);
            timer.unref();
        };
        var this_1 = this;
        try {
            for (var _b = __values(this.alive), _c = _b.next(); !_c.done; _c = _b.next()) {
                var _d = __read(_c.value, 2), socket = _d[0], isAlive = _d[1];
                _loop_1(socket, isAlive);
            }
        }
        catch (e_10_1) { e_10 = { error: e_10_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_10) throw e_10.error; }
        }
    };
    Bus.prototype.frame = function (event, data) {
        return { id: (0, node_crypto_1.randomUUID)(), at: new Date().toISOString(), event: event, data: data };
    };
    Bus.prototype.pushRing = function (teamId, frame) {
        this.ring.push({ id: frame.id, at: Date.now(), teamId: teamId, frame: frame });
        if (this.ring.length > RING_SIZE) {
            this.ring.splice(0, this.ring.length - RING_SIZE);
        }
    };
    return Bus;
}());
exports.Bus = Bus;
